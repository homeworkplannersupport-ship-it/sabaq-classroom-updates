# Sabaq Workspace

Independent Android classroom and planner workspace for a Dawoodi Bohra madrasah context. The project is built from scratch under package `com.foxlabs.sabaqclassroom` and is not the Homework Planner app. The permanent package ID remains unchanged so existing installs can update safely.

Published Build 2 includes local role-based accounts, editable/archiveable classrooms and rosters, history-preserving transfers, assignments and hand-in, offline submission drafts, attachment preview, timestamped receipts, announcements, linked guardian views, progress records, reminders, calendar handoff, assignment-linked focus sessions, editable journal/OCR/backup tools, original haptics and synthesized sound cues, secure update verification, and a Firebase backend/rules scaffold.

Published Build 3 adds a complete assignment lifecycle: draft, scheduled publication, published, closed, archived, restored, editable revisions, and private revision snapshots.

Build 4 is the published classroom-platform overhaul. Students receive prioritized workload planning, completion and remaining-time summaries, due-date grouping, crowded-day warnings, classwork search/filtering, private hand-in feedback, and configurable reminders for each assignment. Teachers receive a dedicated Insights destination with per-class completion, remaining workload, students-needing-attention ranking, upcoming pressure, full return/complete review controls, and one-tap assignment reuse for recurring sabaq. Guardians receive the same workload picture as a read-only family view. Reminder notifications intentionally hide assignment details on the lock screen.

Build 5 connects those workflows to the live Firebase backend. Fresh users verify their invited email with Google, use a one-time invitation, and secure that same Firebase identity with a Sabaq password during activation; returning users can use Google or email/password, and Firebase sends expiring password-reset links without the UI revealing whether an account exists. Server claims—not the client—assign roles. Firestore listeners rebuild and populate the offline cache, callable functions publish assignments and mutate submissions with revision checks, Cloud Storage carries protected attachments, and FCM delivers generic private notifications. Firestore, Storage rules, 29 capped Cloud Functions, Email/Password and Google providers, and Play Integrity App Check are live. The one-time administrator bootstrap and real-device privacy testing remain explicit production gates documented in `BACKEND.md`.

## Build

1. Install Android Studio with JDK 17+ and Android SDK 36.
2. Create `local.properties` with your Android SDK path.
3. Download the Android `google-services.json` for the `sabaq-classroom` Firebase project into `app/`. This environment-specific file is git-ignored.
4. Run `gradlew testDebugUnitTest assembleDebug`.
5. For release builds, create a private signing identity with `scripts/create-signing-identity.ps1`. Never commit the generated `signing/` directory.
6. Run `gradlew testDebugUnitTest lintRelease assembleRelease`.
7. Run `scripts/package-source.ps1 -BuildNumber 5` and `scripts/prepare-release.ps1` before publishing.

## Backend

The production design uses Firebase Authentication, Firestore, Storage, Functions, and Cloud Messaging. Rules default to deny and have adversarial emulator coverage. See [BACKEND.md](BACKEND.md), [PRIVACY-SAFETY.md](PRIVACY-SAFETY.md), and [THREAT-MODEL.md](THREAT-MODEL.md).

Do not enter real student data until the Firebase deployment, policy/consent review, independent security review, real-device testing, and consenting closed pilot are complete.

## Updates

Public APK metadata lives in [sabaq-classroom-updates](https://github.com/homeworkplannersupport-ship-it/sabaq-classroom-updates). Build 1 used a debug certificate, so permanent-key Build 2 requires the migration decision documented in [UPDATES.md](UPDATES.md). All later builds use sequential names and the permanent certificate.
