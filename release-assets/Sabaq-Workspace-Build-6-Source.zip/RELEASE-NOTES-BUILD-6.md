# Sabaq Workspace — Build 6

Build 6 makes Sabaq Workspace account-first and reorganizes classrooms into a focused, role-aware workspace.

## What changed

- A verified cloud account is required before the app opens; the offline administrator setup and local-login bypass are gone.
- The approved pilot owner can activate the first administrator account once with their verified Google identity and a recoverable Sabaq password.
- Each classroom now has Stream, Classwork, People, and Grades areas in Sabaq Workspace's own navy, gold, ivory, and sage design.
- Teachers can publish assignments, post announcements, manage rosters, record progress, review submissions, and see completion summaries.
- Assignments and announcements support multiple protected images or files, scheduling, editing, revisions, pinning, archiving, secure previews, and discussion locks.
- Class discussions and private student–teacher comments include timestamps, moderation, audit records, and privacy-safe notifications.
- Classroom owners can turn grading on or off. When enabled, teachers can use points, private grades, returned work, and class summaries; students and approved guardians see only their own results.
- Students can search classwork, view private feedback, manage reminders, attach work, save server drafts, hand in, and unsubmit when allowed.
- Administrators can invite server accounts, link guardians, suspend access, create and update classrooms, add or transfer students, and retain an audit trail.
- Cached content remains available without a connection, but writes are read-only until Firebase reconnects so no one is told an unsynced action succeeded.
- A complete Mishkaat-inspired interface now covers sign-in, role dashboards, classroom workspaces, dialogs, navigation, settings, and update history with fast haptics and optional refined sounds.

This is an alpha build. Build 2 and newer share the permanent signing identity and can update in place.
