# Updating Sabaq Workspace

The app uses only the dedicated repository `homeworkplannersupport-ship-it/sabaq-classroom-updates`.

Build 4 is published as a pre-release at `https://github.com/homeworkplannersupport-ship-it/sabaq-classroom-updates/releases/tag/build-4`. The live `main/update.json` feed points to the 45,272,848-byte APK with SHA-256 `c767221671a202cded898a36f472656140840d341c62f45a45e59288c8307df5`.

The update button is the gold download icon in the app header. It performs these checks before Android is allowed to install anything:

- update feed is fetched over HTTPS;
- APK URL must belong to the dedicated repository;
- downloaded bytes must match the published SHA-256 checksum;
- APK package must be `com.foxlabs.sabaqclassroom`;
- APK version code must match the manifest;
- Android still verifies that the signing certificate matches the installed app.

Use `scripts/prepare-release.ps1` to generate the correctly named APK and update manifest for each future release.

## Downloads handoff

Before a build is available through the in-app GitHub updater, copy only its final installable APK to the user’s native Downloads folder. Do not copy source archives, manifests, checksums, verification reports, or release notes there. Once that build is available through the updater, do not copy any release artifact to Downloads.

## Build 1 signing migration

The originally published Build 1 alpha was signed by an Android debug certificate. Build 2 and every production-intent build use the separate permanent Sabaq Workspace update certificate.

Android will not install a differently signed APK over Build 1. The secure default is therefore a one-time uninstall of Build 1 followed by installation of permanent-key Build 2; future Build 2 → Build 3 → Build 4 updates will then work normally and preserve app data.

Do not silently keep the debug key as the long-term production signer. Android key rotation can bridge newer platform versions, but supporting Android 8–12 seamlessly would continue relying on the original debug key for those devices. Any legacy bridge requires an explicit release decision and device testing.
