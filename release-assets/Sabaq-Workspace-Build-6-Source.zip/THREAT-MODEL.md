# Sabaq Workspace threat model

## Protected assets

Student identity and membership, guardian links, teacher and administrator privileges, submissions and attachments, private feedback, progress records, authentication secrets, audit history, and the Android release-signing identity.

## Trust boundaries

Android device to Firebase Authentication; Android client to Firestore, Functions, and Storage; privileged callable functions to Admin SDK; GitHub update manifest to verified APK installer; local app to Android document providers.

## Priority threats and controls

| Threat | Required control |
|---|---|
| Privilege or classroom-ID tampering | Server role claims, membership checks, deny-by-default rules, callable validation, adversarial emulator tests |
| Student reads another submission, attachment, or feedback | Separate resource/submission paths; owner, linked-guardian, or assigned-teacher rules; never authorize from UI state |
| Guardian sees an unlinked child | Server-maintained guardian link; read-only rule; audit every link change |
| Malicious or oversized attachment | MIME allowlist, 15 MB limit, immutable upload paths, malware scanning before wider deployment |
| Invitation theft, guessing, or replay | 256-bit bearer code, hash-only storage, email binding, short expiry, one-time transaction, revocation, App Check, audit |
| Replay or duplicate writes | Idempotency keys and transactions for publish, hand-in, invitations, and administration |
| Lost or shared device | Short production sessions, re-authentication for sensitive actions, OS screen-lock guidance, remote account revocation |
| Notification disclosure | Generic lock-screen text; sensitive details shown only after authenticated open |
| Update-channel takeover | Dedicated repository, HTTPS, SHA-256, package and version checks, permanent Android certificate, release gate |
| Signing-key disclosure | Repository exclusion, offline encrypted backup, restricted operators, documented rotation contingency |
| OCR or backup surprise | On-device recognition, editable confirmation, explicit export, planner-only backup |

Residual risk must be reviewed independently before real student data or a public launch.
