# Sabaq Workspace — Build 5

Build 5 is the first server-connected classroom build. Its Firebase services, security rules, capped Cloud Functions, authentication providers, and Play Integrity registration are live.

- Renamed the app to Sabaq Workspace while preserving the original navy-and-gold Sabaq launcher logo, package ID, signing identity, and update compatibility.

## Classroom delivery

- Google accounts activate through email-bound, expiring, one-time invitations issued by an administrator.
- Account creation starts by verifying the invited email with Google and links a Sabaq password to that exact Firebase identity during activation.
- Returning users can sign in with Google or email/password; a fresh install securely restores its active server profile into the offline cache.
- Forgot-password uses Firebase's expiring email reset flow and shows a non-enumerating result that does not disclose whether an account exists.
- Server custom claims and active profile documents control roles; the Android client cannot promote itself.
- Firestore listeners synchronize classrooms, rosters, published work, announcements, progress, and permitted submissions into the local offline cache.
- Teacher publication, assignment transitions, student drafts/hand-ins/unsubmits, and teacher reviews use callable transactions with audit records and revision conflict protection.
- Protected JPEG, PNG, WebP, PDF, and plain-text files upload through Firebase Storage with a 15 MB limit.
- FCM device registration and private generic notification payloads alert recipients without putting classroom, learner, feedback, or assignment details on the lock screen.

## Administration

- A fresh installation can join directly with Google and an invitation instead of creating a fake local administrator first.
- Connected administrators can issue Google invitations and create server classrooms.
- A non-deployed, one-time bootstrap script creates exactly one initial administrator and refuses to run after an administrator exists.

## Deployment status

- Firestore indexes/rules and Storage rules are deployed to the dedicated Firebase project.
- All 29 Cloud Functions are live in `us-central1`, capped at two instances per function; old deployment images are cleaned up after one day.
- Google and Email/Password sign-in are enabled, and the public-facing authentication name is Sabaq Workspace.
- Play Integrity App Check is registered for the permanent signing certificate with settings compatible with direct GitHub APK installation. Callable Functions enforce valid App Check tokens.
- The project uses the Google Cloud free trial with a CA$2.50 monthly budget alert. The alert is not a hard spending cap.

## Pilot note

Build 5 is an alpha release. Complete the initial administrator bootstrap and closed two-account Android test before entering real student data. Verify teacher-to-student publication, push delivery, attachments, hand-in, return, completion, password reset, offline recovery, and the Build 4-to-Build 5 upgrade path on physical devices.
