# Sabaq Workspace — Build 4

Version: `0.4.0-alpha-build-4`

Package: `com.foxlabs.sabaqclassroom`

Planned tag: `build-4`

## What’s new

- Every account role has a dedicated grouped Settings menu for feedback, notifications, account/data controls, updates, privacy, and app information.
- Settings and the update dialog show the exact installed version name and build number.
- A readable in-app update history explains the status and changes in Builds 1–4.
- Update checks show both the available version name and build number before download.
- Update downloads verify the published signing-certificate fingerprint and explain the one-time Build 1 uninstall migration before opening Android’s installer.
- Android 13+ asks for notification permission once during the first app launch so assignment reminders can be enabled before account setup.
- The Classroom hub now unifies classroom membership, teachers, announcements, due-soon reminders, assignment sections, submission state, and private feedback in an original workflow.
- A new workload engine turns estimates, due dates, priority, and submission state into a concrete next action, remaining-time estimate, completion percentage, due-soon/missing counts, and risk level.
- Student and guardian dashboards group upcoming work by due date, flag crowded days, and suggest a focused first study block.
- Teachers have a dedicated Insights destination with per-class completion, total estimated learner workload, attention ranking, individual workload cards, and upcoming class pressure.
- Students can search classwork, filter by classroom, and choose Off, 1-hour, 4-hour, 1-day, or 2-day reminders separately for each assignment.
- Assignment notifications use private lock-screen visibility and generic text so titles and classwork details are not exposed.
- Teachers can return handed-in work, mark it complete with private feedback, and reuse an assignment as a future draft for recurring sabaq.
- Settings explicitly reports offline/local-only operation until a secured production backend is configured.
- Added a SQLite-backed production-neutral outbox for idempotent changes, bounded retries, stale-revision conflicts, and terminal rejections without pretending Firebase is connected.
- Added real Google identity verification through Firebase Authentication and Android Credential Manager, with explicit linking to an existing approved Sabaq role and no client-side role escalation.
- Registered the permanent release fingerprints, enabled the Google provider on the no-cost Spark plan, and kept the refreshed environment-specific Firebase config out of Git.
- Production backend foundations now include secure invitations, auditable account lifecycle, assignment/submission revisions, stale-write protection, private attachment paths, and a generic privacy-safe notification outbox.

## Release gates

- Build 4 must pass unit tests, debug/UI-test compilation, release lint, R8, permanent-certificate verification, checksum generation, and real-device Settings/update-history review before publication.
- The complete post-overhaul automated gate passed on 24 August 2026: 25 unit tests, instrumentation-test APK compilation, release lint with zero errors, R8/resource shrinking, permanent certificate verification, and release checksum inspection.
- Build 3 is published; Build 2 → Build 3 real-device update testing remains a separate gate that Build 4 must not skip.
- Classroom-data backend deployment, App Check, any billing approval for scheduled functions, real push delivery, Google sign-in device testing, accessibility review, safeguarding review, and a consenting pilot remain open.
