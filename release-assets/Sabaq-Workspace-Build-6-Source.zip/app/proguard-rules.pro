# Sabaq Workspace app-specific rules. Keep minimal; release lint and runtime tests guard changes.
