package com.foxlabs.sabaqclassroom

import java.security.MessageDigest

object CloudWirePolicy {
    fun assignmentId(actorUid:String,requestId:String)=sha256("assignment:$actorUid:$requestId")
    fun submissionId(assignmentId:String,studentUid:String)=sha256("submission:$assignmentId:$studentUid")
    fun stableEntityId(actorUid:String,requestId:String,kind:String)=sha256("$kind:$actorUid:$requestId")
    fun assignmentState(state:AssignmentState)=state.name.lowercase()
    fun reviewState(state:SubmissionState)=when(state){
        SubmissionState.RETURNED->"returned"
        SubmissionState.COMPLETED->"completed"
        else->error("Unsupported review state")
    }
    fun extensionForMime(type:String):String=mapOf(
        "image/jpeg" to "jpg","image/png" to "png","image/webp" to "webp","application/pdf" to "pdf","text/plain" to "txt"
    )[type]?:error("Choose a JPEG, PNG, WebP, PDF, or plain-text file.")

    private fun sha256(value:String):String=MessageDigest.getInstance("SHA-256").digest(value.toByteArray()).joinToString(""){"%02x".format(it)}
}
