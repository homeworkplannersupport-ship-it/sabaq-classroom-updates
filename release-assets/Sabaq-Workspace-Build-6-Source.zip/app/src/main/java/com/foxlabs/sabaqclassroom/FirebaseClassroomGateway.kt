package com.foxlabs.sabaqclassroom

import android.content.Context
import android.net.Uri
import com.google.android.gms.tasks.Task
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.QuerySnapshot
import com.google.firebase.functions.FirebaseFunctions
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageMetadata
import com.google.firebase.storage.StorageReference
import java.util.UUID
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine

enum class CloudConnection { LOCAL_ONLY, CONNECTING, LIVE, NEEDS_ACTIVATION, ROLE_MISMATCH, ERROR }

data class CloudClassroomStatus(
    val connection: CloudConnection,
    val message: String,
    val lastSyncAtMillis: Long? = null
)

class FirebaseClassroomGateway(
    private val database: AppDatabase,
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val functions: FirebaseFunctions = FirebaseFunctions.getInstance("us-central1"),
    private val storage: FirebaseStorage = FirebaseStorage.getInstance()
) {
    private val listeners = mutableListOf<ListenerRegistration>()
    private var localAccount: Account? = null
    private var serverUid: String? = null
    private var statusListener: ((CloudClassroomStatus) -> Unit)? = null
    private var currentStatus = CloudClassroomStatus(CloudConnection.LOCAL_ONLY, "Classroom data is stored on this device.")

    fun status(): CloudClassroomStatus = currentStatus

    suspend fun connect(account: Account, onStatus: (CloudClassroomStatus) -> Unit): CloudClassroomStatus {
        disconnect()
        localAccount = account
        statusListener = onStatus
        update(CloudConnection.CONNECTING, "Connecting securely to Sabaq Workspace…")
        val user = auth.currentUser ?: return update(CloudConnection.LOCAL_ONLY, "Link and sign in with Google to receive classroom updates.")
        val linked = database.federatedIdentityForAccount(account.id)
        if (linked?.firebaseUid != user.uid) {
            return update(CloudConnection.LOCAL_ONLY, "This local profile is not linked to the signed-in Google account.")
        }
        serverUid = user.uid
        return try {
            user.getIdToken(true).awaitResult()
            val profile = firestore.document("profiles/${user.uid}").get().awaitResult()
            if (!profile.exists()) return update(CloudConnection.NEEDS_ACTIVATION, "Google is verified. Enter an administrator invitation code to activate classroom sync.")
            val remoteRole = profile.role()
            if (remoteRole != account.role) {
                return update(CloudConnection.ROLE_MISMATCH, "Server role ${remoteRole.name.lowercase()} does not match this local ${account.role.name.lowercase()} profile. Sync is blocked.")
            }
            if (profile.getBoolean("active") != true) return update(CloudConnection.ERROR, "This server account is suspended.")
            database.upsertCloudProfile(user.uid, profile.getString("displayName").orEmpty(), remoteRole, true)
            val classroomIds = if(remoteRole==AccountRole.ADMIN){firestore.collection("classrooms").get().awaitResult().documents.map{it.id}.take(20)}else profile.stringList("classroomIds").distinct().take(20)
            val studentIds = profile.stringList("studentIds").distinct().take(20)
            initialSync(classroomIds, studentIds, remoteRole)
            attachRealtime(profile.reference.path, classroomIds, studentIds, remoteRole)
            registerCurrentDevice()
            update(CloudConnection.LIVE, "Live server sync is active. Teacher publications and student hand-ins update across devices.", System.currentTimeMillis())
        } catch (error: Exception) {
            update(CloudConnection.ERROR, friendlyCloudError(error))
        }
    }

    fun disconnect() {
        listeners.forEach(ListenerRegistration::remove)
        listeners.clear()
        localAccount = null
        serverUid = null
        statusListener = null
        currentStatus = CloudClassroomStatus(CloudConnection.LOCAL_ONLY, "Classroom data is stored on this device.")
    }

    suspend fun restoreSignedInAccount(identity: FirebaseIdentity): Account? {
        val user = auth.currentUser ?: return null
        if (user.uid != identity.uid || identity.email.isBlank()) return null
        user.getIdToken(true).awaitResult()
        val profile = firestore.document("profiles/${user.uid}").get().awaitResult()
        if (!profile.exists() || profile.getBoolean("active") != true) return null
        val account = database.upsertCloudProfile(
            firebaseUid = user.uid,
            displayName = profile.getString("displayName").orEmpty().ifBlank { identity.displayName },
            role = profile.role(),
            active = true
        )
        database.linkFirebaseIdentity(account.id, user.uid, identity.email)
        return account
    }

    suspend fun redeemGoogleInvitation(code: String): AccountRole {
        require(auth.currentUser != null) { "Sign in with Google before using an invitation." }
        val result = call("redeemGoogleInvitation", mapOf("code" to code.trim()))
        auth.currentUser!!.getIdToken(true).awaitResult()
        val role = (result["role"] as? String).orEmpty().uppercase()
        val resolved=AccountRole.valueOf(role)
        val account = database.upsertCloudProfile(auth.currentUser!!.uid,auth.currentUser!!.displayName.orEmpty(),resolved,true)
        database.linkFirebaseIdentity(account.id,auth.currentUser!!.uid,auth.currentUser!!.email.orEmpty())
        return resolved
    }

    suspend fun claimInitialAdministrator(): Account {
        val user = auth.currentUser ?: error("Verify your Google account first.")
        val result = call("claimInitialAdministrator", emptyMap())
        user.getIdToken(true).awaitResult()
        val role = (result["role"] as? String).orEmpty().uppercase()
        require(role == AccountRole.ADMIN.name) { "The server did not grant the workspace owner role." }
        val identity = FirebaseIdentity(user.uid, user.displayName.orEmpty(), user.email.orEmpty(), user.photoUrl?.toString())
        return restoreSignedInAccount(identity) ?: error("Owner activation succeeded, but the profile could not be opened.")
    }

    suspend fun publishAssignment(
        context:Context,
        classroomId: String,
        title: String,
        instructions: String,
        subject: String,
        dueAtMillis: Long,
        estimateMinutes: Int,
        priority: String,
        type: String,
        steps: List<String>,
        state: AssignmentState,
        publishAtMillis: Long,
        attachmentUri:String
        ,attachmentUris:List<String> = listOfNotNull(attachmentUri.takeIf(String::isNotBlank))
        ,pointsPossible:Int? = null
        ,commentsEnabled:Boolean = true
    ): String {
        requireLive()
        val actorUid=serverUid?:error("Server identity is missing.")
        val requestId=UUID.randomUUID().toString()
        val assignmentId=CloudWirePolicy.assignmentId(actorUid,requestId)
        val uploaded=uploadAttachments(context,attachmentUris,"classrooms/$classroomId/assignments/$assignmentId")
        val data = linkedMapOf<String, Any?>(
            "requestId" to requestId,
            "classroomId" to classroomId,
            "title" to title,
            "instructions" to instructions.ifBlank { " " },
            "subject" to subject,
            "dueAt" to dueAtMillis,
            "estimateMinutes" to estimateMinutes,
            "priority" to priority,
            "type" to type,
            "steps" to steps,
            "attachmentPaths" to uploaded.map{it.path},
            "pointsPossible" to pointsPossible,
            "commentsEnabled" to commentsEnabled,
            "state" to CloudWirePolicy.assignmentState(state),
        )
        if (state == AssignmentState.SCHEDULED) data["publishAt"] = publishAtMillis
        return try{
            val result = call("publishAssignment", data)
            result["id"] as? String ?: error("Server did not return the assignment ID.")
        }catch(error:Throwable){uploaded.forEach{it.delete()};throw error}
    }

    suspend fun createInvitation(displayName:String,email:String,role:AccountRole,classroomIds:List<String>):String{
        requireLive()
        val result=call("createInvitation",mapOf("displayName" to displayName,"email" to email,"role" to role.name.lowercase(),"classroomIds" to classroomIds,"expiresInHours" to 72))
        return result["code"] as? String?:error("Server did not return an invitation code.")
    }

    suspend fun createClassroom(name:String,section:String,teacherLocalId:String):String{
        requireLive()
        val teacherUid=database.serverUidForAccount(teacherLocalId)
        val result=call("createClassroom",mapOf("name" to name,"section" to section.ifBlank{"General"},"teacherId" to teacherUid))
        val id=result["id"] as? String?:error("Server did not return the classroom ID.")
        database.upsertCloudClassroom(Classroom(id,name.trim(),section.trim().ifBlank{"General"},teacherUid),emptyList())
        return id
    }

    suspend fun postAnnouncement(classroomId:String,title:String,body:String):String{
        requireLive()
        val result=call("postAnnouncement",mapOf(
            "classroomId" to classroomId,
            "title" to title,
            "body" to body,
            "requestId" to UUID.randomUUID().toString()
        ))
        return result["id"] as? String?:error("Server did not return the announcement ID.")
    }

    suspend fun postAnnouncement(context:Context,classroomId:String,title:String,body:String,attachmentUris:List<String>,state:AnnouncementState,publishAt:Long,pinned:Boolean,commentsEnabled:Boolean):String{
        requireLive();val requestId=UUID.randomUUID().toString();val id=CloudWirePolicy.stableEntityId(serverUid?:error("Server identity is missing."),requestId,"announcement");val uploaded=uploadAttachments(context,attachmentUris,"classrooms/$classroomId/announcements/$id")
        return try{val data=linkedMapOf<String,Any?>("classroomId" to classroomId,"title" to title,"body" to body,"requestId" to requestId,"attachmentPaths" to uploaded.map{it.path},"state" to state.name.lowercase(),"pinned" to pinned,"commentsEnabled" to commentsEnabled);if(state==AnnouncementState.SCHEDULED)data["publishAt"]=publishAt;val result=call("postAnnouncement",data);result["id"] as? String?:error("Server did not return the announcement ID.")}catch(error:Throwable){uploaded.forEach{it.delete()};throw error}
    }

    suspend fun updateAnnouncement(context:Context,announcement:Announcement,title:String,body:String,attachmentUris:List<String>,state:AnnouncementState,publishAt:Long,pinned:Boolean,commentsEnabled:Boolean){
        requireLive();val cloudExisting=attachmentUris.filter{it.startsWith("cloud:")}.map{it.removePrefix("cloud:")};val local=attachmentUris.filterNot{it.startsWith("cloud:")};val uploaded=uploadAttachments(context,local,"classrooms/${announcement.classroomId}/announcements/${announcement.id}");try{val data=linkedMapOf<String,Any?>("announcementId" to announcement.id,"title" to title,"body" to body,"attachmentPaths" to cloudExisting+uploaded.map{it.path},"state" to state.name.lowercase(),"pinned" to pinned,"commentsEnabled" to commentsEnabled);if(state==AnnouncementState.SCHEDULED)data["publishAt"]=publishAt;call("updateAnnouncement",data)}catch(error:Throwable){uploaded.forEach{it.delete()};throw error}
    }

    suspend fun setAccountActive(accountId:String,active:Boolean){
        requireLive();call("setAccountActive",mapOf("uid" to database.serverUidForAccount(accountId),"active" to active))
    }

    suspend fun linkGuardian(guardianId:String,studentId:String){
        requireLive();call("linkGuardian",mapOf("guardianId" to database.serverUidForAccount(guardianId),"studentId" to database.serverUidForAccount(studentId)))
    }

    suspend fun addClassroomMember(classroomId:String,accountId:String){
        requireLive();call("addClassroomMember",mapOf("classroomId" to classroomId,"uid" to database.serverUidForAccount(accountId)))
    }

    suspend fun removeClassroomMember(classroomId:String,accountId:String){
        requireLive();call("removeClassroomMember",mapOf("classroomId" to classroomId,"uid" to database.serverUidForAccount(accountId)))
    }

    suspend fun transferClassroomMember(accountId:String,fromClassroomId:String,toClassroomId:String){
        requireLive();call("transferClassroomMember",mapOf("uid" to database.serverUidForAccount(accountId),"fromClassroomId" to fromClassroomId,"toClassroomId" to toClassroomId))
    }

    suspend fun updateClassroom(classroomId:String,name:String,section:String,archived:Boolean,gradingEnabled:Boolean=false){
        requireLive();call("updateClassroom",mapOf("classroomId" to classroomId,"name" to name,"section" to section.ifBlank{"General"},"archived" to archived,"gradingEnabled" to gradingEnabled))
    }

    suspend fun transitionAssignment(assignment: ClassroomAssignment, state: AssignmentState, publishAtMillis: Long = 0L) {
        requireLive()
        val data = linkedMapOf<String, Any?>("assignmentId" to assignment.id, "state" to CloudWirePolicy.assignmentState(state))
        if (state == AssignmentState.SCHEDULED) data["publishAt"] = publishAtMillis
        call("transitionAssignment", data)
    }

    suspend fun updateAssignment(context:Context,assignment:ClassroomAssignment,title:String,instructions:String,subject:String,dueAtMillis:Long,estimateMinutes:Int,priority:String,type:String,steps:List<String>,attachmentUri:String,attachmentUris:List<String> = listOfNotNull(attachmentUri.takeIf(String::isNotBlank)),pointsPossible:Int?=assignment.pointsPossible,commentsEnabled:Boolean=assignment.commentsEnabled){
        requireLive()
        val existing=attachmentUris.filter{it.startsWith("cloud:")}.map{it.removePrefix("cloud:")};val uploaded=uploadAttachments(context,attachmentUris.filterNot{it.startsWith("cloud:")},"classrooms/${assignment.classroomId}/assignments/${assignment.id}")
        try{call("updateAssignment",mapOf("assignmentId" to assignment.id,"title" to title,"instructions" to instructions.ifBlank{" "},"subject" to subject,"dueAt" to dueAtMillis,"estimateMinutes" to estimateMinutes,"priority" to priority,"type" to type,"steps" to steps,"attachmentPaths" to existing+uploaded.map{it.path},"pointsPossible" to pointsPossible,"commentsEnabled" to commentsEnabled))}catch(error:Throwable){uploaded.forEach{it.delete()};throw error}
    }

    suspend fun recordProgress(studentId:String,classroomId:String,subject:String,criterion:String,level:Int,note:String){
        requireLive();call("recordProgress",mapOf("studentId" to database.serverUidForAccount(studentId),"classroomId" to classroomId,"subject" to subject,"criterion" to criterion,"level" to level,"note" to note.ifBlank{" "}))
    }

    suspend fun saveSubmission(context:Context,assignment:ClassroomAssignment, note: String, current: StudentSubmission?, handIn: Boolean,attachmentUri:String) {
        requireLive()
        val uid=serverUid?:error("Server identity is missing.")
        val submissionId=CloudWirePolicy.submissionId(assignment.id,uid)
        val uploaded=uploadAttachment(context,attachmentUri,"classrooms/${assignment.classroomId}/submissions/$uid/$submissionId")
        try{call(if (handIn) "handIn" else "saveSubmissionDraft", mapOf(
            "assignmentId" to assignment.id,
            "note" to note,
            "attachmentPaths" to uploaded.map{it.path},
            "expectedRevision" to (current?.revision ?: 0),
            "requestId" to UUID.randomUUID().toString(),
        ))}catch(error:Throwable){uploaded.forEach{it.delete()};throw error}
    }

    suspend fun unsubmit(assignmentId: String, current: StudentSubmission) {
        requireLive()
        call("unsubmit", mapOf("assignmentId" to assignmentId, "expectedRevision" to current.revision, "requestId" to UUID.randomUUID().toString()))
    }

    suspend fun reviewSubmission(submission: StudentSubmission, state: SubmissionState, feedback: String,gradePoints:Int?=null) {
        requireLive()
        call("reviewSubmission", mapOf(
            "submissionId" to submission.id,
            "state" to CloudWirePolicy.reviewState(state),
            "feedback" to feedback,
            "gradePoints" to gradePoints,
            "expectedRevision" to submission.revision,
            "requestId" to UUID.randomUUID().toString(),
        ))
    }

    suspend fun postComment(entityType:String,entityId:String,body:String,visibility:CommentVisibility,studentId:String?=null){requireLive();call("postComment",mapOf("entityType" to entityType,"entityId" to entityId,"body" to body,"visibility" to visibility.name.lowercase(),"studentId" to studentId?.let(database::serverUidForAccount),"requestId" to UUID.randomUUID().toString()))}
    suspend fun removeComment(commentId:String){requireLive();call("removeComment",mapOf("commentId" to commentId))}

    private suspend fun initialSync(classroomIds: List<String>, studentIds: List<String>, role: AccountRole) {
        if(role==AccountRole.ADMIN)firestore.collection("profiles").get().awaitResult().documents.forEach(::applyProfile)
        val classDocuments = classroomIds.map { firestore.document("classrooms/$it").get().awaitResult() }.filter(DocumentSnapshot::exists)
        val profileIds = classDocuments.flatMap { it.stringList("memberIds") + it.stringList("teacherIds") }.plus(studentIds).plus(serverUid.orEmpty()).filter(String::isNotBlank).distinct()
        profileIds.forEach { uid -> firestore.document("profiles/$uid").get().awaitResult().takeIf(DocumentSnapshot::exists)?.let(::applyProfile) }
        classDocuments.forEach(::applyClassroom)
        classroomIds.forEach { classId ->
            val managed=role in setOf(AccountRole.ADMIN,AccountRole.TEACHER)
            val assignmentsQuery=firestore.collection("assignments").whereEqualTo("classroomId",classId).let{if(managed)it else it.whereIn("state",listOf("published","closed"))}
            val announcementsQuery=firestore.collection("announcements").whereEqualTo("classroomId",classId).let{if(managed)it else it.whereEqualTo("state","published")}
            applyAssignments(assignmentsQuery.get().awaitResult())
            applyAnnouncements(announcementsQuery.get().awaitResult())
            when(role){AccountRole.ADMIN,AccountRole.TEACHER->applyComments(firestore.collection("comments").whereEqualTo("classId",classId).get().awaitResult());AccountRole.STUDENT->applyComments(firestore.collection("comments").whereEqualTo("classId",classId).whereEqualTo("visibility","public").get().awaitResult());else->Unit}
        }
        if(role==AccountRole.STUDENT)applyComments(firestore.collection("comments").whereEqualTo("studentId",serverUid.orEmpty()).whereEqualTo("visibility","private").get().awaitResult())
        when (role) {
            AccountRole.STUDENT -> {
                applySubmissions(firestore.collection("submissions").whereEqualTo("studentId", serverUid.orEmpty()).get().awaitResult())
                applyProgress(firestore.collection("progress").whereEqualTo("studentId", serverUid.orEmpty()).get().awaitResult())
            }
            AccountRole.GUARDIAN -> studentIds.forEach { uid ->
                applySubmissions(firestore.collection("submissions").whereEqualTo("studentId", uid).get().awaitResult())
                applyProgress(firestore.collection("progress").whereEqualTo("studentId", uid).get().awaitResult())
            }
            AccountRole.TEACHER, AccountRole.ADMIN -> classroomIds.forEach { classId ->
                applySubmissions(firestore.collection("submissions").whereEqualTo("classroomId", classId).get().awaitResult())
                applyProgress(firestore.collection("progress").whereEqualTo("classroomId", classId).get().awaitResult())
            }
        }
    }

    private fun attachRealtime(profilePath: String, classroomIds: List<String>, studentIds: List<String>, role: AccountRole) {
        listeners += firestore.document(profilePath).addSnapshotListener { snapshot, error ->
            if (error != null) update(CloudConnection.ERROR, friendlyCloudError(error))
            else if (snapshot == null || !snapshot.exists() || snapshot.getBoolean("active") != true) update(CloudConnection.ERROR, "This server account is no longer active.")
            else applyProfile(snapshot)
        }
        classroomIds.forEach { classId ->
            listeners += firestore.document("classrooms/$classId").addSnapshotListener { snapshot, error ->
                if (error != null) update(CloudConnection.ERROR, friendlyCloudError(error)) else snapshot?.takeIf(DocumentSnapshot::exists)?.let(::applyClassroomAndMembers)
            }
            val managed=role in setOf(AccountRole.ADMIN,AccountRole.TEACHER)
            val assignmentsQuery=firestore.collection("assignments").whereEqualTo("classroomId",classId).let{if(managed)it else it.whereIn("state",listOf("published","closed"))}
            val announcementsQuery=firestore.collection("announcements").whereEqualTo("classroomId",classId).let{if(managed)it else it.whereEqualTo("state","published")}
            listen(assignmentsQuery, ::applyAssignmentChanges)
            listen(announcementsQuery, ::applyAnnouncementChanges)
            when(role){AccountRole.ADMIN,AccountRole.TEACHER->listen(firestore.collection("comments").whereEqualTo("classId",classId),::applyCommentChanges);AccountRole.STUDENT->listen(firestore.collection("comments").whereEqualTo("classId",classId).whereEqualTo("visibility","public"),::applyCommentChanges);else->Unit}
        }
        if(role==AccountRole.STUDENT)listen(firestore.collection("comments").whereEqualTo("studentId",serverUid.orEmpty()).whereEqualTo("visibility","private"),::applyCommentChanges)
        when (role) {
            AccountRole.STUDENT -> {
                listen(firestore.collection("submissions").whereEqualTo("studentId", serverUid.orEmpty()), ::applySubmissionChanges)
                listen(firestore.collection("progress").whereEqualTo("studentId", serverUid.orEmpty()), ::applyProgressChanges)
            }
            AccountRole.GUARDIAN -> studentIds.forEach { uid ->
                listen(firestore.collection("submissions").whereEqualTo("studentId", uid), ::applySubmissionChanges)
                listen(firestore.collection("progress").whereEqualTo("studentId", uid), ::applyProgressChanges)
            }
            AccountRole.TEACHER, AccountRole.ADMIN -> classroomIds.forEach { classId ->
                listen(firestore.collection("submissions").whereEqualTo("classroomId", classId), ::applySubmissionChanges)
                listen(firestore.collection("progress").whereEqualTo("classroomId", classId), ::applyProgressChanges)
            }
        }
    }

    private fun listen(query: Query, consumer: (QuerySnapshot) -> Unit) {
        listeners += query.addSnapshotListener { snapshot, error ->
            if (error != null) update(CloudConnection.ERROR, friendlyCloudError(error))
            else if (snapshot != null) {
                runCatching { consumer(snapshot) }
                    .onSuccess { update(CloudConnection.LIVE, "Live server sync is active.", System.currentTimeMillis()) }
                    .onFailure { update(CloudConnection.ERROR, friendlyCloudError(it)) }
            }
        }
    }

    private fun applyClassroomAndMembers(snapshot: DocumentSnapshot) {
        snapshot.stringList("memberIds").plus(snapshot.stringList("teacherIds")).distinct().forEach { uid ->
            firestore.document("profiles/$uid").get().addOnSuccessListener { profile -> profile.takeIf(DocumentSnapshot::exists)?.let(::applyProfile) }
        }
        applyClassroom(snapshot)
    }

    private fun applyProfile(snapshot: DocumentSnapshot) {
        val role = runCatching { snapshot.role() }.getOrElse { AccountRole.STUDENT }
        database.upsertCloudProfile(snapshot.id, snapshot.getString("displayName").orEmpty(), role, snapshot.getBoolean("active") == true)
    }

    private fun applyClassroom(snapshot: DocumentSnapshot) {
        val teachers = snapshot.stringList("teacherIds")
        val teacher = teachers.firstOrNull() ?: return
        val members = snapshot.stringList("memberIds").distinct()
        database.upsertCloudClassroom(Classroom(snapshot.id, snapshot.getString("name").orEmpty().ifBlank { "Sabaq classroom" }, snapshot.getString("section").orEmpty().ifBlank { "General" }, teacher, snapshot.getBoolean("archived") == true,snapshot.getBoolean("gradingEnabled")==true), members)
    }

    private fun applyAssignments(snapshot: QuerySnapshot) = snapshot.documents.forEach { applyAssignment(it) }
    private fun applyAssignmentChanges(snapshot: QuerySnapshot) = snapshot.documentChanges.forEach { change -> if (change.type == DocumentChange.Type.REMOVED) database.deleteCloudAssignment(change.document.id) else applyAssignment(change.document) }
    private fun applyAssignment(document: DocumentSnapshot) {
        val state = runCatching { AssignmentState.valueOf(document.getString("state").orEmpty().uppercase()) }.getOrDefault(AssignmentState.DRAFT)
        database.upsertCloudAssignment(ClassroomAssignment(
            id=document.id,classroomId=document.getString("classroomId").orEmpty(),teacherId=document.getString("teacherId").orEmpty(),title=document.getString("title").orEmpty(),instructions=document.getString("instructions").orEmpty(),subject=document.getString("subject").orEmpty(),
            dueAtMillis=document.timeMillis("dueAt"),estimateMinutes=(document.getLong("estimateMinutes")?:30).toInt(),priority=document.getString("priority").orEmpty().ifBlank{"Standard"},state=state,createdAtMillis=document.timeMillis("createdAt"),type=document.getString("type").orEmpty().ifBlank{"Sabaq"},steps=document.stringList("steps"),attachmentUri=document.cloudAttachment(),publishAtMillis=document.timeMillis("publishAt"),updatedAtMillis=document.timeMillis("updatedAt"),revision=(document.getLong("revision")?:1).toInt(),attachmentUris=document.cloudAttachments(),pointsPossible=document.getLong("pointsPossible")?.toInt(),commentsEnabled=document.getBoolean("commentsEnabled")!=false
        ))
    }

    private fun applySubmissions(snapshot: QuerySnapshot) = snapshot.documents.forEach { runCatching { applySubmission(it) } }
    private fun applySubmissionChanges(snapshot: QuerySnapshot) = snapshot.documentChanges.forEach { change -> if (change.type == DocumentChange.Type.REMOVED) database.deleteCloudSubmission(change.document.id) else runCatching { applySubmission(change.document) } }
    private fun applySubmission(document: DocumentSnapshot) {
        val state = when(document.getString("state")) { "draft"->SubmissionState.STARTED;"handed_in"->SubmissionState.HANDED_IN;"returned"->SubmissionState.RETURNED;"completed"->SubmissionState.COMPLETED;else->SubmissionState.NOT_STARTED }
        database.upsertCloudSubmission(StudentSubmission(document.id,document.getString("assignmentId").orEmpty(),document.getString("studentId").orEmpty(),document.getString("note").orEmpty(),state,document.timeMillis("handedInAt").takeIf{it>0},document.getString("feedback").orEmpty(),document.cloudAttachment(),(document.getLong("revision")?:0).toInt(),document.cloudAttachments(),document.getLong("gradePoints")?.toInt()))
    }

    private fun applyAnnouncements(snapshot: QuerySnapshot) = snapshot.documents.forEach(::applyAnnouncement)
    private fun applyAnnouncementChanges(snapshot: QuerySnapshot) = snapshot.documentChanges.forEach { change -> if(change.type==DocumentChange.Type.REMOVED)database.deleteCloudAnnouncement(change.document.id)else applyAnnouncement(change.document) }
    private fun applyAnnouncement(document:DocumentSnapshot)=database.upsertCloudAnnouncement(Announcement(document.id,document.getString("classroomId").orEmpty(),document.getString("authorId").orEmpty(),document.getString("title").orEmpty(),document.getString("body").orEmpty(),document.timeMillis("createdAt"),document.cloudAttachments(),document.timeMillis("publishAt"),document.timeMillis("updatedAt"),document.getBoolean("pinned")==true,runCatching{AnnouncementState.valueOf(document.getString("state").orEmpty().uppercase())}.getOrDefault(AnnouncementState.PUBLISHED),document.getBoolean("commentsEnabled")!=false))

    private fun applyComments(snapshot:QuerySnapshot)=snapshot.documents.forEach(::applyComment)
    private fun applyCommentChanges(snapshot:QuerySnapshot)=snapshot.documentChanges.forEach{change->if(change.type==DocumentChange.Type.REMOVED)database.deleteCloudComment(change.document.id)else applyComment(change.document)}
    private fun applyComment(document:DocumentSnapshot)=database.upsertCloudComment(ClassroomComment(document.id,document.getString("classId").orEmpty(),document.getString("entityType").orEmpty(),document.getString("entityId").orEmpty(),document.getString("authorId").orEmpty(),runCatching{CommentVisibility.valueOf(document.getString("visibility").orEmpty().uppercase())}.getOrDefault(CommentVisibility.PUBLIC),document.getString("studentId"),document.getString("body").orEmpty(),document.timeMillis("createdAt"),document.timeMillis("updatedAt"),document.getBoolean("removed")==true))

    private fun applyProgress(snapshot:QuerySnapshot)=snapshot.documents.forEach(::applyProgressItem)
    private fun applyProgressChanges(snapshot:QuerySnapshot)=snapshot.documentChanges.filter{it.type!=DocumentChange.Type.REMOVED}.forEach{applyProgressItem(it.document)}
    private fun applyProgressItem(document:DocumentSnapshot)=database.upsertCloudProgress(ProgressRecord(document.id,document.getString("studentId").orEmpty(),document.getString("subject").orEmpty(),document.getString("criterion").orEmpty(),(document.getLong("level")?:1).toInt(),document.getString("note").orEmpty(),document.timeMillis("createdAt")))

    private suspend fun registerCurrentDevice() {
        val token = FirebaseMessaging.getInstance().token.awaitResult()
        call("registerDeviceToken", mapOf("token" to token))
    }

    private suspend fun uploadAttachment(context:Context,uriText:String,prefix:String):List<StorageReference>{
        if(uriText.isBlank()||uriText.startsWith("cloud:"))return emptyList()
        val uri=Uri.parse(uriText)
        val type=context.contentResolver.getType(uri).orEmpty()
        val extension=CloudWirePolicy.extensionForMime(type)
        val length=context.contentResolver.openAssetFileDescriptor(uri,"r")?.use{it.length}?:-1
        require(length in 1..(15L*1024L*1024L)){"Attachments must be between 1 byte and 15 MB."}
        val reference=storage.reference.child("$prefix/${UUID.randomUUID()}.$extension")
        reference.putFile(uri,StorageMetadata.Builder().setContentType(type).build()).awaitResult()
        return listOf(reference)
    }

    private suspend fun uploadAttachments(context:Context,uriTexts:List<String>,prefix:String):List<StorageReference>{
        require(uriTexts.size<=10){"Choose no more than 10 attachments."}
        val uploaded=mutableListOf<StorageReference>()
        try{uriTexts.distinct().filter{it.isNotBlank()&&!it.startsWith("cloud:")}.forEach{uploaded+=uploadAttachment(context,it,prefix)};return uploaded}catch(error:Throwable){uploaded.forEach{it.delete()};throw error}
    }

    private suspend fun call(name: String, data: Map<String, Any?>): Map<String, Any?> {
        val raw = functions.getHttpsCallable(name).call(data).awaitResult().data
        @Suppress("UNCHECKED_CAST")
        return raw as? Map<String, Any?> ?: emptyMap()
    }

    private fun requireLive() { require(currentStatus.connection == CloudConnection.LIVE) { "Live classroom sync is not connected." } }
    private fun update(connection:CloudConnection,message:String,lastSyncAtMillis:Long?=currentStatus.lastSyncAtMillis):CloudClassroomStatus{
        currentStatus=CloudClassroomStatus(connection,message,lastSyncAtMillis);statusListener?.invoke(currentStatus);return currentStatus
    }
}

object CloudDeviceRegistration {
    fun register(token:String){
        if(FirebaseAuth.getInstance().currentUser==null)return
        FirebaseFunctions.getInstance("us-central1").getHttpsCallable("registerDeviceToken").call(mapOf("token" to token))
    }
}

private fun DocumentSnapshot.stringList(field:String):List<String> = (get(field) as? List<*>)?.mapNotNull{it as? String}.orEmpty()
private fun DocumentSnapshot.timeMillis(field:String):Long = getTimestamp(field)?.toDate()?.time ?: 0L
private fun DocumentSnapshot.cloudAttachments():List<String> = stringList("attachmentPaths").map{"cloud:$it"}
private fun DocumentSnapshot.cloudAttachment():String = cloudAttachments().firstOrNull().orEmpty()
private fun DocumentSnapshot.role():AccountRole = AccountRole.valueOf(getString("role").orEmpty().uppercase())

private suspend fun <T> Task<T>.awaitResult():T = suspendCancellableCoroutine { continuation ->
    addOnCompleteListener { task ->
        if(!continuation.isActive)return@addOnCompleteListener
        if(task.isSuccessful)continuation.resume(task.result) else continuation.resumeWithException(task.exception?:IllegalStateException("Firebase operation failed."))
    }
}

private fun friendlyCloudError(error:Throwable):String{
    val message=error.message.orEmpty()
    return when{
        message.contains("PERMISSION_DENIED",true)||message.contains("permission",true)->"Server access was denied. Check the account role, invitation, and App Check setup."
        message.contains("UNAVAILABLE",true)||message.contains("network",true)->"The classroom server is temporarily unreachable. Cached work remains available."
        else->"Classroom sync stopped safely: ${message.ifBlank{"Unknown server error."}}"
    }
}
