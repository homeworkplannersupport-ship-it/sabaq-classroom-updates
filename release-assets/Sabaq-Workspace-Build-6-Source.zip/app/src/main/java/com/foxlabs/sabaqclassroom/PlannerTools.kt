package com.foxlabs.sabaqclassroom

import android.content.Intent
import android.os.SystemClock
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Assignment
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.ceil

private val HubNavy=Color(0xFF102D46)
private val HubGold=Color(0xFFD4A928)
private val HubIvory=Color(0xFFFFF9EA)

@Composable
fun PlannerHub(db:AppDatabase,account:Account,refresh:Int,onRefresh:()->Unit,perform:(FeedbackKind)->Unit){
    var tab by rememberSaveable{mutableStateOf("Tasks")}
    Column(Modifier.fillMaxSize()){
        Column(Modifier.padding(horizontal=20.dp,vertical=14.dp)){Text("My planner",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold,color=HubNavy);Text("Private study tools and history",color=HubNavy.copy(alpha=.6f));PrimaryScrollableTabRow(selectedTabIndex=listOf("Tasks","Calendar","Focus","Journal","Scanner").indexOf(tab),edgePadding=0.dp,containerColor=Color.Transparent){listOf("Tasks","Calendar","Focus","Journal","Scanner").forEach{label->Tab(tab==label,{tab=label;perform(FeedbackKind.SELECT)},text={Text(label)})}}}
        when(tab){"Tasks"->TaskTool(db,account,refresh,onRefresh,perform);"Calendar"->CalendarTool(db,account,refresh);"Focus"->FocusTool(db,account,refresh,onRefresh,perform);"Journal"->JournalTool(db,account,refresh,onRefresh,perform);else->ScannerTool(db,account,refresh,onRefresh,perform)}
    }
}

@Composable
private fun TaskTool(db:AppDatabase,account:Account,refresh:Int,onRefresh:()->Unit,perform:(FeedbackKind)->Unit){val tasks=remember(refresh){db.personalTasks(account.id)};var add by remember{mutableStateOf(false)};LazyColumn(contentPadding=PaddingValues(20.dp,8.dp,20.dp,90.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
    item{ToolInfo(Icons.Default.Lightbulb,"Planning coach",if(tasks.none{!it.completed})"Add a short revision task for this week." else "Begin with ${tasks.first{!it.completed}.estimateMinutes.coerceAtMost(25)} minutes on ${tasks.first{!it.completed}.title}.")}
    item{Button(onClick={add=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Add,null);Spacer(Modifier.width(8.dp));Text("Add personal task")}}
    if(tasks.isEmpty())item{ToolEmpty("No personal tasks")}
    items(tasks,key={it.id}){t->Surface(color=HubIvory,shape=RoundedCornerShape(18.dp)){Row(Modifier.fillMaxWidth().padding(13.dp),verticalAlignment=Alignment.CenterVertically){Checkbox(t.completed,{db.togglePersonalTask(t.id,it);perform(if(it)FeedbackKind.COMPLETE else FeedbackKind.SELECT);onRefresh()});Column{Text(t.title,fontWeight=FontWeight.Bold);Text("${t.estimateMinutes} min · ${formatMoment(t.dueAtMillis)}",color=HubNavy.copy(alpha=.6f))}}}}
    }
    if(add)TaskDialog({add=false}){title,min->db.addPersonalTask(account.id,title,System.currentTimeMillis()+86_400_000,min);perform(FeedbackKind.CONFIRM);add=false;onRefresh()}
}

@Composable private fun TaskDialog(onDismiss:()->Unit,onAdd:(String,Int)->Unit){var title by remember{mutableStateOf("")};var min by remember{mutableStateOf("25")};AlertDialog(onDismissRequest=onDismiss,title={Text("Personal task")},text={Column{OutlinedTextField(title,{title=it},label={Text("Title")});OutlinedTextField(min,{min=it.filter(Char::isDigit)},label={Text("Minutes")})}},confirmButton={Button(enabled=title.isNotBlank(),onClick={onAdd(title,min.toIntOrNull()?:25)}){Text("Add")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})}

@Composable
private fun CalendarTool(db:AppDatabase,account:Account,refresh:Int){val assignments=remember(refresh){db.assignmentsFor(account)};val tasks=remember(refresh){db.personalTasks(account.id)};val days=remember(assignments,tasks){(assignments.map{Instant.ofEpochMilli(it.dueAtMillis).atZone(ZoneId.systemDefault()).toLocalDate()}+tasks.map{Instant.ofEpochMilli(it.dueAtMillis).atZone(ZoneId.systemDefault()).toLocalDate()}).distinct().sorted()};LazyColumn(contentPadding=PaddingValues(20.dp,8.dp,20.dp,90.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
    if(days.isEmpty())item{ToolEmpty("Nothing scheduled")}
    items(days){day->Surface(color=HubIvory,shape=RoundedCornerShape(19.dp)){Column(Modifier.padding(15.dp)){Text(day.format(DateTimeFormatter.ofPattern("EEEE, d MMMM")),fontWeight=FontWeight.Bold,color=HubNavy);assignments.filter{Instant.ofEpochMilli(it.dueAtMillis).atZone(ZoneId.systemDefault()).toLocalDate()==day}.forEach{Text("• ${it.title} · classroom")};tasks.filter{Instant.ofEpochMilli(it.dueAtMillis).atZone(ZoneId.systemDefault()).toLocalDate()==day}.forEach{Text("• ${it.title} · personal")}}}}
    }}

@Composable
private fun FocusTool(db:AppDatabase,account:Account,refresh:Int,onRefresh:()->Unit,perform:(FeedbackKind)->Unit){
    val history=remember(refresh){db.focusSessions(account.id)}
    val assignments=remember(refresh){db.assignmentsFor(account).filter{it.state==AssignmentState.PUBLISHED}}
    val assignmentNames=remember(assignments){assignments.associate{it.id to it.title}}
    var selectedAssignmentId by rememberSaveable{mutableStateOf("")}
    var assignmentMenu by remember{mutableStateOf(false)}
    var minutes by rememberSaveable{mutableIntStateOf(15)}
    var deadline by rememberSaveable{mutableLongStateOf(0L)}
    var remaining by remember{mutableLongStateOf(0L)}
    LaunchedEffect(deadline){while(deadline>0){remaining=(deadline-SystemClock.elapsedRealtime()).coerceAtLeast(0);if(remaining==0L){db.addFocusSession(account.id,selectedAssignmentId.ifBlank{null},minutes,minutes);perform(FeedbackKind.COMPLETE);deadline=0;onRefresh();break};delay(250)}}
    LazyColumn(contentPadding=PaddingValues(20.dp,8.dp,20.dp,90.dp),verticalArrangement=Arrangement.spacedBy(13.dp)){
    item{Box{OutlinedButton(enabled=deadline==0L,onClick={assignmentMenu=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.AutoMirrored.Filled.Assignment,null);Spacer(Modifier.width(7.dp));Text(assignmentNames[selectedAssignmentId]?:"General focus session")};DropdownMenu(assignmentMenu,{assignmentMenu=false}){DropdownMenuItem({Text("General focus session")},{selectedAssignmentId="";assignmentMenu=false});assignments.forEach{item->DropdownMenuItem({Text(item.title)},{selectedAssignmentId=item.id;minutes=item.estimateMinutes.coerceIn(5,45);assignmentMenu=false})}}}}
    item{Surface(color=HubNavy,shape=RoundedCornerShape(24.dp)){Column(Modifier.fillMaxWidth().padding(22.dp),horizontalAlignment=Alignment.CenterHorizontally){Icon(Icons.Default.Timer,null,tint=HubGold,modifier=Modifier.size(40.dp));Text(if(deadline==0L)"$minutes:00" else "%02d:%02d".format(remaining/60000,(remaining/1000)%60),color=Color.White,style=MaterialTheme.typography.displayMedium,fontWeight=FontWeight.Bold);Text(if(deadline==0L)assignmentNames[selectedAssignmentId]?.let{"Focus on $it"}?:"Choose a quiet focus session" else "Timer catches up after screen locks",color=Color.White.copy(alpha=.7f));Spacer(Modifier.height(12.dp));Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){listOf(5,15,25,45).forEach{FilterChip(minutes==it,{if(deadline==0L)minutes=it},label={Text("$it")})}};Spacer(Modifier.height(10.dp));Button(onClick={if(deadline==0L){deadline=SystemClock.elapsedRealtime()+minutes*60_000L;perform(FeedbackKind.CONFIRM)}else deadline=0},colors=ButtonDefaults.buttonColors(containerColor=HubGold,contentColor=HubNavy)){Text(if(deadline==0L)"Start" else "Stop")}}}}
    item{Text("Recent sessions",fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleLarge)}
    if(history.isEmpty())item{ToolEmpty("No completed focus sessions")}
    items(history.take(20)){Text("${it.completedMinutes} minutes · ${it.assignmentId?.let(assignmentNames::get)?:"General focus"} · ${formatMoment(it.completedAt)}",modifier=Modifier.fillMaxWidth().background(HubIvory,RoundedCornerShape(15.dp)).padding(14.dp))}
    }}

@Composable
private fun JournalTool(db:AppDatabase,account:Account,refresh:Int,onRefresh:()->Unit,perform:(FeedbackKind)->Unit){val entries=remember(refresh){db.journal(account.id)};var add by remember{mutableStateOf(false)};var editing by remember{mutableStateOf<JournalEntry?>(null)};LazyColumn(contentPadding=PaddingValues(20.dp,8.dp,20.dp,90.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
    item{Button(onClick={add=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Edit,null);Spacer(Modifier.width(8.dp));Text("New journal entry")}}
    if(entries.isEmpty())item{ToolEmpty("Your journal is private and empty")}
    items(entries,key={it.id}){e->Surface(color=HubIvory,shape=RoundedCornerShape(18.dp),modifier=Modifier.clickable{editing=e}){Column(Modifier.padding(15.dp)){Row{Column(Modifier.weight(1f)){Text(e.title,fontWeight=FontWeight.Bold);Text(LocalDate.ofEpochDay(e.epochDay).toString()+" · Mood ${e.mood}/5",color=HubNavy.copy(alpha=.6f))};IconButton(onClick={editing=e}){Icon(Icons.Default.Edit,"Edit")};IconButton(onClick={db.deleteJournal(e.id);perform(FeedbackKind.WARNING);onRefresh()}){Icon(Icons.Default.Delete,"Delete",tint=MaterialTheme.colorScheme.error)}};Text(e.body)}}}
    }
    if(add)JournalDialog(null,{add=false}){day,title,body,mood->db.addJournal(account.id,day,title,body,mood);perform(FeedbackKind.CONFIRM);add=false;onRefresh()}
    editing?.let{entry->JournalDialog(entry,{editing=null}){day,title,body,mood->db.updateJournal(entry.id,account.id,day,title,body,mood);perform(FeedbackKind.CONFIRM);editing=null;onRefresh()}}
}

@Composable private fun JournalDialog(existing:JournalEntry?,onDismiss:()->Unit,onSave:(Long,String,String,Int)->Unit){var title by remember(existing?.id){mutableStateOf(existing?.title.orEmpty())};var body by remember(existing?.id){mutableStateOf(existing?.body.orEmpty())};var mood by remember(existing?.id){mutableFloatStateOf(existing?.mood?.toFloat()?:3f)};var dayText by remember(existing?.id){mutableStateOf(LocalDate.ofEpochDay(existing?.epochDay?:LocalDate.now().toEpochDay()).toString())};val validDay=runCatching{LocalDate.parse(dayText).toEpochDay()}.getOrNull();AlertDialog(onDismissRequest=onDismiss,title={Text(if(existing==null)"Journal entry" else "Edit journal entry")},text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(10.dp)){OutlinedTextField(title,{title=it},label={Text("Title")});OutlinedTextField(body,{body=it},label={Text("Notes")},minLines=4);OutlinedTextField(dayText,{dayText=it},label={Text("Date · YYYY-MM-DD")},isError=validDay==null);Text("Mood ${mood.toInt()}/5");Slider(mood,{mood=it},valueRange=1f..5f,steps=3)}},confirmButton={Button(enabled=title.isNotBlank()&&validDay!=null,onClick={onSave(validDay!!,title,body,mood.toInt())}){Text("Save")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})}

@Composable
private fun ScannerTool(db:AppDatabase,account:Account,refresh:Int,onRefresh:()->Unit,perform:(FeedbackKind)->Unit){val context=LocalContext.current;val scans=remember(refresh){db.scans(account.id)};var status by remember{mutableStateOf("Choose a clear printed page. Recognition runs on this device and everything is editable before use.")};var latestText by remember{mutableStateOf("")};var latestUri by remember{mutableStateOf("")};val recognizer=remember{TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)};DisposableEffect(Unit){onDispose{recognizer.close()}};val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null){runCatching{context.contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)};latestUri=uri.toString();status="Recognizing text…";runCatching{InputImage.fromFilePath(context,uri)}.onSuccess{image->recognizer.process(image).addOnSuccessListener{text->latestText=text.text;status=if(text.text.isBlank())"No clear text was found. Try a sharper image." else "Review the recognized text, then save it."}.addOnFailureListener{status="Recognition failed safely: ${it.message.orEmpty()}"}}}};LazyColumn(contentPadding=PaddingValues(20.dp,8.dp,20.dp,90.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
    item{ToolInfo(Icons.Default.DocumentScanner,"On-device scanner",status)}
    item{Button(onClick={picker.launch(arrayOf("image/*"))},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.ImageSearch,null);Spacer(Modifier.width(8.dp));Text("Choose page image")}}
    if(latestText.isNotBlank())item{Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(latestText,{latestText=it},label={Text("Recognized text")},modifier=Modifier.fillMaxWidth(),minLines=5);Button(onClick={db.addScan(account.id,latestUri,latestText);perform(FeedbackKind.CONFIRM);latestText="";latestUri="";status="Saved to scan history.";onRefresh()},modifier=Modifier.fillMaxWidth()){Text("Save reviewed text")}}}
    item{Text("Scan history",fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleLarge)}
    if(scans.isEmpty())item{ToolEmpty("No saved scans")}
    items(scans.take(20)){s->Surface(color=HubIvory,shape=RoundedCornerShape(16.dp)){Column(Modifier.padding(14.dp)){Text(formatMoment(s.createdAt),fontWeight=FontWeight.Bold);Text(s.recognizedText,maxLines=4)}}}
    }}

@Composable private fun ToolInfo(icon:androidx.compose.ui.graphics.vector.ImageVector,title:String,body:String){Surface(color=HubGold.copy(alpha=.15f),shape=RoundedCornerShape(20.dp)){Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.Top){Icon(icon,null,tint=HubNavy);Spacer(Modifier.width(11.dp));Column{Text(title,fontWeight=FontWeight.Bold);Text(body,color=HubNavy.copy(alpha=.72f))}}}}
@Composable private fun ToolEmpty(text:String){Text(text,modifier=Modifier.fillMaxWidth().background(HubIvory,RoundedCornerShape(18.dp)).padding(22.dp),color=HubNavy.copy(alpha=.6f))}
private fun formatMoment(value:Long)=DateTimeFormatter.ofPattern("d MMM · h:mm a").format(Instant.ofEpochMilli(value).atZone(ZoneId.systemDefault()))
