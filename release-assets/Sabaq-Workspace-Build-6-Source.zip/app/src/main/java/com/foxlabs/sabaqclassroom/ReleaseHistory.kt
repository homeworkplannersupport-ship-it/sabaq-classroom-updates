package com.foxlabs.sabaqclassroom

data class ReleaseLog(
    val buildNumber: Int,
    val versionName: String,
    val title: String,
    val status: String,
    val changes: List<String>
)

object ReleaseHistory {
    val entries = listOf(
        ReleaseLog(
            6,
            "0.6.0-alpha-build-6",
            "Mishkaat classroom workspace",
            "Published pre-release",
            listOf(
                "A verified Sabaq Workspace server account is now required before any app features can be used; the offline administrator bypass is removed.",
                "The approved owner can securely activate the first administrator account once, then invite teachers, students, and guardians by verified Google email.",
                "Every class opens into a dedicated Stream, Classwork, People, and Grades workspace with role-specific controls.",
                "Classwork is searchable and grouped into Sabaq-friendly subject topics, with upcoming work surfaced in each class stream.",
                "Teachers get server-backed announcements, assignment publishing and revision, rosters, progress records, completion gradebook summaries, and private review queues.",
                "Students get per-class hand-in status, private feedback, reminders, submission receipts, and an account-synced view across devices.",
                "Administrator access changes, guardian links, classroom rosters, student transfers, and classroom lifecycle changes now use audited Firebase operations.",
                "Teaching teams can now share a classroom as co-teachers, while the server protects every class from being left without a teacher.",
                "Assignments and announcements support up to ten protected images or documents, secure previews, scheduling, revisions, pinning, archiving, and per-post discussion locks.",
                "Public class discussions and private student-teacher comments include timestamps, moderation, audit records, and privacy-safe notifications.",
                "Class owners can enable optional points; teachers can privately grade or return work, while students and approved guardians see only their own results.",
                "The role-aware home stream now surfaces recent announcements and newly published classwork across the workspace.",
                "A warmer Mishkaat-inspired navy, ivory, gold, and sage design now runs through the app, with a one-time What’s New card after each installed update.",
                "Offline classroom data remains readable, while writes clearly wait for a live connection so the app never falsely claims work was delivered."
            )
        ),
        ReleaseLog(
            5,
            "0.5.0-alpha-build-5",
            "Live classroom servers",
            "In development",
            listOf(
                "The app is now named Sabaq Workspace while keeping the original navy-and-gold Sabaq logo, permanent package ID, and update certificate.",
                "Fresh installs can join with Google and an email-bound, one-time administrator invitation.",
                "The invited Google identity can be secured with a Sabaq password, used for returning email sign-in, and recovered through a private Firebase reset email.",
                "A returning server account rebuilds its active local profile and offline cache after reinstall instead of requiring old device data.",
                "Firebase custom claims remain the server authority for student, teacher, guardian, and administrator roles.",
                "Published assignments, rosters, announcements, progress, and submissions synchronize through Firestore with local caching.",
                "Teacher publications and student hand-ins use audited callable transactions with idempotency and revision-conflict protection.",
                "JPEG, PNG, WebP, PDF, and text attachments upload to role-protected Cloud Storage with a 15 MB limit.",
                "Private Firebase Cloud Messaging notifications register each signed-in device and contain no assignment or student details on the lock screen.",
                "Administrators can create Google invitations and server classrooms without giving the Android client any server credentials."
            )
        ),
        ReleaseLog(
            4,
            "0.4.0-alpha-build-4",
            "The classroom overhaul",
            "Published pre-release",
            listOf(
                "Dedicated grouped Settings menu for every account role.",
                "Installed version and build number are shown in the app.",
                "Versioned update history explains what changed in each build.",
                "Students get a prioritized workload dashboard, due-date plan, crowded-day warnings, classwork search, and private per-assignment reminder controls.",
                "Teachers get class workload intelligence, completion trends, students-needing-attention ranking, and upcoming pressure summaries.",
                "Teachers can return work, mark it complete with private feedback, and reuse an assignment as next week's draft.",
                "Guardians receive the same read-only workload picture for each linked student.",
                "Reminder notifications hide assignment details on the lock screen.",
                "Sync status clearly reports offline/local-only operation until the secured backend is configured.",
                "Production backend foundations now cover secure invitations, revisions, conflict checks, and privacy-safe notification delivery."
            )
        ),
        ReleaseLog(
            3,
            "0.3.0-alpha-build-3",
            "Assignment lifecycle",
            "Published pre-release",
            listOf(
                "Teachers can draft, schedule, publish, close, archive, and restore assignments.",
                "Eligible assignments can be edited with private revision snapshots.",
                "Students and guardians cannot see drafts, scheduled work, or archives."
            )
        ),
        ReleaseLog(
            2,
            "0.2.0-alpha-build-2",
            "Independent Sabaq Workspace foundation",
            "Published pre-release",
            listOf(
                "Permanent signing identity and dedicated GitHub update channel.",
                "Role-based local accounts, classrooms, assignments, submissions, reminders, planner tools, haptics, and original interaction cues.",
                "New package identity separated from the earlier Homework Planner app."
            )
        ),
        ReleaseLog(
            1,
            "0.1.0-alpha-build-1",
            "Initial preview",
            "Retired signing identity",
            listOf(
                "Early visual and navigation prototype.",
                "Requires a one-time uninstall before installing permanently signed Build 2."
            )
        )
    )

    fun forBuild(buildNumber: Int): ReleaseLog? = entries.firstOrNull { it.buildNumber == buildNumber }
}
