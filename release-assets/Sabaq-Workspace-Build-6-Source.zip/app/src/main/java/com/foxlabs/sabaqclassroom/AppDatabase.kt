package com.foxlabs.sabaqclassroom

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.util.UUID
import java.security.SecureRandom
import org.json.JSONArray
import org.json.JSONObject

class AppDatabase(context: Context) : SQLiteOpenHelper(context, "sabaq_classroom.db", null, 10), SyncQueueStore {
    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE accounts(id TEXT PRIMARY KEY, display_name TEXT NOT NULL, username TEXT NOT NULL UNIQUE COLLATE NOCASE, role TEXT NOT NULL, password_hash BLOB NOT NULL, password_salt BLOB NOT NULL, active INTEGER NOT NULL DEFAULT 1, created_at INTEGER NOT NULL)""")
        db.execSQL("""CREATE TABLE classrooms(id TEXT PRIMARY KEY, name TEXT NOT NULL, section TEXT NOT NULL, teacher_id TEXT NOT NULL REFERENCES accounts(id), archived INTEGER NOT NULL DEFAULT 0, grading_enabled INTEGER NOT NULL DEFAULT 0)""")
        db.execSQL("""CREATE TABLE memberships(classroom_id TEXT NOT NULL REFERENCES classrooms(id) ON DELETE CASCADE, account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE, PRIMARY KEY(classroom_id, account_id))""")
        db.execSQL("""CREATE TABLE assignments(id TEXT PRIMARY KEY, classroom_id TEXT NOT NULL REFERENCES classrooms(id) ON DELETE CASCADE, teacher_id TEXT NOT NULL REFERENCES accounts(id), title TEXT NOT NULL, instructions TEXT NOT NULL, subject TEXT NOT NULL, due_at INTEGER NOT NULL, estimate_minutes INTEGER NOT NULL, priority TEXT NOT NULL, state TEXT NOT NULL, created_at INTEGER NOT NULL, type TEXT NOT NULL DEFAULT 'Sabaq', steps TEXT NOT NULL DEFAULT '', attachment_uri TEXT NOT NULL DEFAULT '', publish_at INTEGER NOT NULL DEFAULT 0, updated_at INTEGER NOT NULL, revision INTEGER NOT NULL DEFAULT 1, attachment_uris TEXT NOT NULL DEFAULT '[]', points_possible INTEGER, comments_enabled INTEGER NOT NULL DEFAULT 1)""")
        db.execSQL("""CREATE TABLE submissions(id TEXT PRIMARY KEY, assignment_id TEXT NOT NULL REFERENCES assignments(id) ON DELETE CASCADE, student_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE, note TEXT NOT NULL, state TEXT NOT NULL, handed_in_at INTEGER, feedback TEXT NOT NULL, attachment_uri TEXT NOT NULL DEFAULT '', revision INTEGER NOT NULL DEFAULT 0, attachment_uris TEXT NOT NULL DEFAULT '[]', grade_points INTEGER, UNIQUE(assignment_id, student_id))""")
        db.execSQL("""CREATE TABLE personal_tasks(id TEXT PRIMARY KEY, owner_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE, title TEXT NOT NULL, due_at INTEGER NOT NULL, estimate_minutes INTEGER NOT NULL, completed INTEGER NOT NULL DEFAULT 0)""")
        createPlannerTables(db)
        createScannerTable(db)
        createCommunicationTables(db)
        createAssignmentHistoryTable(db)
        createSyncOutboxTable(db)
        createFederatedIdentityTable(db)
        createReminderPreferencesTable(db)
        db.execSQL("CREATE INDEX idx_assignments_classroom ON assignments(classroom_id, due_at)")
        db.execSQL("CREATE INDEX idx_submissions_student ON submissions(student_id, state)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if(oldVersion<2){
            db.execSQL("ALTER TABLE assignments ADD COLUMN type TEXT NOT NULL DEFAULT 'Sabaq'")
            db.execSQL("ALTER TABLE assignments ADD COLUMN steps TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE assignments ADD COLUMN attachment_uri TEXT NOT NULL DEFAULT ''")
            createPlannerTables(db)
        }
        if(oldVersion<3)createScannerTable(db)
        if(oldVersion<4){db.execSQL("ALTER TABLE submissions ADD COLUMN attachment_uri TEXT NOT NULL DEFAULT ''");createCommunicationTables(db)}
        if(oldVersion<5){
            db.execSQL("ALTER TABLE assignments ADD COLUMN publish_at INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE assignments ADD COLUMN updated_at INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE assignments ADD COLUMN revision INTEGER NOT NULL DEFAULT 1")
            db.execSQL("UPDATE assignments SET updated_at=created_at WHERE updated_at=0")
            createAssignmentHistoryTable(db)
        }
        if(oldVersion<6)createSyncOutboxTable(db)
        if(oldVersion<7)createFederatedIdentityTable(db)
        if(oldVersion<8)createReminderPreferencesTable(db)
        if(oldVersion<9)db.execSQL("ALTER TABLE submissions ADD COLUMN revision INTEGER NOT NULL DEFAULT 0")
        if(oldVersion<10){
            db.execSQL("ALTER TABLE classrooms ADD COLUMN grading_enabled INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE assignments ADD COLUMN attachment_uris TEXT NOT NULL DEFAULT '[]'")
            db.execSQL("ALTER TABLE assignments ADD COLUMN points_possible INTEGER")
            db.execSQL("ALTER TABLE assignments ADD COLUMN comments_enabled INTEGER NOT NULL DEFAULT 1")
            db.execSQL("ALTER TABLE submissions ADD COLUMN attachment_uris TEXT NOT NULL DEFAULT '[]'")
            db.execSQL("ALTER TABLE submissions ADD COLUMN grade_points INTEGER")
            upgradeCommunicationTables(db)
        }
    }

    private fun createPlannerTables(db:SQLiteDatabase){
        db.execSQL("""CREATE TABLE IF NOT EXISTS journal_entries(id TEXT PRIMARY KEY, owner_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE, epoch_day INTEGER NOT NULL, title TEXT NOT NULL, body TEXT NOT NULL, mood INTEGER NOT NULL, created_at INTEGER NOT NULL)""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS focus_sessions(id TEXT PRIMARY KEY, owner_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE, assignment_id TEXT, planned_minutes INTEGER NOT NULL, completed_minutes INTEGER NOT NULL, completed_at INTEGER NOT NULL)""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS progress_records(id TEXT PRIMARY KEY, student_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE, subject TEXT NOT NULL, criterion TEXT NOT NULL, level INTEGER NOT NULL, note TEXT NOT NULL, recorded_at INTEGER NOT NULL)""")
    }
    private fun createScannerTable(db:SQLiteDatabase){db.execSQL("""CREATE TABLE IF NOT EXISTS scan_history(id TEXT PRIMARY KEY,owner_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,image_uri TEXT NOT NULL,recognized_text TEXT NOT NULL,created_at INTEGER NOT NULL)""")}
    private fun createCommunicationTables(db:SQLiteDatabase){
        db.execSQL("""CREATE TABLE IF NOT EXISTS announcements(id TEXT PRIMARY KEY,classroom_id TEXT NOT NULL REFERENCES classrooms(id) ON DELETE CASCADE,author_id TEXT NOT NULL REFERENCES accounts(id),title TEXT NOT NULL,body TEXT NOT NULL,created_at INTEGER NOT NULL,attachment_uris TEXT NOT NULL DEFAULT '[]',publish_at INTEGER NOT NULL DEFAULT 0,updated_at INTEGER NOT NULL DEFAULT 0,pinned INTEGER NOT NULL DEFAULT 0,state TEXT NOT NULL DEFAULT 'PUBLISHED',comments_enabled INTEGER NOT NULL DEFAULT 1)""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS classroom_comments(id TEXT PRIMARY KEY,classroom_id TEXT NOT NULL REFERENCES classrooms(id) ON DELETE CASCADE,entity_type TEXT NOT NULL,entity_id TEXT NOT NULL,author_id TEXT NOT NULL REFERENCES accounts(id),visibility TEXT NOT NULL,student_id TEXT,body TEXT NOT NULL,created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL,removed INTEGER NOT NULL DEFAULT 0)""")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_comments_entity ON classroom_comments(entity_type,entity_id,created_at)")
        db.execSQL("""CREATE TABLE IF NOT EXISTS guardian_links(guardian_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,student_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,PRIMARY KEY(guardian_id,student_id))""")
    }
    private fun upgradeCommunicationTables(db:SQLiteDatabase){
        listOf(
            "ALTER TABLE announcements ADD COLUMN attachment_uris TEXT NOT NULL DEFAULT '[]'",
            "ALTER TABLE announcements ADD COLUMN publish_at INTEGER NOT NULL DEFAULT 0",
            "ALTER TABLE announcements ADD COLUMN updated_at INTEGER NOT NULL DEFAULT 0",
            "ALTER TABLE announcements ADD COLUMN pinned INTEGER NOT NULL DEFAULT 0",
            "ALTER TABLE announcements ADD COLUMN state TEXT NOT NULL DEFAULT 'PUBLISHED'",
            "ALTER TABLE announcements ADD COLUMN comments_enabled INTEGER NOT NULL DEFAULT 1"
        ).forEach(db::execSQL)
        db.execSQL("UPDATE announcements SET publish_at=created_at,updated_at=created_at WHERE publish_at=0")
        createCommunicationTables(db)
    }
    private fun createAssignmentHistoryTable(db:SQLiteDatabase){db.execSQL("""CREATE TABLE IF NOT EXISTS assignment_revisions(id TEXT PRIMARY KEY,assignment_id TEXT NOT NULL REFERENCES assignments(id) ON DELETE CASCADE,revision INTEGER NOT NULL,snapshot_json TEXT NOT NULL,edited_at INTEGER NOT NULL,editor_id TEXT NOT NULL REFERENCES accounts(id))""")}
    private fun createSyncOutboxTable(db:SQLiteDatabase){
        db.execSQL("""CREATE TABLE IF NOT EXISTS sync_outbox(idempotency_key TEXT PRIMARY KEY,entity_type TEXT NOT NULL,entity_id TEXT NOT NULL,operation TEXT NOT NULL,expected_revision INTEGER NOT NULL,payload_digest TEXT NOT NULL,state TEXT NOT NULL,attempts INTEGER NOT NULL,next_attempt_at INTEGER NOT NULL,server_revision INTEGER,error TEXT)""")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_sync_outbox_due ON sync_outbox(state,next_attempt_at)")
    }
    private fun createFederatedIdentityTable(db:SQLiteDatabase){
        db.execSQL("""CREATE TABLE IF NOT EXISTS federated_identity_links(firebase_uid TEXT PRIMARY KEY,account_id TEXT NOT NULL UNIQUE REFERENCES accounts(id) ON DELETE CASCADE,email TEXT NOT NULL,linked_at INTEGER NOT NULL)""")
    }
    private fun createReminderPreferencesTable(db:SQLiteDatabase){
        db.execSQL("""CREATE TABLE IF NOT EXISTS assignment_reminder_preferences(assignment_id TEXT NOT NULL REFERENCES assignments(id) ON DELETE CASCADE,account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,enabled INTEGER NOT NULL DEFAULT 1,lead_hours INTEGER NOT NULL DEFAULT 24,PRIMARY KEY(assignment_id,account_id))""")
    }

    override fun putIfAbsent(entry:OutboxEntry):Boolean = writableDatabase.insertWithOnConflict("sync_outbox",null,syncValues(entry),SQLiteDatabase.CONFLICT_IGNORE)!=-1L
    override fun find(idempotencyKey:String):OutboxEntry? = query("SELECT idempotency_key,entity_type,entity_id,operation,expected_revision,payload_digest,state,attempts,next_attempt_at,server_revision,error FROM sync_outbox WHERE idempotency_key=?",arrayOf(idempotencyKey),::syncEntryFromCursor).firstOrNull()
    override fun list():List<OutboxEntry> = query("SELECT idempotency_key,entity_type,entity_id,operation,expected_revision,payload_digest,state,attempts,next_attempt_at,server_revision,error FROM sync_outbox ORDER BY next_attempt_at,idempotency_key",map=::syncEntryFromCursor)
    override fun put(entry:OutboxEntry){writableDatabase.insertWithOnConflict("sync_outbox",null,syncValues(entry),SQLiteDatabase.CONFLICT_REPLACE)}
    override fun remove(idempotencyKey:String){writableDatabase.delete("sync_outbox","idempotency_key=?",arrayOf(idempotencyKey))}

    private fun syncValues(entry:OutboxEntry)=ContentValues().apply{
        put("idempotency_key",entry.change.idempotencyKey);put("entity_type",entry.change.entityType);put("entity_id",entry.change.entityId)
        put("operation",entry.change.operation.name);put("expected_revision",entry.change.expectedRevision);put("payload_digest",entry.change.payloadDigest)
        put("state",entry.state.name);put("attempts",entry.attempts);put("next_attempt_at",entry.nextAttemptAtMillis)
        if(entry.serverRevision==null)putNull("server_revision") else put("server_revision",entry.serverRevision)
        if(entry.error==null)putNull("error") else put("error",entry.error)
    }
    private fun syncEntryFromCursor(c:Cursor)=OutboxEntry(
        change=SyncChange(c.getString(0),c.getString(1),c.getString(2),SyncOperation.valueOf(c.getString(3)),c.getLong(4),c.getString(5)),
        state=OutboxState.valueOf(c.getString(6)),attempts=c.getInt(7),nextAttemptAtMillis=c.getLong(8),
        serverRevision=if(c.isNull(9))null else c.getLong(9),error=if(c.isNull(10))null else c.getString(10)
    )

    fun accountCount(): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM accounts", null).use { it.moveToFirst(); it.getInt(0) }

    fun createAccount(displayName: String, username: String, role: AccountRole, password: CharArray): Account {
        val cleanName = displayName.trim().also { require(it.length in 2..80) }
        val cleanUser = username.trim().lowercase().also { require(it.matches(Regex("[a-z0-9._-]{3,40}"))) { "Username must be 3–40 letters, numbers, dots, underscores, or dashes" } }
        val record = PasswordHasher.create(password)
        val account = Account(UUID.randomUUID().toString(), cleanName, cleanUser, role)
        writableDatabase.insertOrThrow("accounts", null, ContentValues().apply {
            put("id", account.id); put("display_name", account.displayName); put("username", account.username)
            put("role", account.role.name); put("password_hash", record.hash); put("password_salt", record.salt)
            put("active", 1); put("created_at", System.currentTimeMillis())
        })
        return account
    }

    fun authenticate(username: String, password: CharArray): Account? {
        return readableDatabase.query("accounts", arrayOf("id","display_name","username","role","password_hash","password_salt","active"), "username=?", arrayOf(username.trim()), null, null, null).use { c ->
            if (!c.moveToFirst() || c.getInt(6) == 0) { password.fill('\u0000'); return@use null }
            val ok = PasswordHasher.verify(password, c.getBlob(5), c.getBlob(4))
            if (ok) Account(c.getString(0), c.getString(1), c.getString(2), AccountRole.valueOf(c.getString(3)), true) else null
        }
    }

    fun accounts(): List<Account> = query("SELECT id,display_name,username,role,active FROM accounts ORDER BY role,display_name") { c ->
        Account(c.getString(0), c.getString(1), c.getString(2), AccountRole.valueOf(c.getString(3)), c.getInt(4) == 1)
    }

    fun account(id: String): Account? = query("SELECT id,display_name,username,role,active FROM accounts WHERE id=?", arrayOf(id)) { c ->
        Account(c.getString(0), c.getString(1), c.getString(2), AccountRole.valueOf(c.getString(3)), c.getInt(4) == 1)
    }.firstOrNull()

    fun accountForFirebaseUid(firebaseUid:String):Account? = query(
        "SELECT a.id,a.display_name,a.username,a.role,a.active FROM accounts a JOIN federated_identity_links f ON f.account_id=a.id WHERE f.firebase_uid=?",
        arrayOf(firebaseUid)
    ){c->Account(c.getString(0),c.getString(1),c.getString(2),AccountRole.valueOf(c.getString(3)),c.getInt(4)==1)}.firstOrNull()

    fun federatedIdentityForAccount(accountId:String):FederatedIdentityLink? = query(
        "SELECT firebase_uid,account_id,email,linked_at FROM federated_identity_links WHERE account_id=?",
        arrayOf(accountId)
    ){c->FederatedIdentityLink(c.getString(0),c.getString(1),c.getString(2),c.getLong(3))}.firstOrNull()

    fun linkFirebaseIdentity(accountId:String,firebaseUid:String,email:String){
        require(firebaseUid.isNotBlank()){"Firebase identity is missing"}
        require(account(accountId)?.active==true){"Only an active account can be linked"}
        val byUid=accountForFirebaseUid(firebaseUid)
        require(byUid==null||byUid.id==accountId){"This Google account is already linked to another Sabaq profile"}
        val existing=federatedIdentityForAccount(accountId)
        require(existing==null||existing.firebaseUid==firebaseUid){"This Sabaq profile is already linked to another Google account"}
        writableDatabase.insertWithOnConflict("federated_identity_links",null,ContentValues().apply{
            put("firebase_uid",firebaseUid);put("account_id",accountId);put("email",email.trim());put("linked_at",System.currentTimeMillis())
        },SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun localAccountIdForServerUid(firebaseUid:String):String = accountForFirebaseUid(firebaseUid)?.id ?: firebaseUid
    fun serverUidForAccount(accountId:String):String = federatedIdentityForAccount(accountId)?.firebaseUid ?: accountId

    fun upsertCloudProfile(firebaseUid:String,displayName:String,role:AccountRole,active:Boolean):Account{
        val localId=localAccountIdForServerUid(firebaseUid)
        val existing=account(localId)
        if(existing==null){
            val hash=ByteArray(32).also(SecureRandom()::nextBytes)
            val salt=ByteArray(24).also(SecureRandom()::nextBytes)
            writableDatabase.insertOrThrow("accounts",null,ContentValues().apply{
                put("id",localId);put("display_name",displayName.ifBlank{"Sabaq member"});put("username","cloud-${firebaseUid.take(24).lowercase()}")
                put("role",role.name);put("password_hash",hash);put("password_salt",salt);put("active",if(active)1 else 0);put("created_at",System.currentTimeMillis())
            })
        }else{
            writableDatabase.update("accounts",ContentValues().apply{put("display_name",displayName.ifBlank{existing.displayName});put("role",role.name);put("active",if(active)1 else 0)},"id=?",arrayOf(localId))
        }
        return account(localId)!!
    }

    fun upsertCloudClassroom(item:Classroom,memberServerUids:List<String>){
        val teacherLocalId=localAccountIdForServerUid(item.teacherId)
        if(account(teacherLocalId)==null)upsertCloudProfile(item.teacherId,"Sabaq teacher",AccountRole.TEACHER,true)
        val classValues=ContentValues().apply{put("id",item.id);put("name",item.name);put("section",item.section);put("teacher_id",teacherLocalId);put("archived",if(item.archived)1 else 0);put("grading_enabled",if(item.gradingEnabled)1 else 0)}
        if(writableDatabase.update("classrooms",classValues,"id=?",arrayOf(item.id))==0){
            writableDatabase.insertOrThrow("classrooms",null,classValues)
        }
        writableDatabase.beginTransaction()
        try{
            writableDatabase.delete("memberships","classroom_id=?",arrayOf(item.id))
            memberServerUids.distinct().forEach{uid->
                val localId=localAccountIdForServerUid(uid)
                if(account(localId)==null)upsertCloudProfile(uid,"Sabaq member",AccountRole.STUDENT,true)
                writableDatabase.insertWithOnConflict("memberships",null,ContentValues().apply{put("classroom_id",item.id);put("account_id",localId)},SQLiteDatabase.CONFLICT_IGNORE)
            }
            writableDatabase.setTransactionSuccessful()
        }finally{writableDatabase.endTransaction()}
    }

    fun upsertCloudAssignment(item:ClassroomAssignment){
        val teacherLocalId=localAccountIdForServerUid(item.teacherId)
        if(account(teacherLocalId)==null)upsertCloudProfile(item.teacherId,"Sabaq teacher",AccountRole.TEACHER,true)
        if(readableDatabase.rawQuery("SELECT COUNT(*) FROM classrooms WHERE id=?",arrayOf(item.classroomId)).use{it.moveToFirst();it.getInt(0)==0}){
            upsertCloudClassroom(Classroom(item.classroomId,"Sabaq classroom","Online",item.teacherId),emptyList())
        }
        val assignmentValues=ContentValues().apply{
            put("id",item.id);put("classroom_id",item.classroomId);put("teacher_id",teacherLocalId);put("title",item.title);put("instructions",item.instructions)
            put("subject",item.subject);put("due_at",item.dueAtMillis);put("estimate_minutes",item.estimateMinutes);put("priority",item.priority);put("state",item.state.name)
            put("created_at",item.createdAtMillis);put("type",item.type);put("steps",item.steps.joinToString("\n"));put("attachment_uri",item.attachmentUri)
            put("publish_at",item.publishAtMillis);put("updated_at",item.updatedAtMillis);put("revision",item.revision)
            put("attachment_uris",JSONArray(item.attachmentUris).toString());if(item.pointsPossible==null)putNull("points_possible")else put("points_possible",item.pointsPossible);put("comments_enabled",if(item.commentsEnabled)1 else 0)
        }
        if(writableDatabase.update("assignments",assignmentValues,"id=?",arrayOf(item.id))==0){
            writableDatabase.insertOrThrow("assignments",null,assignmentValues)
        }
    }

    fun upsertCloudSubmission(item:StudentSubmission){
        val studentLocalId=localAccountIdForServerUid(item.studentId)
        if(account(studentLocalId)==null)upsertCloudProfile(item.studentId,"Sabaq student",AccountRole.STUDENT,true)
        writableDatabase.insertWithOnConflict("submissions",null,ContentValues().apply{
            put("id",item.id);put("assignment_id",item.assignmentId);put("student_id",studentLocalId);put("note",item.note);put("state",item.state.name)
            if(item.handedInAtMillis==null)putNull("handed_in_at") else put("handed_in_at",item.handedInAtMillis)
            put("feedback",item.feedback);put("attachment_uri",item.attachmentUri);put("revision",item.revision);put("attachment_uris",JSONArray(item.attachmentUris).toString());if(item.gradePoints==null)putNull("grade_points")else put("grade_points",item.gradePoints)
        },SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun upsertCloudAnnouncement(item:Announcement){
        val authorLocalId=localAccountIdForServerUid(item.authorId)
        if(account(authorLocalId)==null)upsertCloudProfile(item.authorId,"Sabaq teacher",AccountRole.TEACHER,true)
        writableDatabase.insertWithOnConflict("announcements",null,ContentValues().apply{put("id",item.id);put("classroom_id",item.classroomId);put("author_id",authorLocalId);put("title",item.title);put("body",item.body);put("created_at",item.createdAt);put("attachment_uris",JSONArray(item.attachmentUris).toString());put("publish_at",item.publishAt);put("updated_at",item.updatedAt);put("pinned",if(item.pinned)1 else 0);put("state",item.state.name);put("comments_enabled",if(item.commentsEnabled)1 else 0)},SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun upsertCloudComment(item:ClassroomComment){
        val authorLocalId=localAccountIdForServerUid(item.authorId)
        if(account(authorLocalId)==null)upsertCloudProfile(item.authorId,"Sabaq member",AccountRole.STUDENT,true)
        val studentLocalId=item.studentId?.let(::localAccountIdForServerUid)
        writableDatabase.insertWithOnConflict("classroom_comments",null,ContentValues().apply{put("id",item.id);put("classroom_id",item.classroomId);put("entity_type",item.entityType);put("entity_id",item.entityId);put("author_id",authorLocalId);put("visibility",item.visibility.name);if(studentLocalId==null)putNull("student_id")else put("student_id",studentLocalId);put("body",item.body);put("created_at",item.createdAt);put("updated_at",item.updatedAt);put("removed",if(item.removed)1 else 0)},SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun upsertCloudProgress(item:ProgressRecord){
        val studentLocalId=localAccountIdForServerUid(item.studentId)
        if(account(studentLocalId)==null)upsertCloudProfile(item.studentId,"Sabaq student",AccountRole.STUDENT,true)
        writableDatabase.insertWithOnConflict("progress_records",null,ContentValues().apply{put("id",item.id);put("student_id",studentLocalId);put("subject",item.subject);put("criterion",item.criterion);put("level",item.level);put("note",item.note);put("recorded_at",item.recordedAt)},SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun deleteCloudAssignment(id:String){writableDatabase.delete("assignments","id=?",arrayOf(id))}
    fun deleteCloudSubmission(id:String){writableDatabase.delete("submissions","id=?",arrayOf(id))}
    fun deleteCloudAnnouncement(id:String){writableDatabase.delete("announcements","id=?",arrayOf(id))}
    fun deleteCloudComment(id:String){writableDatabase.delete("classroom_comments","id=?",arrayOf(id))}

    fun setAccountActive(id: String, active: Boolean) {
        writableDatabase.update("accounts", ContentValues().apply { put("active", if (active) 1 else 0) }, "id=?", arrayOf(id))
    }

    fun changePassword(account:Account,current:CharArray,replacement:CharArray){
        require(authenticate(account.username,current)?.id==account.id){"Current password was not accepted"}
        val record=PasswordHasher.create(replacement)
        writableDatabase.update("accounts",ContentValues().apply{put("password_hash",record.hash);put("password_salt",record.salt)},"id=?",arrayOf(account.id))
    }

    fun createClassroom(name: String, section: String, teacherId: String): Classroom {
        require(accounts().any { it.id == teacherId && it.role == AccountRole.TEACHER && it.active }) { "Choose an active teacher" }
        val item = Classroom(UUID.randomUUID().toString(), name.trim(), section.trim(), teacherId)
        writableDatabase.insertOrThrow("classrooms", null, ContentValues().apply {
            put("id", item.id); put("name", item.name); put("section", item.section); put("teacher_id", item.teacherId); put("archived", 0)
        })
        return item
    }

    fun updateClassroom(actor:Account,id:String,name:String,section:String){require(name.trim().length in 2..80);require(classroomsFor(actor).any{it.id==id}&&DomainPolicy.canManageClassroom(actor.role)){"Classroom access denied"};writableDatabase.update("classrooms",ContentValues().apply{put("name",name.trim());put("section",section.trim())},"id=?",arrayOf(id))}
    fun setClassroomArchived(actor:Account,id:String,archived:Boolean){require(classroomsFor(actor).any{it.id==id}&&DomainPolicy.canManageClassroom(actor.role)){"Classroom access denied"};writableDatabase.update("classrooms",ContentValues().apply{put("archived",if(archived)1 else 0)},"id=?",arrayOf(id))}

    fun classroomsFor(account: Account): List<Classroom> {
        val sql = when (account.role) {
            AccountRole.ADMIN -> "SELECT id,name,section,teacher_id,archived,grading_enabled FROM classrooms ORDER BY archived,name"
            AccountRole.TEACHER -> "SELECT c.id,c.name,c.section,c.teacher_id,c.archived,c.grading_enabled FROM classrooms c JOIN memberships m ON c.id=m.classroom_id WHERE m.account_id=? ORDER BY c.archived,c.name"
            else -> "SELECT c.id,c.name,c.section,c.teacher_id,c.archived,c.grading_enabled FROM classrooms c JOIN memberships m ON c.id=m.classroom_id WHERE m.account_id=? AND c.archived=0 ORDER BY c.name"
        }
        val args = if (account.role == AccountRole.ADMIN) emptyArray() else arrayOf(account.id)
        return query(sql, args) { c -> Classroom(c.getString(0), c.getString(1), c.getString(2), c.getString(3), c.getInt(4) == 1,c.getInt(5)==1) }
    }

    fun addMember(classroomId: String, studentId: String) {
        require(accounts().any { it.id == studentId && it.role == AccountRole.STUDENT && it.active }) { "Choose an active student" }
        require(readableDatabase.rawQuery("SELECT COUNT(*) FROM classrooms WHERE id=? AND archived=0",arrayOf(classroomId)).use{it.moveToFirst();it.getInt(0)>0}){"Choose an active classroom"}
        writableDatabase.insertWithOnConflict("memberships", null, ContentValues().apply { put("classroom_id", classroomId); put("account_id", studentId) }, SQLiteDatabase.CONFLICT_IGNORE)
    }

    fun moveMember(studentId:String,fromClassroomId:String,toClassroomId:String){
        require(fromClassroomId!=toClassroomId)
        writableDatabase.beginTransaction()
        try{addMember(toClassroomId,studentId);writableDatabase.delete("memberships","classroom_id=? AND account_id=?",arrayOf(fromClassroomId,studentId));writableDatabase.setTransactionSuccessful()}finally{writableDatabase.endTransaction()}
    }

    fun members(classroomId: String): List<Account> = query("SELECT a.id,a.display_name,a.username,a.role,a.active FROM accounts a JOIN memberships m ON a.id=m.account_id WHERE m.classroom_id=? ORDER BY a.display_name", arrayOf(classroomId)) { c ->
        Account(c.getString(0), c.getString(1), c.getString(2), AccountRole.valueOf(c.getString(3)), c.getInt(4) == 1)
    }

    fun publishAssignment(teacher: Account, classroomId: String, title: String, instructions: String, subject: String, dueAt: Long, estimateMinutes: Int, priority: String,type:String="Sabaq",steps:List<String> = emptyList(),attachmentUri:String="",state:AssignmentState=AssignmentState.PUBLISHED,publishAt:Long=0L): ClassroomAssignment {
        require(teacher.role == AccountRole.TEACHER || teacher.role == AccountRole.ADMIN)
        val classroom = classroomsFor(teacher).firstOrNull { it.id == classroomId && !it.archived } ?: error("Classroom access denied")
        val teacherId = if (teacher.role == AccountRole.ADMIN) classroom.teacherId else teacher.id
        require(state in setOf(AssignmentState.DRAFT,AssignmentState.SCHEDULED,AssignmentState.PUBLISHED))
        require(title.trim().length in 2..120&&subject.trim().isNotBlank()&&dueAt>System.currentTimeMillis())
        val now=System.currentTimeMillis();val availableAt=when(state){AssignmentState.SCHEDULED->publishAt.also{require(it>now&&it<dueAt){"Scheduled publication must be before the due time"}};AssignmentState.PUBLISHED->now;else->0L}
        val item = ClassroomAssignment(UUID.randomUUID().toString(), classroomId, teacherId, title.trim(), instructions.trim(), subject.trim(), dueAt, estimateMinutes.coerceIn(5,600), priority, state, now,type,steps,attachmentUri,availableAt,now,1)
        writableDatabase.insertOrThrow("assignments", null, ContentValues().apply {
            put("id", item.id); put("classroom_id", item.classroomId); put("teacher_id", item.teacherId); put("title", item.title)
            put("instructions", item.instructions); put("subject", item.subject); put("due_at", item.dueAtMillis); put("estimate_minutes", item.estimateMinutes)
            put("priority", item.priority); put("state", item.state.name); put("created_at", item.createdAtMillis);put("type",item.type);put("steps",item.steps.joinToString("\n"));put("attachment_uri",item.attachmentUri);put("publish_at",item.publishAtMillis);put("updated_at",item.updatedAtMillis);put("revision",item.revision)
        })
        return item
    }

    fun assignmentsFor(account: Account): List<ClassroomAssignment> {
        promoteScheduledAssignments()
        val classroomIds = classroomsFor(account).map { it.id }
        if (classroomIds.isEmpty()) return emptyList()
        val placeholders = classroomIds.joinToString(",") { "?" }
        val visibility=if(account.role==AccountRole.STUDENT||account.role==AccountRole.GUARDIAN)" AND state IN ('PUBLISHED','CLOSED')" else " AND state!='ARCHIVED'"
        return query("SELECT id,classroom_id,teacher_id,title,instructions,subject,due_at,estimate_minutes,priority,state,created_at,type,steps,attachment_uri,publish_at,updated_at,revision,attachment_uris,points_possible,comments_enabled FROM assignments WHERE classroom_id IN ($placeholders)$visibility ORDER BY due_at", classroomIds.toTypedArray(),::assignmentFromCursor)
    }

    fun managedAssignmentsFor(actor:Account):List<ClassroomAssignment>{require(DomainPolicy.canManageClassroom(actor.role));promoteScheduledAssignments();val ids=classroomsFor(actor).map{it.id};if(ids.isEmpty())return emptyList();val marks=ids.joinToString(","){"?"};return query("SELECT id,classroom_id,teacher_id,title,instructions,subject,due_at,estimate_minutes,priority,state,created_at,type,steps,attachment_uri,publish_at,updated_at,revision,attachment_uris,points_possible,comments_enabled FROM assignments WHERE classroom_id IN ($marks) ORDER BY state,due_at",ids.toTypedArray(),::assignmentFromCursor)}

    private fun assignmentForManagement(actor:Account,id:String):ClassroomAssignment{require(DomainPolicy.canManageClassroom(actor.role));return managedAssignmentsFor(actor).firstOrNull{it.id==id}?:error("Assignment access denied")}

    fun updateAssignment(actor:Account,assignmentId:String,title:String,instructions:String,subject:String,dueAt:Long,estimateMinutes:Int,priority:String,type:String,steps:List<String>,attachmentUri:String){
        val current=assignmentForManagement(actor,assignmentId);require(DomainPolicy.canEditAssignment(current)){"This assignment can no longer be edited"};require(title.trim().length in 2..120&&subject.trim().isNotBlank()&&dueAt>System.currentTimeMillis());writableDatabase.beginTransaction();try{recordAssignmentRevision(actor,current);writableDatabase.update("assignments",ContentValues().apply{put("title",title.trim());put("instructions",instructions.trim());put("subject",subject.trim());put("due_at",dueAt);put("estimate_minutes",estimateMinutes.coerceIn(5,600));put("priority",priority.trim());put("type",type.trim());put("steps",steps.map(String::trim).filter(String::isNotBlank).joinToString("\n"));put("attachment_uri",attachmentUri);put("updated_at",System.currentTimeMillis());put("revision",current.revision+1)},"id=?",arrayOf(assignmentId));writableDatabase.setTransactionSuccessful()}finally{writableDatabase.endTransaction()}
    }

    fun setAssignmentState(actor:Account,assignmentId:String,state:AssignmentState,publishAt:Long=0L){val current=assignmentForManagement(actor,assignmentId);require(DomainPolicy.canTransitionAssignment(current.state,state)){"Invalid assignment state change"};val now=System.currentTimeMillis();val availableAt=when(state){AssignmentState.SCHEDULED->publishAt.also{require(it>now&&it<current.dueAtMillis){"Scheduled publication must be before the due time"}};AssignmentState.PUBLISHED->now;else->0L};writableDatabase.beginTransaction();try{recordAssignmentRevision(actor,current);writableDatabase.update("assignments",ContentValues().apply{put("state",state.name);put("publish_at",availableAt);put("updated_at",now);put("revision",current.revision+1)},"id=?",arrayOf(assignmentId));writableDatabase.setTransactionSuccessful()}finally{writableDatabase.endTransaction()}}

    fun duplicateAssignmentAsDraft(actor:Account,assignmentId:String,dueAt:Long):ClassroomAssignment{
        val source=assignmentForManagement(actor,assignmentId)
        require(dueAt>System.currentTimeMillis()){"Choose a future due time"}
        return publishAssignment(actor,source.classroomId,source.title,source.instructions,source.subject,dueAt,source.estimateMinutes,source.priority,source.type,source.steps,source.attachmentUri,AssignmentState.DRAFT)
    }

    private fun promoteScheduledAssignments(){val now=System.currentTimeMillis();writableDatabase.update("assignments",ContentValues().apply{put("state",AssignmentState.PUBLISHED.name);put("updated_at",now)},"state=? AND publish_at>0 AND publish_at<=?",arrayOf(AssignmentState.SCHEDULED.name,now.toString()))}

    private fun recordAssignmentRevision(actor:Account,item:ClassroomAssignment){val snapshot=JSONObject().put("title",item.title).put("instructions",item.instructions).put("subject",item.subject).put("dueAt",item.dueAtMillis).put("estimateMinutes",item.estimateMinutes).put("priority",item.priority).put("state",item.state.name).put("type",item.type).put("steps",JSONArray(item.steps)).put("attachmentUri",item.attachmentUri).put("publishAt",item.publishAtMillis);writableDatabase.insertOrThrow("assignment_revisions",null,ContentValues().apply{put("id",UUID.randomUUID().toString());put("assignment_id",item.id);put("revision",item.revision);put("snapshot_json",snapshot.toString());put("edited_at",System.currentTimeMillis());put("editor_id",actor.id)})}

    fun assignmentRevisionCount(assignmentId:String):Int=readableDatabase.rawQuery("SELECT COUNT(*) FROM assignment_revisions WHERE assignment_id=?",arrayOf(assignmentId)).use{it.moveToFirst();it.getInt(0)}

    private fun assignmentFromCursor(c:Cursor):ClassroomAssignment{
        val legacy=c.getString(13)
        val attachments=jsonStringList(c.getString(17)).ifEmpty{listOfNotNull(legacy.takeIf(String::isNotBlank))}
        return ClassroomAssignment(c.getString(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5),c.getLong(6),c.getInt(7),c.getString(8),AssignmentState.valueOf(c.getString(9)),c.getLong(10),c.getString(11),c.getString(12).lines().filter(String::isNotBlank),legacy,c.getLong(14),c.getLong(15),c.getInt(16),attachments,if(c.isNull(18))null else c.getInt(18),c.getInt(19)==1)
    }

    private fun saveSubmission(student:Account,assignmentId:String,note:String,attachmentUri:String,state:SubmissionState,handedInAt:Long?){
        require(student.role==AccountRole.STUDENT)
        val assignment=assignmentsFor(student).firstOrNull{it.id==assignmentId}?:error("Assignment access denied")
        val existing=submissionFor(assignmentId,student.id)
        require(when(state){SubmissionState.STARTED->DomainPolicy.canSaveSubmissionDraft(assignment,existing);SubmissionState.HANDED_IN->DomainPolicy.canSubmit(assignment,existing);else->false}){"This submission cannot be changed now"}
        val values = ContentValues().apply {
            put("id", existing?.id ?: UUID.randomUUID().toString()); put("assignment_id", assignmentId); put("student_id", student.id)
            put("note", note.trim()); put("state", state.name);if(handedInAt==null)putNull("handed_in_at")else put("handed_in_at",handedInAt); put("feedback", existing?.feedback.orEmpty());put("attachment_uri",attachmentUri.ifBlank{existing?.attachmentUri.orEmpty()});put("revision",existing?.revision?:0)
        }
        writableDatabase.insertWithOnConflict("submissions", null, values, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun saveSubmissionDraft(student:Account,assignmentId:String,note:String,attachmentUri:String="")=saveSubmission(student,assignmentId,note,attachmentUri,SubmissionState.STARTED,null)

    fun handIn(student: Account, assignmentId: String, note: String,attachmentUri:String="") =
        saveSubmission(student,assignmentId,note,attachmentUri,SubmissionState.HANDED_IN,System.currentTimeMillis())

    fun unsubmit(student:Account,assignmentId:String){
        require(student.role==AccountRole.STUDENT)
        val assignment=assignmentsFor(student).firstOrNull{it.id==assignmentId}?:error("Assignment access denied")
        val existing=submissionFor(assignmentId,student.id)
        require(DomainPolicy.canUnsubmit(assignment,existing)){"This work can no longer be unsubmitted"}
        writableDatabase.update("submissions",ContentValues().apply{put("state",SubmissionState.STARTED.name);putNull("handed_in_at")},"assignment_id=? AND student_id=?",arrayOf(assignmentId,student.id))
    }

    fun submissionFor(assignmentId: String, studentId: String): StudentSubmission? = query("SELECT id,assignment_id,student_id,note,state,handed_in_at,feedback,attachment_uri,revision,attachment_uris,grade_points FROM submissions WHERE assignment_id=? AND student_id=?", arrayOf(assignmentId,studentId)) { c ->
        submissionFromCursor(c)
    }.firstOrNull()

    fun submissionsForAssignment(assignmentId: String): List<StudentSubmission> = query("SELECT id,assignment_id,student_id,note,state,handed_in_at,feedback,attachment_uri,revision,attachment_uris,grade_points FROM submissions WHERE assignment_id=? ORDER BY handed_in_at", arrayOf(assignmentId),::submissionFromCursor)

    private fun submissionFromCursor(c:Cursor):StudentSubmission{val legacy=c.getString(7);val attachments=jsonStringList(c.getString(9)).ifEmpty{listOfNotNull(legacy.takeIf(String::isNotBlank))};return StudentSubmission(c.getString(0),c.getString(1),c.getString(2),c.getString(3),SubmissionState.valueOf(c.getString(4)),if(c.isNull(5))null else c.getLong(5),c.getString(6),legacy,c.getInt(8),attachments,if(c.isNull(10))null else c.getInt(10))}

    fun reminderPreference(assignmentId:String,accountId:String):AssignmentReminderPreference = query(
        "SELECT assignment_id,account_id,enabled,lead_hours FROM assignment_reminder_preferences WHERE assignment_id=? AND account_id=?",
        arrayOf(assignmentId,accountId)
    ){c->AssignmentReminderPreference(c.getString(0),c.getString(1),c.getInt(2)==1,c.getInt(3))}.firstOrNull()
        ?: AssignmentReminderPreference(assignmentId,accountId)

    fun saveReminderPreference(preference:AssignmentReminderPreference){
        require(preference.leadHours in setOf(1,4,24,48)){"Choose a supported reminder time"}
        require(account(preference.accountId)?.role==AccountRole.STUDENT){"Only students can set assignment reminders"}
        require(assignmentsFor(account(preference.accountId)!!).any{it.id==preference.assignmentId}){"Assignment access denied"}
        writableDatabase.insertWithOnConflict("assignment_reminder_preferences",null,ContentValues().apply{
            put("assignment_id",preference.assignmentId);put("account_id",preference.accountId)
            put("enabled",if(preference.enabled)1 else 0);put("lead_hours",preference.leadHours)
        },SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun returnSubmission(actor: Account, submissionId: String, feedback: String) {
        reviewSubmission(actor,submissionId,SubmissionState.RETURNED,feedback)
    }

    fun reviewSubmission(actor:Account,submissionId:String,state:SubmissionState,feedback:String){
        require(state in setOf(SubmissionState.RETURNED,SubmissionState.COMPLETED)){"Choose return or complete"}
        val item=query("SELECT id,assignment_id,student_id,note,state,handed_in_at,feedback,attachment_uri,revision,attachment_uris,grade_points FROM submissions WHERE id=?",arrayOf(submissionId),::submissionFromCursor).firstOrNull()?:error("Submission not found")
        assignmentForManagement(actor,item.assignmentId)
        require(item.state in setOf(SubmissionState.HANDED_IN,SubmissionState.RETURNED)){"Only handed-in or returned work can be reviewed"}
        writableDatabase.update("submissions",ContentValues().apply{put("state",state.name);put("feedback",feedback.trim())},"id=?",arrayOf(submissionId))
    }

    fun addPersonalTask(ownerId: String, title: String, dueAt: Long, estimate: Int) {
        writableDatabase.insertOrThrow("personal_tasks", null, ContentValues().apply { put("id",UUID.randomUUID().toString()); put("owner_id",ownerId); put("title",title.trim()); put("due_at",dueAt); put("estimate_minutes",estimate.coerceIn(5,600)); put("completed",0) })
    }

    fun personalTasks(ownerId: String): List<PersonalTask> = query("SELECT id,owner_id,title,due_at,estimate_minutes,completed FROM personal_tasks WHERE owner_id=? ORDER BY completed,due_at", arrayOf(ownerId)) { c ->
        PersonalTask(c.getString(0),c.getString(1),c.getString(2),c.getLong(3),c.getInt(4),c.getInt(5)==1)
    }

    fun togglePersonalTask(id: String, complete: Boolean) { writableDatabase.update("personal_tasks",ContentValues().apply { put("completed",if(complete)1 else 0) },"id=?",arrayOf(id)) }

    fun addJournal(ownerId:String,epochDay:Long,title:String,body:String,mood:Int){writableDatabase.insertOrThrow("journal_entries",null,ContentValues().apply{put("id",UUID.randomUUID().toString());put("owner_id",ownerId);put("epoch_day",epochDay);put("title",title.trim());put("body",body.trim());put("mood",mood.coerceIn(1,5));put("created_at",System.currentTimeMillis())})}
    fun updateJournal(id:String,ownerId:String,epochDay:Long,title:String,body:String,mood:Int){require(title.trim().isNotBlank());writableDatabase.update("journal_entries",ContentValues().apply{put("epoch_day",epochDay);put("title",title.trim());put("body",body.trim());put("mood",mood.coerceIn(1,5))},"id=? AND owner_id=?",arrayOf(id,ownerId))}
    fun journal(ownerId:String):List<JournalEntry> = query("SELECT id,owner_id,epoch_day,title,body,mood,created_at FROM journal_entries WHERE owner_id=? ORDER BY epoch_day DESC,created_at DESC",arrayOf(ownerId)){c->JournalEntry(c.getString(0),c.getString(1),c.getLong(2),c.getString(3),c.getString(4),c.getInt(5),c.getLong(6))}
    fun deleteJournal(id:String){writableDatabase.delete("journal_entries","id=?",arrayOf(id))}
    fun addFocusSession(ownerId:String,assignmentId:String?,planned:Int,completed:Int){writableDatabase.insertOrThrow("focus_sessions",null,ContentValues().apply{put("id",UUID.randomUUID().toString());put("owner_id",ownerId);put("assignment_id",assignmentId);put("planned_minutes",planned);put("completed_minutes",completed);put("completed_at",System.currentTimeMillis())})}
    fun focusSessions(ownerId:String):List<FocusSession> = query("SELECT id,owner_id,assignment_id,planned_minutes,completed_minutes,completed_at FROM focus_sessions WHERE owner_id=? ORDER BY completed_at DESC",arrayOf(ownerId)){c->FocusSession(c.getString(0),c.getString(1),if(c.isNull(2))null else c.getString(2),c.getInt(3),c.getInt(4),c.getLong(5))}
    fun addProgress(studentId:String,subject:String,criterion:String,level:Int,note:String){writableDatabase.insertOrThrow("progress_records",null,ContentValues().apply{put("id",UUID.randomUUID().toString());put("student_id",studentId);put("subject",subject.trim());put("criterion",criterion.trim());put("level",level.coerceIn(1,5));put("note",note.trim());put("recorded_at",System.currentTimeMillis())})}
    fun progress(studentId:String):List<ProgressRecord> = query("SELECT id,student_id,subject,criterion,level,note,recorded_at FROM progress_records WHERE student_id=? ORDER BY recorded_at DESC",arrayOf(studentId)){c->ProgressRecord(c.getString(0),c.getString(1),c.getString(2),c.getString(3),c.getInt(4),c.getString(5),c.getLong(6))}
    fun addScan(ownerId:String,imageUri:String,text:String){writableDatabase.insertOrThrow("scan_history",null,ContentValues().apply{put("id",UUID.randomUUID().toString());put("owner_id",ownerId);put("image_uri",imageUri);put("recognized_text",text);put("created_at",System.currentTimeMillis())})}
    fun scans(ownerId:String):List<ScanRecord> = query("SELECT id,owner_id,image_uri,recognized_text,created_at FROM scan_history WHERE owner_id=? ORDER BY created_at DESC",arrayOf(ownerId)){c->ScanRecord(c.getString(0),c.getString(1),c.getString(2),c.getString(3),c.getLong(4))}
    fun addAnnouncement(actor:Account,classroomId:String,title:String,body:String){require(actor.role==AccountRole.TEACHER||actor.role==AccountRole.ADMIN);require(classroomsFor(actor).any{it.id==classroomId&&!it.archived});writableDatabase.insertOrThrow("announcements",null,ContentValues().apply{put("id",UUID.randomUUID().toString());put("classroom_id",classroomId);put("author_id",actor.id);put("title",title.trim());put("body",body.trim());put("created_at",System.currentTimeMillis())})}
    fun announcementsFor(account:Account):List<Announcement>{val ids=classroomsFor(account).map{it.id};if(ids.isEmpty())return emptyList();val marks=ids.joinToString(","){"?"};val visible=if(account.role in setOf(AccountRole.ADMIN,AccountRole.TEACHER))"" else " AND state='PUBLISHED'";return query("SELECT id,classroom_id,author_id,title,body,created_at,attachment_uris,publish_at,updated_at,pinned,state,comments_enabled FROM announcements WHERE classroom_id IN ($marks)$visible ORDER BY pinned DESC,publish_at DESC",ids.toTypedArray()){c->Announcement(c.getString(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getLong(5),jsonStringList(c.getString(6)),c.getLong(7),c.getLong(8),c.getInt(9)==1,runCatching{AnnouncementState.valueOf(c.getString(10))}.getOrDefault(AnnouncementState.PUBLISHED),c.getInt(11)==1)}}
    fun commentsFor(entityType:String,entityId:String,viewer:Account):List<ClassroomComment>{val allowed=classroomsFor(viewer).map{it.id};return query("SELECT id,classroom_id,entity_type,entity_id,author_id,visibility,student_id,body,created_at,updated_at,removed FROM classroom_comments WHERE entity_type=? AND entity_id=? ORDER BY created_at",arrayOf(entityType,entityId)){c->ClassroomComment(c.getString(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),CommentVisibility.valueOf(c.getString(5)),if(c.isNull(6))null else c.getString(6),c.getString(7),c.getLong(8),c.getLong(9),c.getInt(10)==1)}.filter{it.classroomId in allowed&&(it.visibility==CommentVisibility.PUBLIC||viewer.role in setOf(AccountRole.ADMIN,AccountRole.TEACHER)||it.studentId==viewer.id)}}
    fun linkGuardian(guardianId:String,studentId:String){require(accounts().any{it.id==guardianId&&it.role==AccountRole.GUARDIAN});require(accounts().any{it.id==studentId&&it.role==AccountRole.STUDENT});writableDatabase.insertWithOnConflict("guardian_links",null,ContentValues().apply{put("guardian_id",guardianId);put("student_id",studentId)},SQLiteDatabase.CONFLICT_IGNORE)}
    fun wards(guardianId:String):List<Account> = query("SELECT a.id,a.display_name,a.username,a.role,a.active FROM accounts a JOIN guardian_links g ON a.id=g.student_id WHERE g.guardian_id=? ORDER BY a.display_name",arrayOf(guardianId)){c->Account(c.getString(0),c.getString(1),c.getString(2),AccountRole.valueOf(c.getString(3)),c.getInt(4)==1)}
    fun guardiansFor(studentId:String):List<Account> = query("SELECT a.id,a.display_name,a.username,a.role,a.active FROM accounts a JOIN guardian_links g ON a.id=g.guardian_id WHERE g.student_id=? ORDER BY a.display_name",arrayOf(studentId)){c->Account(c.getString(0),c.getString(1),c.getString(2),AccountRole.valueOf(c.getString(3)),c.getInt(4)==1)}
    fun removeGuardianLink(guardianId:String,studentId:String){writableDatabase.delete("guardian_links","guardian_id=? AND student_id=?",arrayOf(guardianId,studentId))}

    fun exportPlanner(ownerId:String):String = JSONObject().apply{
        put("schema",1);put("package","com.foxlabs.sabaqclassroom");put("buildNumber",6);put("versionName","0.6.0-alpha-build-6");put("generatedAt",System.currentTimeMillis())
        put("tasks",JSONArray().apply{personalTasks(ownerId).forEach{put(JSONObject().put("title",it.title).put("dueAt",it.dueAtMillis).put("minutes",it.estimateMinutes).put("completed",it.completed))}})
        put("journal",JSONArray().apply{journal(ownerId).forEach{put(JSONObject().put("epochDay",it.epochDay).put("title",it.title).put("body",it.body).put("mood",it.mood))}})
        put("focus",JSONArray().apply{focusSessions(ownerId).forEach{put(JSONObject().put("planned",it.plannedMinutes).put("completed",it.completedMinutes).put("completedAt",it.completedAt))}})
        put("scans",JSONArray().apply{scans(ownerId).forEach{put(JSONObject().put("text",it.recognizedText).put("createdAt",it.createdAt))}})
    }.toString(2)

    fun restorePlanner(ownerId:String,jsonText:String){
        val root=JSONObject(jsonText);require(root.getInt("schema")==1&&root.getString("package")=="com.foxlabs.sabaqclassroom"){"Unsupported backup"}
        writableDatabase.beginTransaction()
        try{
            listOf("personal_tasks","journal_entries","focus_sessions","scan_history").forEach{writableDatabase.delete(it,"owner_id=?",arrayOf(ownerId))}
            root.getJSONArray("tasks").forEachObject{j->writableDatabase.insertOrThrow("personal_tasks",null,ContentValues().apply{put("id",UUID.randomUUID().toString());put("owner_id",ownerId);put("title",j.getString("title"));put("due_at",j.getLong("dueAt"));put("estimate_minutes",j.getInt("minutes"));put("completed",if(j.getBoolean("completed"))1 else 0)})}
            root.getJSONArray("journal").forEachObject{j->writableDatabase.insertOrThrow("journal_entries",null,ContentValues().apply{put("id",UUID.randomUUID().toString());put("owner_id",ownerId);put("epoch_day",j.getLong("epochDay"));put("title",j.getString("title"));put("body",j.getString("body"));put("mood",j.getInt("mood"));put("created_at",System.currentTimeMillis())})}
            root.getJSONArray("focus").forEachObject{j->writableDatabase.insertOrThrow("focus_sessions",null,ContentValues().apply{put("id",UUID.randomUUID().toString());put("owner_id",ownerId);putNull("assignment_id");put("planned_minutes",j.getInt("planned"));put("completed_minutes",j.getInt("completed"));put("completed_at",j.getLong("completedAt"))})}
            root.getJSONArray("scans").forEachObject{j->writableDatabase.insertOrThrow("scan_history",null,ContentValues().apply{put("id",UUID.randomUUID().toString());put("owner_id",ownerId);put("image_uri","");put("recognized_text",j.getString("text"));put("created_at",j.getLong("createdAt"))})}
            writableDatabase.setTransactionSuccessful()
        }finally{writableDatabase.endTransaction()}
    }

    private inline fun JSONArray.forEachObject(block:(JSONObject)->Unit){for(i in 0 until length())block(getJSONObject(i))}

    private fun jsonStringList(value:String?):List<String>{if(value.isNullOrBlank())return emptyList();return runCatching{val array=JSONArray(value);buildList{for(i in 0 until array.length())add(array.getString(i))}}.getOrDefault(emptyList())}

    private fun <T> query(sql: String, args: Array<String> = emptyArray(), map: (Cursor) -> T): List<T> = readableDatabase.rawQuery(sql,args).use { c -> buildList { while(c.moveToNext()) add(map(c)) } }
}
