package com.foxlabs.sabaqclassroom

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.AudioManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import java.util.concurrent.atomic.AtomicLong

enum class FeedbackKind { SELECT, CONFIRM, COMPLETE, WARNING, ERROR }
enum class HapticLevel { OFF, LIGHT, STANDARD, STRONG }
enum class SoundLevel { OFF, SUBTLE, FULL }

data class FeedbackSettings(
    val haptics: HapticLevel = HapticLevel.STANDARD,
    val sounds: SoundLevel = SoundLevel.OFF
)

class FeedbackPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("sabaq_feedback", Context.MODE_PRIVATE)
    fun load() = FeedbackSettings(
        haptics = runCatching { HapticLevel.valueOf(prefs.getString("haptics", HapticLevel.STANDARD.name)!!) }.getOrDefault(HapticLevel.STANDARD),
        sounds = runCatching { SoundLevel.valueOf(prefs.getString("sounds", SoundLevel.OFF.name)!!) }.getOrDefault(SoundLevel.OFF)
    )
    fun save(value: FeedbackSettings) { prefs.edit().putString("haptics", value.haptics.name).putString("sounds", value.sounds.name).apply() }
}

object FeedbackEngine {
    private val lastSoundAt=AtomicLong(0)
    fun perform(context: Context, settings: FeedbackSettings, kind: FeedbackKind) {
        haptic(context, settings.haptics, kind)
        if (settings.sounds != SoundLevel.OFF) playOriginalCue(context,kind, settings.sounds)
    }

    private fun haptic(context: Context, level: HapticLevel, kind: FeedbackKind) {
        if (level == HapticLevel.OFF || Settings.System.getInt(context.contentResolver, Settings.System.HAPTIC_FEEDBACK_ENABLED, 1) == 0) return
        val vibrator = if (Build.VERSION.SDK_INT >= 31) context.getSystemService(VibratorManager::class.java).defaultVibrator else @Suppress("DEPRECATION") context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        if (!vibrator.hasVibrator()) return
        val base = when (level) { HapticLevel.LIGHT -> 35; HapticLevel.STANDARD -> 80; HapticLevel.STRONG -> 140; HapticLevel.OFF -> 0 }
        val duration = when (kind) { FeedbackKind.SELECT -> 8L; FeedbackKind.CONFIRM -> 14L; FeedbackKind.COMPLETE -> 22L; FeedbackKind.WARNING -> 28L; FeedbackKind.ERROR -> 36L }
        vibrator.vibrate(VibrationEffect.createOneShot(duration, base))
    }

    /** Short synthesized cues: original tones, no sampled vehicle or third-party audio. */
    private fun playOriginalCue(context:Context,kind: FeedbackKind, level: SoundLevel) {
        val audio=context.getSystemService(AudioManager::class.java)
        if(audio.ringerMode!=AudioManager.RINGER_MODE_NORMAL||audio.isMusicActive)return
        val now=android.os.SystemClock.elapsedRealtime();val previous=lastSoundAt.get();if(now-previous<180||!lastSoundAt.compareAndSet(previous,now))return
        val frequencies = when (kind) {
            FeedbackKind.SELECT -> doubleArrayOf(520.0)
            FeedbackKind.CONFIRM -> doubleArrayOf(440.0, 660.0)
            FeedbackKind.COMPLETE -> doubleArrayOf(392.0, 587.3, 783.9)
            FeedbackKind.WARNING -> doubleArrayOf(330.0, 277.2)
            FeedbackKind.ERROR -> doubleArrayOf(246.9, 196.0)
        }
        val durationMs = if (level == SoundLevel.SUBTLE) 85 else 135
        val volume = if (level == SoundLevel.SUBTLE) .055 else .095
        thread(name = "SabaqFeedback", isDaemon = true) {
            runCatching {
                val sampleRate = 44_100
                val frames = sampleRate * durationMs / 1000
                val samples = ShortArray(frames)
                for (i in samples.indices) {
                    val t = i.toDouble() / sampleRate
                    val attack = (i / (frames * .12)).coerceIn(0.0, 1.0)
                    val release = exp(-5.5 * i / frames.toDouble())
                    val tone = frequencies.mapIndexed { index, hz -> sin(2 * PI * hz * t) / (index + 1.2) }.sum()
                    samples[i] = (tone * attack * release * volume * Short.MAX_VALUE).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                }
                val track = AudioTrack.Builder()
                    .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                    .setAudioFormat(AudioFormat.Builder().setSampleRate(sampleRate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(samples.size * 2).setTransferMode(AudioTrack.MODE_STATIC).build()
                track.write(samples, 0, samples.size); track.play(); Thread.sleep(durationMs.toLong() + 30); track.release()
            }
        }
    }
}
