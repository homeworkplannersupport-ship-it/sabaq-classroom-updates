package com.foxlabs.sabaqclassroom

enum class AccountRole { ADMIN, TEACHER, STUDENT, GUARDIAN }
enum class AssignmentState { DRAFT, SCHEDULED, PUBLISHED, CLOSED, ARCHIVED }
enum class SubmissionState { NOT_STARTED, STARTED, HANDED_IN, RETURNED, COMPLETED }

data class Account(
    val id: String,
    val displayName: String,
    val username: String,
    val role: AccountRole,
    val active: Boolean = true
)

data class FederatedIdentityLink(
    val firebaseUid: String,
    val accountId: String,
    val email: String,
    val linkedAtMillis: Long
)

data class Classroom(
    val id: String,
    val name: String,
    val section: String,
    val teacherId: String,
    val archived: Boolean = false,
    val gradingEnabled: Boolean = false
)

data class ClassroomMember(val classroomId: String, val accountId: String)

data class ClassroomAssignment(
    val id: String,
    val classroomId: String,
    val teacherId: String,
    val title: String,
    val instructions: String,
    val subject: String,
    val dueAtMillis: Long,
    val estimateMinutes: Int,
    val priority: String,
    val state: AssignmentState,
    val createdAtMillis: Long,
    val type: String = "Sabaq",
    val steps: List<String> = emptyList(),
    val attachmentUri: String = "",
    val publishAtMillis: Long = 0L,
    val updatedAtMillis: Long = createdAtMillis,
    val revision: Int = 1,
    val attachmentUris: List<String> = listOfNotNull(attachmentUri.takeIf(String::isNotBlank)),
    val pointsPossible: Int? = null,
    val commentsEnabled: Boolean = true
)

data class StudentSubmission(
    val id: String,
    val assignmentId: String,
    val studentId: String,
    val note: String,
    val state: SubmissionState,
    val handedInAtMillis: Long?,
    val feedback: String,
    val attachmentUri: String = "",
    val revision: Int = 0,
    val attachmentUris: List<String> = listOfNotNull(attachmentUri.takeIf(String::isNotBlank)),
    val gradePoints: Int? = null
)

data class PersonalTask(
    val id: String,
    val ownerId: String,
    val title: String,
    val dueAtMillis: Long,
    val estimateMinutes: Int,
    val completed: Boolean
)

data class JournalEntry(val id:String,val ownerId:String,val epochDay:Long,val title:String,val body:String,val mood:Int,val createdAt:Long)
data class FocusSession(val id:String,val ownerId:String,val assignmentId:String?,val plannedMinutes:Int,val completedMinutes:Int,val completedAt:Long)
data class ProgressRecord(val id:String,val studentId:String,val subject:String,val criterion:String,val level:Int,val note:String,val recordedAt:Long)
data class ScanRecord(val id:String,val ownerId:String,val imageUri:String,val recognizedText:String,val createdAt:Long)
enum class AnnouncementState { SCHEDULED, PUBLISHED, ARCHIVED }
data class Announcement(
    val id:String,
    val classroomId:String,
    val authorId:String,
    val title:String,
    val body:String,
    val createdAt:Long,
    val attachmentUris:List<String> = emptyList(),
    val publishAt:Long = createdAt,
    val updatedAt:Long = createdAt,
    val pinned:Boolean = false,
    val state:AnnouncementState = AnnouncementState.PUBLISHED,
    val commentsEnabled:Boolean = true
)
enum class CommentVisibility { PUBLIC, PRIVATE }
data class ClassroomComment(
    val id:String,
    val classroomId:String,
    val entityType:String,
    val entityId:String,
    val authorId:String,
    val visibility:CommentVisibility,
    val studentId:String?,
    val body:String,
    val createdAt:Long,
    val updatedAt:Long,
    val removed:Boolean = false
)
data class GuardianLink(val guardianId:String,val studentId:String)

data class AssignmentReminderPreference(
    val assignmentId:String,
    val accountId:String,
    val enabled:Boolean = true,
    val leadHours:Int = 24
)

enum class WorkloadRisk { ON_TRACK, BUSY, NEEDS_ATTENTION }

data class StudentWorkload(
    val openCount:Int,
    val dueSoonCount:Int,
    val missingCount:Int,
    val returnedCount:Int,
    val handedInCount:Int,
    val completedCount:Int,
    val remainingMinutes:Int,
    val completionPercent:Int,
    val recommended:ClassroomAssignment?,
    val risk:WorkloadRisk,
    val message:String
)

data class StudentWorkloadRow(
    val student:Account,
    val workload:StudentWorkload
)
