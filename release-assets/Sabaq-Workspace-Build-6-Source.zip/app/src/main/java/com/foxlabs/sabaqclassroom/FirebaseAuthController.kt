package com.foxlabs.sabaqclassroom

import android.content.Context
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.Credential
import androidx.credentials.exceptions.NoCredentialException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.AuthCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.GoogleAuthProvider
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine

data class FirebaseIdentity(
    val uid: String,
    val displayName: String,
    val email: String,
    val photoUrl: String?
)

class FirebaseAuthController(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {
    fun currentIdentity(): FirebaseIdentity? = auth.currentUser?.toIdentity()

    suspend fun signIn(context: Context): FirebaseIdentity {
        val serverClientId = context.getString(R.string.default_web_client_id)
        require(serverClientId.isNotBlank()) {
            "Google sign-in is not configured for this build yet."
        }
        val credentialManager = CredentialManager.create(context)
        val credential = try {
            try {
                requestGoogleCredential(credentialManager, context, serverClientId, authorizedOnly = true)
            } catch (_: NoCredentialException) {
                requestGoogleCredential(credentialManager, context, serverClientId, authorizedOnly = false)
            }
        } catch (error: NoCredentialException) {
            throw IllegalStateException("No Google account is available on this device.", error)
        }
        require(
            credential is CustomCredential &&
                credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
        ) { "Google did not return a usable sign-in credential." }

        val googleCredential = GoogleIdTokenCredential.createFrom(credential.data)
        val firebaseCredential = GoogleAuthProvider.getCredential(googleCredential.idToken, null)
        return signInWithCredential(firebaseCredential).toIdentity()
    }

    private suspend fun requestGoogleCredential(
        credentialManager: CredentialManager,
        context: Context,
        serverClientId: String,
        authorizedOnly: Boolean
    ): Credential {
        val googleIdOption = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(authorizedOnly)
            .setServerClientId(serverClientId)
            .setAutoSelectEnabled(authorizedOnly)
            .build()
        val request = GetCredentialRequest.Builder()
            .addCredentialOption(googleIdOption)
            .build()
        return credentialManager.getCredential(context, request).credential
    }

    suspend fun signOut(context: Context) {
        auth.signOut()
        runCatching {
            CredentialManager.create(context)
                .clearCredentialState(ClearCredentialStateRequest())
        }
    }

    suspend fun signInWithEmail(email: String, password: String): FirebaseIdentity {
        require(password.isNotBlank()) { "Enter your email and password." }
        val normalizedEmail = AccountSecurityPolicy.normalizeEmail(email)
        return suspendCancellableCoroutine { continuation ->
            auth.signInWithEmailAndPassword(normalizedEmail, password).addOnCompleteListener { task ->
                if (!continuation.isActive) return@addOnCompleteListener
                val user = task.result?.user
                if (task.isSuccessful && user != null) continuation.resume(user.toIdentity())
                else continuation.resumeWithException(task.exception ?: IllegalStateException("Email sign-in was not accepted."))
            }
        }
    }

    suspend fun ensurePasswordForCurrentGoogleAccount(password: String) {
        AccountSecurityPolicy.requireNewPassword(password)
        val user = auth.currentUser ?: error("Sign in with Google first.")
        val email = user.email?.trim()?.lowercase().orEmpty()
        require(user.isEmailVerified && email.isNotBlank()) { "Google must provide a verified email first." }
        val hasPassword = user.providerData.any { it.providerId == EmailAuthProvider.PROVIDER_ID }
        suspendCancellableCoroutine<Unit> { continuation ->
            val completion: (com.google.android.gms.tasks.Task<*>) -> Unit = { task ->
                if (continuation.isActive) {
                    if (task.isSuccessful) continuation.resume(Unit)
                    else continuation.resumeWithException(task.exception ?: IllegalStateException("Could not secure this account with a password."))
                }
            }
            if (hasPassword) {
                user.updatePassword(password).addOnCompleteListener(completion)
            } else {
                user.linkWithCredential(EmailAuthProvider.getCredential(email, password)).addOnCompleteListener(completion)
            }
        }
    }

    suspend fun sendPasswordReset(email: String) {
        val normalizedEmail = AccountSecurityPolicy.normalizeEmail(email)
        suspendCancellableCoroutine<Unit> { continuation ->
            auth.sendPasswordResetEmail(normalizedEmail).addOnCompleteListener { task ->
                if (!continuation.isActive) return@addOnCompleteListener
                if (task.isSuccessful) continuation.resume(Unit)
                else continuation.resumeWithException(task.exception ?: IllegalStateException("Password reset could not be requested."))
            }
        }
    }

    private suspend fun signInWithCredential(credential: AuthCredential): FirebaseUser =
        suspendCancellableCoroutine { continuation ->
            auth.signInWithCredential(credential).addOnCompleteListener { task ->
                if (!continuation.isActive) return@addOnCompleteListener
                val user = if (task.isSuccessful) task.result?.user else null
                if (user != null) {
                    continuation.resume(user)
                } else {
                    continuation.resumeWithException(
                        task.exception ?: IllegalStateException("Firebase did not accept this Google account.")
                    )
                }
            }
        }
}

private fun FirebaseUser.toIdentity() = FirebaseIdentity(
    uid = uid,
    displayName = displayName.orEmpty(),
    email = email.orEmpty(),
    photoUrl = photoUrl?.toString()
)
