package com.foxlabs.sabaqclassroom

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.DateFormat
import java.time.format.DateTimeFormatter
import java.util.Date

private val InsightNavy=Color(0xFF102D46)
private val InsightGold=Color(0xFFD4A928)
private val InsightIvory=Color(0xFFFFF9EA)
private val InsightSage=Color(0xFF4E7557)
private val InsightWarning=Color(0xFF9D5C2F)

@Composable
fun StudentWorkloadOverview(workload:StudentWorkload,assignments:List<ClassroomAssignment>,submissions:Map<String,StudentSubmission?>){
    val days=remember(assignments,submissions){WorkloadEngine.byDay(assignments,submissions).entries.take(4)}
    val crowded=remember(assignments,submissions){WorkloadEngine.crowdedDays(assignments,submissions)}
    val riskColor=when(workload.risk){WorkloadRisk.ON_TRACK->InsightSage;WorkloadRisk.BUSY->InsightGold;WorkloadRisk.NEEDS_ATTENTION->Color(0xFFB14A40)}
    Card(colors=CardDefaults.cardColors(containerColor=InsightNavy),shape=RoundedCornerShape(28.dp)){
        Column(Modifier.fillMaxWidth().padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
            Row(verticalAlignment=Alignment.CenterVertically){
                Column(Modifier.weight(1f)){Text("YOUR WORKLOAD",color=InsightGold,fontSize=11.sp,fontWeight=FontWeight.ExtraBold);Text(workload.message,color=Color.White,fontWeight=FontWeight.Bold,fontSize=19.sp)}
                Surface(color=riskColor,shape=CircleShape){Icon(when(workload.risk){WorkloadRisk.ON_TRACK->Icons.Default.CheckCircle;WorkloadRisk.BUSY->Icons.Default.Schedule;WorkloadRisk.NEEDS_ATTENTION->Icons.Default.PriorityHigh},null,tint=Color.White,modifier=Modifier.padding(10.dp))}
            }
            LinearProgressIndicator(progress={workload.completionPercent/100f},modifier=Modifier.fillMaxWidth().height(8.dp),color=InsightGold,trackColor=Color.White.copy(alpha=.15f))
            Row(horizontalArrangement=Arrangement.spacedBy(18.dp)){WorkloadMini("Open",workload.openCount.toString());WorkloadMini("Time",WorkloadEngine.friendlyMinutes(workload.remainingMinutes));WorkloadMini("Done","${workload.completionPercent}%")}
            workload.recommended?.let{next->Surface(color=Color.White.copy(alpha=.10f),shape=RoundedCornerShape(18.dp)){Column(Modifier.fillMaxWidth().padding(14.dp)){Text("RECOMMENDED FIRST",color=InsightGold,fontSize=10.sp,fontWeight=FontWeight.ExtraBold);Text(next.title,color=Color.White,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis);Text("${next.subject} · ${next.estimateMinutes.coerceAtMost(25)}-minute first focus block",color=Color.White.copy(alpha=.72f),fontSize=12.sp)}}}
        }
    }
    if(days.isNotEmpty()){
        Card(colors=CardDefaults.cardColors(containerColor=InsightIvory),shape=RoundedCornerShape(22.dp)){
            Column(Modifier.fillMaxWidth().padding(17.dp),verticalArrangement=Arrangement.spacedBy(11.dp)){
                Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.DateRange,null,tint=InsightGold);Spacer(Modifier.width(8.dp));Text("Workload by due date",fontWeight=FontWeight.Bold,color=InsightNavy)}
                days.forEach{(day,items)->val minutes=items.sumOf{it.estimateMinutes};Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(day.format(DateTimeFormatter.ofPattern("EEE, d MMM")),fontWeight=FontWeight.SemiBold);Text("${items.size} ${if(items.size==1)"item" else "items"} · ${WorkloadEngine.friendlyMinutes(minutes)}",fontSize=12.sp,color=InsightNavy.copy(alpha=.62f))};if(day in crowded)Surface(color=InsightWarning.copy(alpha=.14f),shape=CircleShape){Text("Crowded",color=InsightWarning,fontSize=10.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(horizontal=9.dp,vertical=5.dp))}}
            }
        }
    }
}

}

@Composable private fun RowScope.WorkloadMini(label:String,value:String){Column(Modifier.weight(1f)){Text(value,color=Color.White,fontWeight=FontWeight.Bold,fontSize=17.sp);Text(label,color=Color.White.copy(alpha=.58f),fontSize=11.sp)}}

@Composable
fun TeacherInsightsScreen(db:AppDatabase,account:Account,refresh:Int){
    val classes=remember(refresh){db.classroomsFor(account).filterNot{it.archived}}
    var selectedClass by remember(classes){mutableStateOf(classes.firstOrNull()?.id.orEmpty())}
    val classroom=classes.firstOrNull{it.id==selectedClass}
    val students=remember(refresh,selectedClass){selectedClass.takeIf(String::isNotBlank)?.let(db::members).orEmpty()}
    val assignments=remember(refresh,selectedClass){db.managedAssignmentsFor(account).filter{it.classroomId==selectedClass&&it.state in setOf(AssignmentState.PUBLISHED,AssignmentState.CLOSED)}}
    val rows=remember(refresh,selectedClass,assignments,students){WorkloadEngine.classroom(students,assignments,db::submissionFor)}
    val attention=rows.filter{it.workload.risk==WorkloadRisk.NEEDS_ATTENTION}
    val openMinutes=rows.sumOf{it.workload.remainingMinutes}
    val average=if(rows.isEmpty())0 else rows.sumOf{it.workload.completionPercent}/rows.size
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(20.dp,20.dp,20.dp,96.dp),verticalArrangement=Arrangement.spacedBy(13.dp)){
        item{Text("Workload intelligence",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold,color=InsightNavy);Text("See pressure before it becomes a missed deadline",color=InsightNavy.copy(alpha=.65f))}
        if(classes.isEmpty())item{InsightEmpty("Create an active classroom to see workload insights.")}else{
            item{ClassSelector(classes,selectedClass){selectedClass=it}}
            item{Card(colors=CardDefaults.cardColors(containerColor=InsightNavy),shape=RoundedCornerShape(26.dp)){Column(Modifier.fillMaxWidth().padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text(classroom?.name.orEmpty(),color=Color.White,fontWeight=FontWeight.Bold,fontSize=21.sp);Text(classroom?.section.orEmpty(),color=Color.White.copy(alpha=.62f));Row(horizontalArrangement=Arrangement.spacedBy(12.dp)){TeacherMetric("Students",rows.size.toString(),Modifier.weight(1f));TeacherMetric("Attention",attention.size.toString(),Modifier.weight(1f));TeacherMetric("Completion","$average%",Modifier.weight(1f))};Text("${WorkloadEngine.friendlyMinutes(openMinutes)} of estimated student work remains across this class.",color=Color.White.copy(alpha=.75f),fontSize=12.sp)}}}
            if(attention.isNotEmpty()){item{InsightHeading("Needs attention")};items(attention,key={"attention-${it.student.id}"}){StudentRiskCard(it)}}
            val remainingRows=if(attention.isEmpty())rows else rows.filter{it.workload.risk!=WorkloadRisk.NEEDS_ATTENTION}
            item{InsightHeading(if(attention.isEmpty())"Every student" else "Rest of class")}
            if(rows.isEmpty())item{InsightEmpty("Add approved students to this classroom to compare workloads.")}else if(remainingRows.isEmpty())item{InsightEmpty("Every student currently appears in Needs attention.")}else items(remainingRows,key={it.student.id}){StudentRiskCard(it)}
            item{InsightHeading("Upcoming class load")}
            val upcoming=assignments.filter{it.dueAtMillis>=System.currentTimeMillis()}.sortedBy{it.dueAtMillis}.take(6)
            if(upcoming.isEmpty())item{InsightEmpty("No published work is currently upcoming.")}else items(upcoming,key={"load-${it.id}"}){assignment->
                val handed=db.submissionsForAssignment(assignment.id).count{it.state==SubmissionState.HANDED_IN||it.state==SubmissionState.COMPLETED}
                Surface(color=InsightIvory,shape=RoundedCornerShape(18.dp)){Row(Modifier.fillMaxWidth().padding(15.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(42.dp).background(InsightGold.copy(alpha=.18f),RoundedCornerShape(13.dp)),contentAlignment=Alignment.Center){Icon(Icons.Default.AssignmentTurnedIn,null,tint=InsightNavy)};Spacer(Modifier.width(11.dp));Column(Modifier.weight(1f)){Text(assignment.title,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis);Text("${assignment.estimateMinutes} min · ${DateFormat.getDateTimeInstance(DateFormat.MEDIUM,DateFormat.SHORT).format(Date(assignment.dueAtMillis))}",fontSize=12.sp,color=InsightNavy.copy(alpha=.6f))};Text("$handed/${students.size}",fontWeight=FontWeight.Bold,color=InsightSage)}}
            }
        }
    }
}

@Composable private fun ClassSelector(classes:List<Classroom>,selected:String,onSelect:(String)->Unit){var open by remember{mutableStateOf(false)};Box{OutlinedButton(onClick={open=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Groups,null);Spacer(Modifier.width(8.dp));Text(classes.firstOrNull{it.id==selected}?.name?:"Choose classroom",modifier=Modifier.weight(1f));Icon(Icons.Default.ExpandMore,null)};DropdownMenu(open,{open=false}){classes.forEach{item->DropdownMenuItem(text={Text(item.name)},onClick={onSelect(item.id);open=false})}}}}
@Composable private fun RowScope.TeacherMetric(label:String,value:String,modifier:Modifier){Surface(modifier,color=Color.White.copy(alpha=.10f),shape=RoundedCornerShape(15.dp)){Column(Modifier.padding(12.dp)){Text(value,color=Color.White,fontSize=20.sp,fontWeight=FontWeight.Bold);Text(label,color=Color.White.copy(alpha=.6f),fontSize=10.sp)}}}
@Composable private fun StudentRiskCard(row:StudentWorkloadRow){val color=when(row.workload.risk){WorkloadRisk.ON_TRACK->InsightSage;WorkloadRisk.BUSY->InsightGold;WorkloadRisk.NEEDS_ATTENTION->Color(0xFFB14A40)};Surface(color=InsightIvory,shape=RoundedCornerShape(19.dp)){Column(Modifier.fillMaxWidth().padding(15.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Row(verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(40.dp).background(color.copy(alpha=.15f),CircleShape),contentAlignment=Alignment.Center){Text(row.student.displayName.take(1).uppercase(),fontWeight=FontWeight.Bold,color=color)};Spacer(Modifier.width(11.dp));Column(Modifier.weight(1f)){Text(row.student.displayName,fontWeight=FontWeight.Bold);Text(row.workload.message,fontSize=12.sp,color=InsightNavy.copy(alpha=.62f),maxLines=2,overflow=TextOverflow.Ellipsis)};Text("${row.workload.completionPercent}%",fontWeight=FontWeight.Bold,color=color)};LinearProgressIndicator(progress={row.workload.completionPercent/100f},modifier=Modifier.fillMaxWidth().height(6.dp),color=color,trackColor=color.copy(alpha=.12f));Row(horizontalArrangement=Arrangement.spacedBy(14.dp)){Text("${row.workload.openCount} open",fontSize=11.sp);Text("${row.workload.missingCount} missing",fontSize=11.sp);Text(WorkloadEngine.friendlyMinutes(row.workload.remainingMinutes),fontSize=11.sp)}}}
}
@Composable private fun InsightHeading(text:String)=Text(text,style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold,color=InsightNavy)
@Composable private fun InsightEmpty(text:String){Surface(color=InsightIvory,shape=RoundedCornerShape(19.dp)){Text(text,modifier=Modifier.fillMaxWidth().padding(22.dp),color=InsightNavy.copy(alpha=.62f))}}
