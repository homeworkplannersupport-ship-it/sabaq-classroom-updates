package com.foxlabs.sabaqclassroom

object AccountSecurityPolicy {
    const val MIN_PASSWORD_LENGTH = 10

    fun normalizeEmail(email: String): String {
        val normalized = email.trim().lowercase()
        require(normalized.contains('@') && normalized.substringAfter('@').contains('.')) {
            "Enter the Google email used for this account."
        }
        return normalized
    }

    fun requireNewPassword(password: String) {
        require(password.length >= MIN_PASSWORD_LENGTH) {
            "Use at least $MIN_PASSWORD_LENGTH characters."
        }
    }
}
