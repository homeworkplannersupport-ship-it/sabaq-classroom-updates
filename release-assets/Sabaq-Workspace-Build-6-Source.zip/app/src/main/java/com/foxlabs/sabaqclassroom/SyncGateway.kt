package com.foxlabs.sabaqclassroom

enum class SyncAvailability { LOCAL_ONLY, CONFIGURED }
enum class SyncPhase { IDLE, SYNCING, RETRY_SCHEDULED, CONFLICT, ERROR }
enum class SyncOperation { CREATE, UPDATE, DELETE }
enum class OutboxState { PENDING, RETRY_WAIT, CONFLICT, REJECTED }

data class SyncStatus(
    val availability: SyncAvailability,
    val phase: SyncPhase,
    val pendingChanges: Int,
    val lastSuccessfulSyncAtMillis: Long?,
    val message: String
)

data class SyncChange(
    val idempotencyKey: String,
    val entityType: String,
    val entityId: String,
    val operation: SyncOperation,
    val expectedRevision: Long,
    val payloadDigest: String
) {
    init {
        require(idempotencyKey.isNotBlank())
        require(entityType.isNotBlank())
        require(entityId.isNotBlank())
        require(expectedRevision >= 0)
        require(payloadDigest.isNotBlank())
    }
}

data class OutboxEntry(
    val change: SyncChange,
    val state: OutboxState = OutboxState.PENDING,
    val attempts: Int = 0,
    val nextAttemptAtMillis: Long = 0,
    val serverRevision: Long? = null,
    val error: String? = null
)

sealed interface SyncPushResult {
    data class Accepted(val serverRevision: Long) : SyncPushResult
    data class Retryable(val reason: String) : SyncPushResult
    data class Conflict(val serverRevision: Long, val reason: String) : SyncPushResult
    data class Rejected(val reason: String) : SyncPushResult
}

interface SyncGateway {
    fun status(): SyncStatus
    suspend fun push(change: SyncChange): SyncPushResult
}

interface SyncQueueStore {
    fun putIfAbsent(entry: OutboxEntry): Boolean
    fun find(idempotencyKey: String): OutboxEntry?
    fun list(): List<OutboxEntry>
    fun put(entry: OutboxEntry)
    fun remove(idempotencyKey: String)
}

private class InMemorySyncQueueStore : SyncQueueStore {
    private val entries = linkedMapOf<String, OutboxEntry>()
    override fun putIfAbsent(entry: OutboxEntry): Boolean {
        if (entries.containsKey(entry.change.idempotencyKey)) return false
        entries[entry.change.idempotencyKey] = entry
        return true
    }
    override fun find(idempotencyKey: String) = entries[idempotencyKey]
    override fun list() = entries.values.toList()
    override fun put(entry: OutboxEntry) { entries[entry.change.idempotencyKey] = entry }
    override fun remove(idempotencyKey: String) { entries.remove(idempotencyKey) }
}

object LocalOnlySyncGateway : SyncGateway {
    override fun status() = SyncStatus(
        availability = SyncAvailability.LOCAL_ONLY,
        phase = SyncPhase.IDLE,
        pendingChanges = 0,
        lastSuccessfulSyncAtMillis = null,
        message = "Offline/local only — no production classroom backend is configured."
    )

    override suspend fun push(change: SyncChange): SyncPushResult =
        SyncPushResult.Rejected("Production sync is not configured.")
}

class SyncOutbox(
    private val initialRetryMillis: Long = 5_000,
    private val maximumRetryMillis: Long = 300_000,
    private val store: SyncQueueStore = InMemorySyncQueueStore()
) {
    init {
        require(initialRetryMillis > 0)
        require(maximumRetryMillis >= initialRetryMillis)
    }

    fun enqueue(change: SyncChange): Boolean {
        return store.putIfAbsent(OutboxEntry(change))
    }

    fun snapshot(): List<OutboxEntry> = store.list()

    fun due(nowMillis: Long): List<OutboxEntry> = store.list().filter {
        it.state == OutboxState.PENDING ||
            (it.state == OutboxState.RETRY_WAIT && it.nextAttemptAtMillis <= nowMillis)
    }

    fun recordResult(idempotencyKey: String, result: SyncPushResult, nowMillis: Long) {
        val current = store.find(idempotencyKey) ?: return
        when (result) {
            is SyncPushResult.Accepted -> store.remove(idempotencyKey)
            is SyncPushResult.Retryable -> {
                val attempts = current.attempts + 1
                store.put(current.copy(
                    state = OutboxState.RETRY_WAIT,
                    attempts = attempts,
                    nextAttemptAtMillis = nowMillis + retryDelay(attempts),
                    error = result.reason
                ))
            }
            is SyncPushResult.Conflict -> store.put(current.copy(
                state = OutboxState.CONFLICT,
                serverRevision = result.serverRevision,
                error = result.reason
            ))
            is SyncPushResult.Rejected -> store.put(current.copy(
                state = OutboxState.REJECTED,
                error = result.reason
            ))
        }
    }

    fun resolveConflict(idempotencyKey: String, replacement: SyncChange): Boolean {
        val current = store.find(idempotencyKey) ?: return false
        if (current.state != OutboxState.CONFLICT || replacement.idempotencyKey != idempotencyKey) return false
        store.put(OutboxEntry(replacement))
        return true
    }

    private fun retryDelay(attempts: Int): Long {
        val exponent = (attempts - 1).coerceIn(0, 30)
        var delay = initialRetryMillis
        repeat(exponent) {
            if (delay >= maximumRetryMillis / 2) return maximumRetryMillis
            delay *= 2
        }
        return delay.coerceAtMost(maximumRetryMillis)
    }
}
