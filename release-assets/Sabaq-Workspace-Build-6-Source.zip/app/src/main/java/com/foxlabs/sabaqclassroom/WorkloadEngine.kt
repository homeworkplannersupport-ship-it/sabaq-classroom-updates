package com.foxlabs.sabaqclassroom

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

object WorkloadEngine {
    private const val DAY = 24L * 60L * 60L * 1000L

    fun student(
        assignments:List<ClassroomAssignment>,
        submissions:Map<String,StudentSubmission?>,
        now:Long = System.currentTimeMillis()
    ):StudentWorkload {
        val visible=assignments.filter { it.state in setOf(AssignmentState.PUBLISHED,AssignmentState.CLOSED) }
        val sections=visible.associateWith { DomainPolicy.section(it,submissions[it.id],now) }
        val actionable=sections.filterValues { it in setOf(WorkSection.ASSIGNED,WorkSection.STARTED,WorkSection.DUE_SOON,WorkSection.MISSING,WorkSection.RETURNED) }
        val remaining=actionable.keys.sumOf { it.estimateMinutes.coerceIn(5,600) }
        val finished=sections.values.count { it==WorkSection.HANDED_IN||it==WorkSection.COMPLETED }
        val completion=if(visible.isEmpty())100 else (finished*100/visible.size).coerceIn(0,100)
        val recommended=actionable.keys.minWithOrNull(
            compareBy<ClassroomAssignment> { priorityRank(sections[it]?:WorkSection.ASSIGNED) }
                .thenBy { it.dueAtMillis }
                .thenByDescending { priorityRank(it.priority) }
        )
        val missing=sections.values.count { it==WorkSection.MISSING }
        val dueSoon=sections.values.count { it==WorkSection.DUE_SOON }
        val returned=sections.values.count { it==WorkSection.RETURNED }
        val risk=when {
            missing>0||returned>1||remaining>=240 -> WorkloadRisk.NEEDS_ATTENTION
            dueSoon>=2||remaining>=120 -> WorkloadRisk.BUSY
            else -> WorkloadRisk.ON_TRACK
        }
        val message=when {
            missing>0 -> "$missing overdue ${if(missing==1) "assignment needs" else "assignments need"} attention"
            returned>0 -> "$returned returned ${if(returned==1) "assignment is" else "assignments are"} ready to revise"
            dueSoon>0 -> "$dueSoon due soon · about ${friendlyMinutes(remaining)} remaining"
            actionable.isEmpty() -> "All published work is handed in or complete"
            else -> "About ${friendlyMinutes(remaining)} of planned work remaining"
        }
        return StudentWorkload(
            openCount=actionable.size,
            dueSoonCount=dueSoon,
            missingCount=missing,
            returnedCount=returned,
            handedInCount=sections.values.count { it==WorkSection.HANDED_IN },
            completedCount=sections.values.count { it==WorkSection.COMPLETED },
            remainingMinutes=remaining,
            completionPercent=completion,
            recommended=recommended,
            risk=risk,
            message=message
        )
    }

    fun classroom(
        students:List<Account>,
        assignments:List<ClassroomAssignment>,
        submission:(assignmentId:String,studentId:String)->StudentSubmission?,
        now:Long = System.currentTimeMillis()
    ):List<StudentWorkloadRow> = students.map { student ->
        val states=assignments.associate { it.id to submission(it.id,student.id) }
        StudentWorkloadRow(student,student(assignments,states,now))
    }.sortedWith(
        compareByDescending<StudentWorkloadRow> { it.workload.risk.ordinal }
            .thenByDescending { it.workload.missingCount }
            .thenByDescending { it.workload.remainingMinutes }
            .thenBy { it.student.displayName }
    )

    fun byDay(assignments:List<ClassroomAssignment>,submissions:Map<String,StudentSubmission?>,zone:ZoneId=ZoneId.systemDefault()):Map<LocalDate,List<ClassroomAssignment>> =
        assignments.filter { assignment ->
            DomainPolicy.section(assignment,submissions[assignment.id]) !in setOf(WorkSection.HANDED_IN,WorkSection.COMPLETED)
        }.groupBy { Instant.ofEpochMilli(it.dueAtMillis).atZone(zone).toLocalDate() }.toSortedMap()

    fun crowdedDays(assignments:List<ClassroomAssignment>,submissions:Map<String,StudentSubmission?>,zone:ZoneId=ZoneId.systemDefault()):Set<LocalDate> =
        byDay(assignments,submissions,zone).filterValues { day -> day.sumOf { it.estimateMinutes }>=120||day.size>=3 }.keys

    fun studyBlocks(minutes:Int):List<Int> {
        var left=minutes.coerceAtLeast(0)
        val blocks=mutableListOf<Int>()
        while(left>0){val block=left.coerceAtMost(25);blocks+=block;left-=block}
        return blocks
    }

    private fun priorityRank(section:WorkSection)=when(section){
        WorkSection.MISSING->0;WorkSection.RETURNED->1;WorkSection.DUE_SOON->2;WorkSection.STARTED->3;else->4
    }
    private fun priorityRank(priority:String)=when(priority.lowercase()){"urgent","high"->3;"important"->2;else->1}
    fun friendlyMinutes(minutes:Int):String=when { minutes<60 -> "$minutes min";minutes%60==0 -> "${minutes/60} hr";else -> "${minutes/60} hr ${minutes%60} min" }
}
