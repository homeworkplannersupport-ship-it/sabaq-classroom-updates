package com.foxlabs.sabaqclassroom

enum class WorkSection(val label:String){ASSIGNED("Assigned"),STARTED("Started"),DUE_SOON("Due soon"),MISSING("Missing"),HANDED_IN("Handed in"),RETURNED("Returned"),COMPLETED("Completed")}

object DomainPolicy {
    fun section(assignment:ClassroomAssignment,submission:StudentSubmission?,now:Long=System.currentTimeMillis()):WorkSection=when(submission?.state){
        SubmissionState.STARTED->WorkSection.STARTED
        SubmissionState.HANDED_IN->WorkSection.HANDED_IN
        SubmissionState.RETURNED->WorkSection.RETURNED
        SubmissionState.COMPLETED->WorkSection.COMPLETED
        null,SubmissionState.NOT_STARTED->when{assignment.dueAtMillis<now->WorkSection.MISSING;assignment.dueAtMillis-now<=24L*60L*60L*1000L->WorkSection.DUE_SOON;else->WorkSection.ASSIGNED}
    }

    fun canManageClassroom(role:AccountRole)=role==AccountRole.ADMIN||role==AccountRole.TEACHER
    fun canHandIn(role:AccountRole)=role==AccountRole.STUDENT
    fun nextAssignmentStates(from:AssignmentState):Set<AssignmentState> = when(from){
        AssignmentState.DRAFT->setOf(AssignmentState.SCHEDULED,AssignmentState.PUBLISHED,AssignmentState.ARCHIVED)
        AssignmentState.SCHEDULED->setOf(AssignmentState.DRAFT,AssignmentState.PUBLISHED,AssignmentState.ARCHIVED)
        AssignmentState.PUBLISHED->setOf(AssignmentState.CLOSED,AssignmentState.ARCHIVED)
        AssignmentState.CLOSED->setOf(AssignmentState.PUBLISHED,AssignmentState.ARCHIVED)
        AssignmentState.ARCHIVED->setOf(AssignmentState.DRAFT)
    }
    fun canTransitionAssignment(from:AssignmentState,to:AssignmentState)=to in nextAssignmentStates(from)
    fun canEditAssignment(assignment:ClassroomAssignment)=assignment.state in setOf(AssignmentState.DRAFT,AssignmentState.SCHEDULED,AssignmentState.PUBLISHED)
    fun canSaveSubmissionDraft(assignment:ClassroomAssignment,submission:StudentSubmission?):Boolean=
        assignment.state==AssignmentState.PUBLISHED&&submission?.state !in setOf(SubmissionState.HANDED_IN,SubmissionState.COMPLETED)
    fun canUnsubmit(assignment:ClassroomAssignment,submission:StudentSubmission?):Boolean=
        assignment.state==AssignmentState.PUBLISHED&&submission?.state==SubmissionState.HANDED_IN
    fun canSubmit(assignment:ClassroomAssignment,submission:StudentSubmission?):Boolean=
        assignment.state==AssignmentState.PUBLISHED&&submission?.state!=SubmissionState.COMPLETED
    fun canReadPrivateSubmission(viewer:Account,submission:StudentSubmission,teacherClassIds:Set<String>,assignment:ClassroomAssignment,guardianWardIds:Set<String> = emptySet()):Boolean=
        viewer.role==AccountRole.ADMIN||viewer.id==submission.studentId||(viewer.role==AccountRole.TEACHER&&assignment.classroomId in teacherClassIds)||(viewer.role==AccountRole.GUARDIAN&&submission.studentId in guardianWardIds)
}
