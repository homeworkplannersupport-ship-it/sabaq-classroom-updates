package com.foxlabs.sabaqclassroom

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

@Composable
fun BackupControls(db:AppDatabase,account:Account,onRestored:()->Unit){
    val context=LocalContext.current
    var status by remember{mutableStateOf("Backups include private planner tasks, journal, focus history, and recognized scan text. Accounts and classroom data are excluded.")}
    var pendingBackup by remember{mutableStateOf("")}
    val creator=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")){uri->if(uri!=null)runCatching{context.contentResolver.openOutputStream(uri,"wt")!!.bufferedWriter().use{it.write(pendingBackup)}}.onSuccess{status="Backup saved."}.onFailure{status="Backup failed: ${it.message.orEmpty()}"}}
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null)runCatching{context.contentResolver.openInputStream(uri)!!.bufferedReader().use{it.readText()}}.mapCatching{db.restorePlanner(account.id,it)}.onSuccess{status="Planner backup restored.";onRestored()}.onFailure{status="Restore stopped safely: ${it.message.orEmpty()}"}}
    Card{Column(Modifier.fillMaxWidth().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Text("Planner backup",style=MaterialTheme.typography.titleMedium);Text(status);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick={pendingBackup=db.exportPlanner(account.id);creator.launch("Sabaq-Workspace-Build-${BuildConfig.VERSION_CODE}-backup.json")},modifier=Modifier.weight(1f)){Icon(Icons.Default.FileDownload,null);Spacer(Modifier.width(5.dp));Text("Save")};OutlinedButton(onClick={picker.launch(arrayOf("application/json","text/plain"))},modifier=Modifier.weight(1f)){Icon(Icons.Default.FileUpload,null);Spacer(Modifier.width(5.dp));Text("Restore")}}}}
}
