package com.foxlabs.sabaqclassroom

import android.content.Context
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

data class UpdateInfo(
    val versionCode: Long,
    val versionName: String,
    val apkUrl: String,
    val sha256: String,
    val signingCertificateSha256: String,
    val notes: String
)

object UpdateManager {
    private const val FEED = "https://raw.githubusercontent.com/homeworkplannersupport-ship-it/sabaq-classroom-updates/main/update.json"
    private const val PACKAGE = "com.foxlabs.sabaqclassroom"

    fun installedVersionCode(context: Context): Long {
        val info = context.packageManager.getPackageInfo(context.packageName, 0)
        return if (Build.VERSION.SDK_INT >= 28) info.longVersionCode else @Suppress("DEPRECATION") info.versionCode.toLong()
    }

    fun check(): UpdateInfo {
        val connection = (URL(FEED).openConnection() as HttpURLConnection).apply {
            connectTimeout = 12_000
            readTimeout = 12_000
            requestMethod = "GET"
            setRequestProperty("Accept", "application/json")
        }
        require(connection.responseCode in 200..299) { "Update service returned ${connection.responseCode}" }
        val json = connection.inputStream.bufferedReader().use { JSONObject(it.readText()) }
        return validate(UpdateInfo(
            versionCode = json.getLong("versionCode"),
            versionName = json.getString("versionName"),
            apkUrl = json.getString("apkUrl"),
            sha256 = json.getString("sha256").lowercase(),
            signingCertificateSha256 = json.getString("signingCertificateSha256").lowercase(),
            notes = json.optString("notes")
        ))
    }

    fun downloadAndVerify(context: Context, update: UpdateInfo): File {
        validate(update)
        val folder = File(context.cacheDir, "updates").apply { mkdirs() }
        val target = File(folder, "Sabaq-Workspace-${update.versionName}.apk")
        val digest = MessageDigest.getInstance("SHA-256")
        val connection = (URL(update.apkUrl).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000
            readTimeout = 45_000
            instanceFollowRedirects = true
        }
        require(connection.responseCode in 200..299) { "Download failed (${connection.responseCode})" }
        connection.inputStream.use { input ->
            target.outputStream().use { output ->
                val buffer = ByteArray(64 * 1024)
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    digest.update(buffer, 0, count)
                    output.write(buffer, 0, count)
                }
            }
        }
        val actual = digest.digest().joinToString("") { "%02x".format(it) }
        require(actual == update.sha256) { target.delete(); "Downloaded file did not pass checksum verification" }
        val signatureFlags = if (Build.VERSION.SDK_INT >= 28) PackageManager.GET_SIGNING_CERTIFICATES else @Suppress("DEPRECATION") PackageManager.GET_SIGNATURES
        val archive = context.packageManager.getPackageArchiveInfo(target.absolutePath, signatureFlags)
        require(archive?.packageName == PACKAGE) { target.delete(); "Downloaded APK belongs to a different app" }
        val archiveCode = if (Build.VERSION.SDK_INT >= 28) archive.longVersionCode else @Suppress("DEPRECATION") archive.versionCode.toLong()
        require(archiveCode == update.versionCode) { target.delete(); "Downloaded APK version does not match the update feed" }
        val archiveCertificates = certificateDigests(archive)
        require(update.signingCertificateSha256 in archiveCertificates) { target.delete(); "Downloaded APK does not have the published Sabaq Workspace signing certificate" }
        val installed = context.packageManager.getPackageInfo(context.packageName, signatureFlags)
        require(certificateDigests(installed).any(archiveCertificates::contains)) {
            target.delete()
            "This installed copy uses the retired Build 1 signing identity. Export anything important, uninstall Sabaq Workspace once, then install Build ${update.versionCode} fresh. Later updates will install normally."
        }
        return target
    }

    internal fun validate(update:UpdateInfo):UpdateInfo{
        val uri=java.net.URI(update.apkUrl)
        require(uri.scheme=="https"&&uri.host=="github.com"&&uri.path.startsWith("/homeworkplannersupport-ship-it/sabaq-classroom-updates/releases/download/")){"Unexpected download location"}
        require(update.versionCode>0&&update.versionName.isNotBlank()){"Invalid update version"}
        require(update.sha256.matches(Regex("[0-9a-f]{64}"))){"Invalid update checksum"}
        require(update.signingCertificateSha256.matches(Regex("[0-9a-f]{64}"))){"Invalid signing certificate"}
        return update
    }

    @Suppress("DEPRECATION")
    private fun certificateDigests(info:PackageInfo):Set<String>{
        val signatures=if(Build.VERSION.SDK_INT>=28){
            info.signingInfo?.let{if(it.hasMultipleSigners())it.apkContentsSigners else it.signingCertificateHistory}.orEmpty()
        }else info.signatures.orEmpty()
        return signatures.mapTo(linkedSetOf()){signature->MessageDigest.getInstance("SHA-256").digest(signature.toByteArray()).joinToString(""){"%02x".format(it)}}
    }

    fun openInstaller(context: Context, apk: File) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", apk)
        context.startActivity(Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }
}
