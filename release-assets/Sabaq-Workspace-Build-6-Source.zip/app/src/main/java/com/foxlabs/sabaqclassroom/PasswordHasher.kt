package com.foxlabs.sabaqclassroom

import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

data class PasswordRecord(val salt: ByteArray, val hash: ByteArray)

object PasswordHasher {
    private const val ITERATIONS = 210_000
    private const val KEY_BITS = 256

    fun create(password: CharArray): PasswordRecord {
        require(password.size >= 10) { "Password must be at least 10 characters" }
        val salt = ByteArray(16).also(SecureRandom()::nextBytes)
        return PasswordRecord(salt, derive(password, salt))
    }

    fun verify(password: CharArray, salt: ByteArray, expected: ByteArray): Boolean =
        MessageDigest.isEqual(derive(password, salt), expected)

    private fun derive(password: CharArray, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(password, salt, ITERATIONS, KEY_BITS)
        return try { SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded }
        finally { spec.clearPassword(); password.fill('\u0000') }
    }
}
