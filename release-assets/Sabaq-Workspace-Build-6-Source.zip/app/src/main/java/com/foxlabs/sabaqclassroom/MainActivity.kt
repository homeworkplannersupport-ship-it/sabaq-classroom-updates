package com.foxlabs.sabaqclassroom

import android.os.Bundle
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.provider.CalendarContract
import android.icu.util.IslamicCalendar
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import com.google.firebase.storage.FirebaseStorage
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Assignment
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.automirrored.filled.ScheduleSend
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date
import java.util.Calendar
import java.io.File

// Mishkaat-inspired palette: prayer-hall teal, warm brass, parchment, and garden green.
private val Navy = Color(0xFF123C3A)
private val Gold = Color(0xFFC99A31)
private val Ivory = Color(0xFFFFFBF1)
private val Canvas = Color(0xFFF0F2EA)
private val Sage = Color(0xFF3D7457)
private val DeepTeal = Color(0xFF0A272A)
private val BUILD_NUMBER get() = BuildConfig.VERSION_CODE
private val VERSION_NAME get() = BuildConfig.VERSION_NAME
private const val SESSION_MAX_AGE = 12L*60L*60L*1000L

private data class NavItem(val id: String, val label: String, val icon: ImageVector)
private enum class ClassroomTab(val label:String){STREAM("Stream"),CLASSWORK("Classwork"),PEOPLE("People"),GRADES("Grades")}

class MainActivity : ComponentActivity() {
    private val destination = mutableStateOf<String?>(null)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        destination.value=intent.getStringExtra("destination")
        setContent { SabaqTheme { SabaqRoot(destination.value) } }
    }
    override fun onNewIntent(intent:Intent){super.onNewIntent(intent);setIntent(intent);destination.value=intent.getStringExtra("destination")}
}

@Composable
private fun SabaqTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Navy, onPrimary = Color.White, secondary = Gold, onSecondary = Navy,
            tertiary = Sage, background = Canvas, surface = Ivory, surfaceVariant = Color(0xFFE7E1D4),
            error = Color(0xFF9D2F2F)
        ),
        typography = Typography(
            headlineMedium = MaterialTheme.typography.headlineMedium.copy(fontWeight=FontWeight.Bold,letterSpacing=(-0.4).sp),
            titleLarge = MaterialTheme.typography.titleLarge.copy(fontWeight=FontWeight.Bold),
            bodyLarge = MaterialTheme.typography.bodyLarge.copy(lineHeight=23.sp),
            labelLarge = MaterialTheme.typography.labelLarge.copy(fontWeight=FontWeight.SemiBold)
        ),
        shapes = Shapes(
            extraSmall=RoundedCornerShape(8.dp),small=RoundedCornerShape(12.dp),
            medium=RoundedCornerShape(18.dp),large=RoundedCornerShape(24.dp),extraLarge=RoundedCornerShape(30.dp)
        ),
        content = content
    )
}

@Composable
private fun SabaqRoot(initialDestination:String?=null) {
    val context = LocalContext.current
    val db = remember { AppDatabase(context.applicationContext) }
    val authController = remember { FirebaseAuthController() }
    val classroomGateway = remember { FirebaseClassroomGateway(db) }
    val scope = rememberCoroutineScope()
    val sessionPrefs = remember { context.getSharedPreferences("sabaq_session", android.content.Context.MODE_PRIVATE) }
    val permissionPrefs = remember { context.getSharedPreferences("sabaq_permissions", android.content.Context.MODE_PRIVATE) }
    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        performNotificationFeedback(context, granted)
    }
    val requestNotifications = {
        if (android.os.Build.VERSION.SDK_INT >= 33 && androidx.core.content.ContextCompat.checkSelfPermission(context,android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
    }
    var refresh by remember { mutableIntStateOf(0) }
    var firebaseIdentity by remember { mutableStateOf(authController.currentIdentity()) }
    var googleBusy by remember { mutableStateOf(false) }
    var googleStatus by rememberSaveable { mutableStateOf("") }
    var cloudStatus by remember { mutableStateOf(classroomGateway.status()) }
    var current by remember(refresh,firebaseIdentity?.uid) {
        mutableStateOf(
            firebaseIdentity?.uid?.let(db::accountForFirebaseUid)?.takeIf { it.active }
        )
    }
    val saveSession:(Account)->Unit = { account ->
        sessionPrefs.edit().putString("account_id",account.id).putLong("last_seen",System.currentTimeMillis()).apply()
        current=account
    }
    val signInWithGoogle:()->Unit = googleSignIn@{
        if(googleBusy)return@googleSignIn
        scope.launch {
            googleBusy=true;googleStatus=""
            try{
                val identity=authController.signIn(context)
                firebaseIdentity=identity
                val linked=db.accountForFirebaseUid(identity.uid)?.takeIf{it.active}
                    ?: classroomGateway.restoreSignedInAccount(identity)
                if(linked==null){
                    googleStatus="Google verified ${identity.email.ifBlank{"this account"}}, but no active Sabaq role is linked yet. Enter the invitation issued for this email."
                }else{
                    saveSession(linked);googleStatus=""
                }
            }catch(error:Exception){googleStatus=friendlyGoogleAuthError(error)}
            finally{googleBusy=false}
        }
    }
    LaunchedEffect(Unit) {
        NotificationScheduler.createChannels(context)
        NotificationScheduler.scheduleDaily(context)
        if (!permissionPrefs.getBoolean("notification_prompted",false)) {
            permissionPrefs.edit().putBoolean("notification_prompted",true).apply()
            requestNotifications()
        }
    }
    LaunchedEffect(firebaseIdentity?.uid) {
        val identity=firebaseIdentity
        if(identity!=null&&current==null&&!googleBusy){
            googleBusy=true
            runCatching{classroomGateway.restoreSignedInAccount(identity)}
                .onSuccess{account->if(account!=null){saveSession(account);googleStatus=""}}
                .onFailure{googleStatus=friendlyGoogleAuthError(it)}
            googleBusy=false
        }
    }
    LaunchedEffect(current?.id,firebaseIdentity?.uid){
        val account=current
        if(account!=null&&firebaseIdentity!=null){
            classroomGateway.connect(account){state->cloudStatus=state;refresh++}
        }else{
            classroomGateway.disconnect();cloudStatus=classroomGateway.status()
        }
    }
    DisposableEffect(classroomGateway){onDispose{classroomGateway.disconnect()}}

    when {
        current == null -> CloudWelcome(
            identity=firebaseIdentity,
            busy=googleBusy,
            status=googleStatus,
            onGoogle=signInWithGoogle,
            onEmailSignIn={email,password,complete->scope.launch{
                runCatching{
                    val identity=authController.signInWithEmail(email,password)
                    val account=classroomGateway.restoreSignedInAccount(identity)
                        ?: error("This email does not have an active Sabaq Workspace account.")
                    firebaseIdentity=identity
                    saveSession(account)
                    refresh++
                }.onSuccess{complete(null)}.onFailure{complete(friendlyEmailAuthError(it))}
            }},
            onResetPassword={email,complete->scope.launch{
                runCatching{authController.sendPasswordReset(email)}
                    .onSuccess{complete(null)}
                    .onFailure{complete("The reset request could not be sent. Check your connection and try again.")}
            }},
            onActivate={code,password,complete->scope.launch{
                runCatching{
                    authController.ensurePasswordForCurrentGoogleAccount(password)
                    classroomGateway.redeemGoogleInvitation(code)
                    val identity=authController.currentIdentity()?:error("Google session expired. Sign in again.")
                    val account=classroomGateway.restoreSignedInAccount(identity)
                        ?: error("Activation succeeded, but the local profile could not be opened.")
                    firebaseIdentity=identity
                    saveSession(account)
                    refresh++
                }.onSuccess{complete(null)}.onFailure{complete(it.message.orEmpty())}
            }},
            onClaimOwner={password,complete->scope.launch{
                runCatching{
                    authController.ensurePasswordForCurrentGoogleAccount(password)
                    val account=classroomGateway.claimInitialAdministrator()
                    saveSession(account)
                    refresh++
                }.onSuccess{complete(null)}.onFailure{complete(friendlyEmailAuthError(it))}
            }}
        )
        else -> AuthenticatedApp(
            db,current!!,refresh,initialDestination,
            firebaseIdentity=firebaseIdentity,
            googleBusy=googleBusy,
            googleStatus=googleStatus,
            classroomGateway=classroomGateway,
            cloudStatus=cloudStatus,
            onRefresh={refresh++},
            onRequestNotifications=requestNotifications,
            onReconnectCloud={scope.launch{val latest=current?.id?.let(db::account)?:return@launch;cloudStatus=classroomGateway.connect(latest){state->cloudStatus=state;refresh++}}},
            onActivateCloudAccount={code,password,complete->scope.launch{
                runCatching{
                    authController.ensurePasswordForCurrentGoogleAccount(password)
                    classroomGateway.redeemGoogleInvitation(code)
                }.onSuccess{complete(null)}.onFailure{complete(it.message.orEmpty())}
            }},
            onLinkGoogle={
                if(!googleBusy)scope.launch{
                    googleBusy=true;googleStatus=""
                    try{
                        val identity=authController.currentIdentity()?:authController.signIn(context)
                        db.linkFirebaseIdentity(current!!.id,identity.uid,identity.email)
                        firebaseIdentity=identity
                        googleStatus="Google account linked. You can use it to sign in on this device."
                        refresh++
                    }catch(error:Exception){googleStatus=friendlyGoogleAuthError(error)}
                    finally{googleBusy=false}
                }
            },
            onLogout={
                firebaseIdentity=null;googleStatus="";sessionPrefs.edit().remove("account_id").apply();current=null;refresh++
                scope.launch{authController.signOut(context)}
            }
        )
    }
}

@Composable
private fun CloudWelcome(
    identity:FirebaseIdentity?,
    busy:Boolean,
    status:String,
    onGoogle:()->Unit,
    onEmailSignIn:(String,String,(String?)->Unit)->Unit,
    onResetPassword:(String,(String?)->Unit)->Unit,
    onActivate:(String,String,(String?)->Unit)->Unit,
    onClaimOwner:(String,(String?)->Unit)->Unit
) {
    var email by rememberSaveable{mutableStateOf("")}
    var password by rememberSaveable{mutableStateOf("")}
    var confirmation by rememberSaveable{mutableStateOf("")}
    var code by rememberSaveable{mutableStateOf("")}
    var message by remember{mutableStateOf("")}
    var working by remember{mutableStateOf(false)}
    AuthCanvas("Sabaq Workspace","Your invited Google email becomes your secure workspace identity across devices.") {
        Button(enabled=!busy&&!working,onClick=onGoogle,modifier=Modifier.fillMaxWidth()) {
            if(busy) CircularProgressIndicator(Modifier.size(18.dp),strokeWidth=2.dp,color=Color.White)
            else Icon(Icons.Default.AccountCircle,null)
            Spacer(Modifier.width(8.dp))
            Text(if(identity==null)"Verify invitation email with Google" else identity.email.ifBlank{"Google verified"})
        }
        if(identity==null) {
            HorizontalDivider()
            Text("Already activated? Sign in with the same Google email and your Sabaq password.",color=Navy.copy(alpha=.7f),fontSize=13.sp)
            OutlinedTextField(email,{email=it},label={Text("Google email")},singleLine=true,modifier=Modifier.fillMaxWidth())
            OutlinedTextField(password,{password=it},label={Text("Sabaq password")},singleLine=true,visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth())
            Button(enabled=email.contains('@')&&password.isNotBlank()&&!working,onClick={
                working=true;message=""
                onEmailSignIn(email,password){error->working=false;password="";message=error.orEmpty()}
            },modifier=Modifier.fillMaxWidth()){Text("Sign in with email")}
            TextButton(enabled=email.contains('@')&&!working,onClick={
                working=true;message=""
                onResetPassword(email){error->working=false;message=error?:"If an activated account exists, a secure reset email has been sent."}
            },modifier=Modifier.fillMaxWidth()){Text("Forgot password?")}
        } else {
            Text("Create a Sabaq password for future sign-in and secure email recovery. Your invitation decides whether you are a teacher, student, or guardian.",color=Navy.copy(alpha=.7f),fontSize=13.sp)
            OutlinedTextField(code,{code=it.trim()},label={Text("Invitation code")},singleLine=true,modifier=Modifier.fillMaxWidth())
            OutlinedTextField(password,{password=it},label={Text("Create password · at least 10 characters")},singleLine=true,visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth())
            OutlinedTextField(confirmation,{confirmation=it},label={Text("Confirm password")},singleLine=true,visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth())
            Button(enabled=code.length>=40&&password.length>=10&&password==confirmation&&!working,onClick={
                working=true;message=""
                onActivate(code,password){error->working=false;message=error.orEmpty()}
            },modifier=Modifier.fillMaxWidth()) {
                if(working) CircularProgressIndicator(Modifier.size(18.dp),strokeWidth=2.dp,color=Color.White)
                else Text("Create account and join")
            }
            HorizontalDivider()
            Text("Setting up this workspace for the first time? Only the approved owner Google account can use this once.",color=Navy.copy(alpha=.65f),fontSize=12.sp)
            OutlinedButton(enabled=!working&&password.length>=10&&password==confirmation,onClick={working=true;message="";onClaimOwner(password){error->working=false;message=error?:"Owner account activated."}},modifier=Modifier.fillMaxWidth()){
                Icon(Icons.Default.AdminPanelSettings,null);Spacer(Modifier.width(8.dp));Text("Activate workspace owner")
            }
        }
        if(status.isNotBlank()) Text(status,color=Navy.copy(alpha=.7f),fontSize=13.sp)
        if(message.isNotBlank()) Text(message,color=if(message.startsWith("If an activated"))Sage else MaterialTheme.colorScheme.error,fontSize=13.sp)
        Text("A verified server account is required. Classroom data stays tied to your account across devices.",color=Navy.copy(alpha=.55f),fontSize=11.sp)
    }
}

@Composable
private fun AuthCanvas(title: String, subtitle: String, content: @Composable ColumnScope.() -> Unit) {
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(DeepTeal,Navy))), contentAlignment = Alignment.Center) {
        Column(Modifier.fillMaxWidth().padding(24.dp).background(Ivory, RoundedCornerShape(28.dp)).padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Box(Modifier.size(58.dp).background(Gold, RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.AutoStories, null, tint = Navy, modifier = Modifier.size(34.dp)) }
            Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Navy)
            Text(subtitle, color = Navy.copy(alpha = .68f))
            content()
        }
    }
}

@Composable
private fun AuthenticatedApp(db:AppDatabase,account:Account,refresh:Int,initialDestination:String?,firebaseIdentity:FirebaseIdentity?,googleBusy:Boolean,googleStatus:String,classroomGateway:FirebaseClassroomGateway,cloudStatus:CloudClassroomStatus,onRefresh:()->Unit,onRequestNotifications:()->Unit,onReconnectCloud:()->Unit,onActivateCloudAccount:(String,String,(String?)->Unit)->Unit,onLinkGoogle:()->Unit,onLogout:()->Unit) {
    val context = LocalContext.current
    val feedbackPrefs = remember { FeedbackPreferences(context) }
    var feedbackSettings by remember { mutableStateOf(feedbackPrefs.load()) }
    var updateAvailable by remember{mutableStateOf(false)}
    val navItems = remember(account.role) {
        when (account.role) {
            AccountRole.ADMIN -> listOf(NavItem("overview","Overview",Icons.Default.SpaceDashboard),NavItem("accounts","Accounts",Icons.Default.ManageAccounts),NavItem("classes","Classes",Icons.Default.Groups),NavItem("settings","Settings",Icons.Default.Settings))
            AccountRole.TEACHER -> listOf(NavItem("today","Today",Icons.Default.Home),NavItem("classroom","Classroom",Icons.Default.Groups),NavItem("insights","Insights",Icons.Default.QueryStats),NavItem("planner","Planner",Icons.AutoMirrored.Filled.Assignment),NavItem("settings","Settings",Icons.Default.Settings))
            AccountRole.STUDENT -> listOf(NavItem("today","Today",Icons.Default.Home),NavItem("classwork","Classroom",Icons.AutoMirrored.Filled.MenuBook),NavItem("planner","Planner",Icons.AutoMirrored.Filled.Assignment),NavItem("settings","Settings",Icons.Default.Settings))
            AccountRole.GUARDIAN -> listOf(NavItem("today","Family",Icons.Default.Home),NavItem("classes","Classes",Icons.Default.Groups),NavItem("settings","Settings",Icons.Default.Settings))
        }
    }
    var selected by rememberSaveable(account.id) { mutableStateOf(initialDestination?.takeIf{candidate->navItems.any{it.id==candidate}}?:navItems.first().id) }
    LaunchedEffect(initialDestination){initialDestination?.takeIf{candidate->navItems.any{it.id==candidate}}?.let{selected=it}}
    var updatesOpen by rememberSaveable { mutableStateOf(false) }
    val releasePrefs=remember{context.getSharedPreferences("sabaq_release_notes",android.content.Context.MODE_PRIVATE)}
    var whatsNewOpen by rememberSaveable { mutableStateOf(false) }
    val perform: (FeedbackKind) -> Unit = { FeedbackEngine.perform(context, feedbackSettings, it) }
    LaunchedEffect(account.id, refresh) {
        if (account.role == AccountRole.STUDENT) db.assignmentsFor(account).forEach { assignment -> NotificationScheduler.scheduleAssignment(context,assignment,db.reminderPreference(assignment.id,account.id)) }
    }
    LaunchedEffect(Unit){updateAvailable=runCatching{withContext(Dispatchers.IO){UpdateManager.check().versionCode>UpdateManager.installedVersionCode(context)}}.getOrDefault(false)}
    LaunchedEffect(account.id) {
        if(releasePrefs.getInt("acknowledged_build",0)<BUILD_NUMBER&&ReleaseHistory.forBuild(BUILD_NUMBER)!=null) whatsNewOpen=true
    }

    Scaffold(
        containerColor = Canvas,
        topBar = { AppHeader(account, updateAvailable, onUpdates = { updatesOpen = true; perform(FeedbackKind.SELECT) }, onLogout = onLogout) },
        bottomBar = {
            NavigationBar(containerColor = Ivory, tonalElevation = 0.dp) {
                navItems.forEach { item -> NavigationBarItem(selected == item.id, onClick = { selected = item.id; perform(FeedbackKind.SELECT) }, icon = { Icon(item.icon,item.label) }, label = { Text(item.label) }, colors = NavigationBarItemDefaults.colors(indicatorColor = Gold.copy(alpha=.24f))) }
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (selected) {
                "overview" -> AdminOverview(db, refresh)
                "accounts" -> AccountAdmin(db, account, refresh, classroomGateway, cloudStatus, onRefresh, perform)
                "classes" -> when(account.role){AccountRole.ADMIN->ClassAdmin(db,account,refresh,classroomGateway,cloudStatus,onRefresh,perform);AccountRole.GUARDIAN->GuardianClassrooms(db,account,refresh);else->ClassroomList(db,account,refresh,perform)}
                "today" -> if(account.role==AccountRole.GUARDIAN) GuardianDashboard(db,account,refresh) else TodayScreen(db, account, refresh)
                "classroom" -> TeacherClassroom(db, account, refresh, classroomGateway, cloudStatus, onRefresh, perform)
                "insights" -> TeacherInsightsScreen(db,account,refresh)
                "classwork" -> StudentClasswork(db, account, refresh, classroomGateway, cloudStatus, onRefresh, perform)
                "planner" -> PlannerHub(db, account, refresh, onRefresh, perform)
                "settings" -> SettingsScreen(db,account,feedbackSettings,firebaseIdentity,googleBusy,googleStatus,cloudStatus,onRefresh,onReconnectCloud,onActivateCloudAccount,onFeedback={feedbackSettings=it;feedbackPrefs.save(it);perform(FeedbackKind.CONFIRM)},onUpdates={updatesOpen=true},onNotifications=onRequestNotifications,onLinkGoogle=onLinkGoogle)
            }
        }
    }
    if (updatesOpen) UpdateDialog { updatesOpen = false }
    if(whatsNewOpen) WhatsNewDialog(ReleaseHistory.forBuild(BUILD_NUMBER)!!){
        releasePrefs.edit().putInt("acknowledged_build",BUILD_NUMBER).apply()
        whatsNewOpen=false
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AppHeader(account: Account, updateAvailable:Boolean, onUpdates: () -> Unit, onLogout: () -> Unit) {
    TopAppBar(
        colors = TopAppBarDefaults.topAppBarColors(containerColor=Navy,titleContentColor=Color.White),
        title = { Row(verticalAlignment=Alignment.CenterVertically) {
            Box(Modifier.size(40.dp).background(Gold,RoundedCornerShape(12.dp)),contentAlignment=Alignment.Center){Icon(Icons.Default.AutoStories,null,tint=Navy)}
            Spacer(Modifier.width(11.dp)); Column { Text("Sabaq Workspace",fontWeight=FontWeight.Bold,fontSize=18.sp); Text("${account.displayName} · ${account.role.name.lowercase().replaceFirstChar(Char::uppercase)}",fontSize=11.sp,color=Color.White.copy(alpha=.7f)) }
        } },
        actions = { IconButton(onClick=onUpdates){BadgedBox(badge={if(updateAvailable)Badge()}){Icon(Icons.Default.SystemUpdate,if(updateAvailable)"Update available" else "Check for updates",tint=Gold)}}; IconButton(onClick=onLogout){Icon(Icons.AutoMirrored.Filled.Logout,"Sign out",tint=Color.White)} }
    )
}

@Composable
private fun AdminOverview(db: AppDatabase, refresh: Int) {
    val accounts = remember(refresh) { db.accounts() }
    val admin = accounts.first { it.role == AccountRole.ADMIN }
    val classes = remember(refresh) { db.classroomsFor(admin) }
    Page("Administration", "Accounts and classrooms on this device") {
        item { Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) { Metric("Accounts",accounts.size.toString(),Icons.Default.ManageAccounts,Modifier.weight(1f)); Metric("Classes",classes.size.toString(),Icons.Default.Groups,Modifier.weight(1f)) } }
        item { InfoCard(Icons.Default.Security,"Server-authorized workspace","Firebase Authentication, verified invitations, server roles, App Check, audited writes, and live sync protect classroom access across devices.") }
        item { SectionTitle("Account summary") }
        items(AccountRole.entries) { role -> SimpleRow(role.name.lowercase().replaceFirstChar(Char::uppercase),"${accounts.count{it.role==role}} active or suspended",Icons.Default.Person) }
    }
}

@Composable
private fun AccountAdmin(db: AppDatabase, administrator:Account, refresh: Int,gateway:FirebaseClassroomGateway,cloudStatus:CloudClassroomStatus, onRefresh: () -> Unit, perform: (FeedbackKind) -> Unit) {
    val scope=rememberCoroutineScope()
    val accounts = remember(refresh) { db.accounts() }
    val classrooms=remember(refresh){db.classroomsFor(administrator).filterNot{it.archived}}
    var query by rememberSaveable{mutableStateOf("")}
    val visible=remember(accounts,query){accounts.filter{query.isBlank()||it.displayName.contains(query,true)||it.username.contains(query,true)||it.role.name.contains(query,true)}}
    var inviteOpen by rememberSaveable { mutableStateOf(false) }
    var invitationCode by rememberSaveable { mutableStateOf("") }
    var guardianOpen by rememberSaveable { mutableStateOf(false) }
    var pendingStatus by remember{mutableStateOf<Pair<Account,Boolean>?>(null)}
    var adminMessage by remember{mutableStateOf("")}
    Page("Accounts", "Invite and manage secure server accounts") {
        item { Button(enabled=cloudStatus.connection==CloudConnection.LIVE,onClick={inviteOpen=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.PersonAdd,null);Spacer(Modifier.width(8.dp));Text("Invite teacher, student, or guardian")} }
        if(adminMessage.isNotBlank())item{InfoCard(Icons.Default.AdminPanelSettings,"Account access",adminMessage)}
        if(invitationCode.isNotBlank())item{InfoCard(Icons.Default.VpnKey,"Invitation ready","Share this once with the invited person:\n$invitationCode\n\nIt expires in 72 hours and only works with the invited verified Google email.")}
        item { OutlinedButton(enabled=cloudStatus.connection==CloudConnection.LIVE,onClick={guardianOpen=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.FamilyRestroom,null);Spacer(Modifier.width(8.dp));Text("Link guardian and student")} }
        item{OutlinedTextField(query,{query=it},label={Text("Search name, username, or role")},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true,modifier=Modifier.fillMaxWidth())}
        items(visible,key={it.id}) { item ->
            Card(colors=CardDefaults.cardColors(containerColor=Ivory),shape=RoundedCornerShape(20.dp)) { Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.CenterVertically) {
                Box(Modifier.size(44.dp).background(if(item.active) Sage else Color.Gray,CircleShape),contentAlignment=Alignment.Center){Text(item.displayName.take(1).uppercase(),color=Color.White,fontWeight=FontWeight.Bold)}
                Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)){Text(item.displayName,fontWeight=FontWeight.Bold);Text("@${item.username} · ${item.role.name.lowercase()}",color=Navy.copy(alpha=.6f))}
                Switch(item.active,{pendingStatus=item to it},enabled=item.role!=AccountRole.ADMIN,modifier=Modifier.semantics{contentDescription=if(item.active)"Suspend ${item.displayName}" else "Activate ${item.displayName}"})
            } }
        }
    }
    if(inviteOpen)ServerInviteDialog(classrooms,{inviteOpen=false}){name,email,role,classIds,complete->scope.launch{runCatching{gateway.createInvitation(name,email,role,classIds)}.onSuccess{code->invitationCode=code;inviteOpen=false;perform(FeedbackKind.CONFIRM);complete(null)}.onFailure{complete(it.message.orEmpty())}}}
    if(guardianOpen) GuardianLinkDialog(accounts.filter{it.role==AccountRole.GUARDIAN&&it.active},accounts.filter{it.role==AccountRole.STUDENT&&it.active},{guardianOpen=false}){g,s->scope.launch{runCatching{gateway.linkGuardian(g,s)}.onSuccess{perform(FeedbackKind.CONFIRM);guardianOpen=false;adminMessage="Guardian access linked securely.";onRefresh()}.onFailure{adminMessage=it.message.orEmpty();guardianOpen=false}}}
    pendingStatus?.let{change->ConfirmActionDialog("${if(change.second)"Activate" else "Suspend"} ${change.first.displayName}?",if(change.second)"They will regain access on every device." else "They will be signed out and blocked on every device.",{pendingStatus=null}){scope.launch{runCatching{gateway.setAccountActive(change.first.id,change.second)}.onSuccess{perform(if(change.second)FeedbackKind.CONFIRM else FeedbackKind.WARNING);adminMessage="${change.first.displayName} was ${if(change.second)"activated" else "suspended"}.";onRefresh()}.onFailure{adminMessage=it.message.orEmpty()}};pendingStatus=null}}
}

@Composable private fun ConfirmActionDialog(title:String,message:String,onDismiss:()->Unit,onConfirm:()->Unit){AlertDialog(onDismissRequest=onDismiss,title={Text(title)},text={Text(message)},confirmButton={Button(onClick=onConfirm){Text("Confirm")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})}

@Composable private fun ServerInviteDialog(classrooms:List<Classroom>,onDismiss:()->Unit,onCreate:(String,String,AccountRole,List<String>,(String?)->Unit)->Unit){var name by rememberSaveable{mutableStateOf("")};var email by rememberSaveable{mutableStateOf("")};var role by rememberSaveable{mutableStateOf(AccountRole.STUDENT)};var classroomId by rememberSaveable{mutableStateOf(classrooms.firstOrNull()?.id.orEmpty())};var error by remember{mutableStateOf("")};var busy by remember{mutableStateOf(false)};val validEmail=email.matches(Regex("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$"));AlertDialog(onDismissRequest={if(!busy)onDismiss()},icon={Icon(Icons.Default.MarkEmailRead,null,tint=Gold)},title={Text("Create Google invitation")},text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(9.dp)){Text("The server assigns this role; invitees cannot choose or promote their own role.");OutlinedTextField(name,{name=it},label={Text("Display name")});OutlinedTextField(email,{email=it.trim()},label={Text("Google email")},singleLine=true);RoleDropdown(role,allowAdmin=true){role=it};if(role==AccountRole.ADMIN)InfoCard(Icons.Default.AdminPanelSettings,"Administrator invitation","This account can manage users and classrooms after activation.") else if(classrooms.isNotEmpty())ClassDropdown(classroomId,classrooms){classroomId=it};if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)}},confirmButton={Button(enabled=name.trim().length>=2&&validEmail&&!busy&&(role!=AccountRole.STUDENT||classroomId.isNotBlank()),onClick={busy=true;error="";onCreate(name,email,role,listOfNotNull(classroomId.takeIf{role!=AccountRole.ADMIN&&it.isNotBlank()})){message->busy=false;error=message.orEmpty()}}){if(busy)CircularProgressIndicator(Modifier.size(18.dp),strokeWidth=2.dp,color=Color.White)else Text("Create")}},dismissButton={TextButton(enabled=!busy,onClick=onDismiss){Text("Cancel")}})}

@Composable private fun ReauthenticateDialog(message:String,onDismiss:()->Unit,onConfirm:(String)->String?){var password by rememberSaveable{mutableStateOf("")};var error by rememberSaveable{mutableStateOf("")};AlertDialog(onDismissRequest=onDismiss,title={Text("Re-authentication required")},text={Column(verticalArrangement=Arrangement.spacedBy(9.dp)){Text(message);OutlinedTextField(password,{password=it},label={Text("Your administrator password")},visualTransformation=PasswordVisualTransformation());if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)}},confirmButton={Button(enabled=password.isNotBlank(),onClick={error=onConfirm(password).orEmpty();password=""}){Text("Confirm")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})}

@Composable private fun GuardianLinkDialog(guardians:List<Account>,students:List<Account>,onDismiss:()->Unit,onLink:(String,String)->Unit){var guardian by remember{mutableStateOf(guardians.firstOrNull()?.id.orEmpty())};var student by remember{mutableStateOf(students.firstOrNull()?.id.orEmpty())};AlertDialog(onDismissRequest=onDismiss,title={Text("Link family access")},text={Column(verticalArrangement=Arrangement.spacedBy(10.dp)){AccountDropdown("Guardian",guardian,guardians){guardian=it};AccountDropdown("Student",student,students){student=it};Text("Guardians can view the linked student’s classwork, hand-in state, feedback, and progress. They cannot submit or change classroom records.",fontSize=12.sp,color=Navy.copy(alpha=.65f))}},confirmButton={Button(enabled=guardian.isNotBlank()&&student.isNotBlank(),onClick={onLink(guardian,student)}){Text("Link")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})}

@Composable
private fun CreateAccountDialog(onDismiss:()->Unit,onCreate:(String,String,AccountRole,String)->String?) {
    var name by rememberSaveable{mutableStateOf("")};var user by rememberSaveable{mutableStateOf("")};var pass by rememberSaveable{mutableStateOf("")};var role by rememberSaveable{mutableStateOf(AccountRole.STUDENT)};var error by rememberSaveable{mutableStateOf("")}
    AlertDialog(onDismissRequest=onDismiss,title={Text("Create account")},text={Column(verticalArrangement=Arrangement.spacedBy(10.dp)){
        OutlinedTextField(name,{name=it},label={Text("Display name")});OutlinedTextField(user,{user=it},label={Text("Username")});OutlinedTextField(pass,{pass=it},label={Text("Initial password · 10+ characters")},visualTransformation=PasswordVisualTransformation())
        RoleDropdown(role){role=it}; if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error);Text("The password is hashed immediately and is never shown again.",fontSize=12.sp,color=Navy.copy(alpha=.6f))
    }},confirmButton={Button(enabled=name.isNotBlank()&&user.isNotBlank()&&pass.length>=10,onClick={error=onCreate(name,user,role,pass).orEmpty();if(error.isBlank())pass=""}){Text("Create")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})
}

@Composable
private fun RoleDropdown(role:AccountRole,allowAdmin:Boolean=false,onChange:(AccountRole)->Unit){var open by remember{mutableStateOf(false)};Box{OutlinedButton(onClick={open=true},modifier=Modifier.fillMaxWidth()){Text("Role: ${role.name.lowercase().replaceFirstChar(Char::uppercase)}")};DropdownMenu(open,{open=false}){AccountRole.entries.filter{allowAdmin||it!=AccountRole.ADMIN}.forEach{DropdownMenuItem({Text(it.name.lowercase().replaceFirstChar(Char::uppercase))},{onChange(it);open=false})}}}}

@Composable
private fun ClassAdmin(db:AppDatabase,account:Account,refresh:Int,gateway:FirebaseClassroomGateway,cloudStatus:CloudClassroomStatus,onRefresh:()->Unit,perform:(FeedbackKind)->Unit){
    val scope=rememberCoroutineScope();val classes=remember(refresh){db.classroomsFor(account)};val activeClasses=remember(classes){classes.filterNot{it.archived}};val people=remember(refresh){db.accounts()};var serverMessage by remember{mutableStateOf("")};var addOpen by rememberSaveable{mutableStateOf(false)};var transferOpen by rememberSaveable{mutableStateOf(false)};var rosterClass by remember{mutableStateOf<Classroom?>(null)};var teamClass by remember{mutableStateOf<Classroom?>(null)};var manageClass by remember{mutableStateOf<Classroom?>(null)}
    Page("Classrooms","Assign teachers and manage student rosters"){
        item{Button(onClick={addOpen=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Add,null);Spacer(Modifier.width(8.dp));Text("Create classroom")}}
        if(serverMessage.isNotBlank())item{InfoCard(Icons.Default.Cloud,if(cloudStatus.connection==CloudConnection.LIVE)"Server classroom" else "Local classroom",serverMessage)}
        item{OutlinedButton(enabled=activeClasses.size>1&&activeClasses.any{db.members(it.id).isNotEmpty()},onClick={transferOpen=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.SwapHoriz,null);Spacer(Modifier.width(8.dp));Text("Transfer student")}}
        if(classes.isEmpty())item{EmptyCard("No classrooms","Create a classroom after adding at least one teacher account.")}
        items(classes,key={it.id}){c->val teacher=people.firstOrNull{it.id==c.teacherId};val studentCount=db.members(c.id).count{it.role==AccountRole.STUDENT};Card(colors=CardDefaults.cardColors(containerColor=if(c.archived)Canvas else Ivory),shape=RoundedCornerShape(20.dp)){Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(48.dp).background(if(c.archived)Navy.copy(alpha=.12f)else Gold,RoundedCornerShape(15.dp)),contentAlignment=Alignment.Center){Icon(if(c.archived)Icons.Default.Archive else Icons.Default.Groups,null,tint=Navy)};Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f).clickable(enabled=!c.archived){rosterClass=c}){Text(c.name,fontWeight=FontWeight.Bold);Text("${c.section} · ${teacher?.displayName?:"Teacher"} · $studentCount students${if(c.archived)" · Archived" else ""}",color=Navy.copy(alpha=.6f))};IconButton(onClick={teamClass=c}){Icon(Icons.Default.People,"Manage teaching team")};IconButton(onClick={manageClass=c}){Icon(Icons.Default.Edit,"Manage classroom")}}}}
    }
    if(addOpen)CreateClassDialog(people.filter{it.role==AccountRole.TEACHER&&it.active},{addOpen=false}){name,section,teacher->
        if(cloudStatus.connection==CloudConnection.LIVE){serverMessage="Creating classroom on the server…";scope.launch{runCatching{gateway.createClassroom(name,section,teacher)}.onSuccess{serverMessage="Classroom created. You can now invite students into it.";perform(FeedbackKind.CONFIRM);addOpen=false;onRefresh()}.onFailure{serverMessage=it.message.orEmpty();addOpen=false}};null}
        else runCatching{db.createClassroom(name,section,teacher)}.onSuccess{perform(FeedbackKind.CONFIRM);addOpen=false;onRefresh()}.exceptionOrNull()?.message
    }
    rosterClass?.let{c->RosterDialog(c,db.members(c.id).filter{it.role==AccountRole.STUDENT},people.filter{it.role==AccountRole.STUDENT&&it.active&&!db.members(c.id).any{m->m.id==it.id}},{rosterClass=null}){student->serverMessage="Adding student…";scope.launch{runCatching{gateway.addClassroomMember(c.id,student)}.onSuccess{perform(FeedbackKind.CONFIRM);serverMessage="Student added to ${c.name}.";rosterClass=null;onRefresh()}.onFailure{serverMessage=it.message.orEmpty();rosterClass=null}}}}
    teamClass?.let { classroom ->
        TeachingTeamDialog(
            classroom = classroom,
            teachers = db.members(classroom.id).filter { it.role == AccountRole.TEACHER },
            available = people.filter { candidate -> candidate.role == AccountRole.TEACHER && candidate.active && db.members(classroom.id).none { it.id == candidate.id } },
            onDismiss = { teamClass = null },
            onAdd = { teacherId ->
                serverMessage = "Adding co-teacher…"
                scope.launch {
                    runCatching { gateway.addClassroomMember(classroom.id, teacherId) }
                        .onSuccess { perform(FeedbackKind.CONFIRM); serverMessage = "Co-teacher added to ${classroom.name}."; onRefresh() }
                        .onFailure { serverMessage = it.message.orEmpty() }
                }
            },
            onRemove = { teacherId ->
                serverMessage = "Removing co-teacher…"
                scope.launch {
                    runCatching { gateway.removeClassroomMember(classroom.id, teacherId) }
                        .onSuccess { perform(FeedbackKind.CONFIRM); serverMessage = "Co-teacher removed."; onRefresh() }
                        .onFailure { serverMessage = it.message.orEmpty() }
                }
            }
        )
    }
    manageClass?.let{c->ManageClassDialog(c,{manageClass=null}){name,section,archived,grading->if(cloudStatus.connection!=CloudConnection.LIVE)"Reconnect before changing a classroom." else {serverMessage="Updating classroom…";scope.launch{runCatching{gateway.updateClassroom(c.id,name,section,archived,grading)}.onSuccess{perform(if(archived)FeedbackKind.WARNING else FeedbackKind.CONFIRM);serverMessage="Classroom updated for everyone.";manageClass=null;onRefresh()}.onFailure{serverMessage=it.message.orEmpty();manageClass=null}};null}}}
    if(transferOpen)TransferDialog(activeClasses,{classId->db.members(classId)},{transferOpen=false}){student,from,to->serverMessage="Transferring student…";scope.launch{runCatching{gateway.transferClassroomMember(student,from,to)}.onSuccess{perform(FeedbackKind.CONFIRM);serverMessage="Student transferred securely.";transferOpen=false;onRefresh()}.onFailure{serverMessage=it.message.orEmpty();transferOpen=false}}}
}

@Composable private fun TransferDialog(classes:List<Classroom>,members:(String)->List<Account>,onDismiss:()->Unit,onTransfer:(String,String,String)->Unit){var from by remember{mutableStateOf(classes.firstOrNull{members(it.id).isNotEmpty()}?.id.orEmpty())};var student by remember(from){mutableStateOf(members(from).firstOrNull()?.id.orEmpty())};var to by remember(from){mutableStateOf(classes.firstOrNull{it.id!=from}?.id.orEmpty())};AlertDialog(onDismissRequest=onDismiss,title={Text("Transfer student")},text={Column(verticalArrangement=Arrangement.spacedBy(9.dp)){ClassDropdown(from,classes.filter{members(it.id).isNotEmpty()}){from=it};AccountDropdown("Student",student,members(from)){student=it};ClassDropdown(to,classes.filter{it.id!=from}){to=it};Text("Existing submissions and work history stay attached to the student. Only active membership moves.",fontSize=12.sp,color=Navy.copy(alpha=.65f))}},confirmButton={Button(enabled=student.isNotBlank()&&from.isNotBlank()&&to.isNotBlank()&&from!=to,onClick={onTransfer(student,from,to)}){Text("Transfer")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})}

@Composable
private fun CreateClassDialog(teachers:List<Account>,onDismiss:()->Unit,onCreate:(String,String,String)->String?){var name by rememberSaveable{mutableStateOf("")};var section by rememberSaveable{mutableStateOf("")};var teacher by remember{mutableStateOf(teachers.firstOrNull()?.id.orEmpty())};var error by remember{mutableStateOf("")};AlertDialog(onDismissRequest=onDismiss,title={Text("Create classroom")},text={Column(verticalArrangement=Arrangement.spacedBy(10.dp)){OutlinedTextField(name,{name=it},label={Text("Classroom name")});OutlinedTextField(section,{section=it},label={Text("Section or schedule")});AccountDropdown("Teacher",teacher,teachers){teacher=it};if(teachers.isEmpty())Text("Create an active teacher account first.",color=MaterialTheme.colorScheme.error);if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)}},confirmButton={Button(enabled=name.isNotBlank()&&teacher.isNotBlank(),onClick={error=onCreate(name,section,teacher).orEmpty()}){Text("Create")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})}

@Composable
private fun ManageClassDialog(classroom:Classroom,onDismiss:()->Unit,onSave:(String,String,Boolean,Boolean)->String?){var name by rememberSaveable(classroom.id){mutableStateOf(classroom.name)};var section by rememberSaveable(classroom.id){mutableStateOf(classroom.section)};var archived by rememberSaveable(classroom.id){mutableStateOf(classroom.archived)};var grading by rememberSaveable(classroom.id){mutableStateOf(classroom.gradingEnabled)};var error by remember{mutableStateOf("")};AlertDialog(onDismissRequest=onDismiss,title={Text("Manage classroom")},text={Column(verticalArrangement=Arrangement.spacedBy(10.dp)){OutlinedTextField(name,{name=it},label={Text("Classroom name")});OutlinedTextField(section,{section=it},label={Text("Section or schedule")});Row(verticalAlignment=Alignment.CenterVertically){Switch(grading,{grading=it});Spacer(Modifier.width(9.dp));Column{Text(if(grading)"Points and private grades" else "Completion tracking",fontWeight=FontWeight.Bold);Text(if(grading)"Assignments may use points; grades stay private." else "No scores are shown; completion and feedback remain available.",fontSize=12.sp,color=Navy.copy(alpha=.65f))}};Row(verticalAlignment=Alignment.CenterVertically){Switch(archived,{archived=it});Spacer(Modifier.width(9.dp));Column{Text(if(archived)"Archived" else "Active",fontWeight=FontWeight.Bold);Text(if(archived)"Hidden from students; roster and history are preserved." else "Available for assignments and announcements.",fontSize=12.sp,color=Navy.copy(alpha=.65f))}};if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)}},confirmButton={Button(enabled=name.trim().length>=2,onClick={error=onSave(name,section,archived,grading).orEmpty()}){Text("Save")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})}

@Composable
private fun RosterDialog(classroom:Classroom,members:List<Account>,available:List<Account>,onDismiss:()->Unit,onAdd:(String)->Unit){var selected by remember{mutableStateOf(available.firstOrNull()?.id.orEmpty())};AlertDialog(onDismissRequest=onDismiss,title={Text(classroom.name)},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Text("Roster",fontWeight=FontWeight.Bold);if(members.isEmpty())Text("No students yet.")else members.forEach{Text("• ${it.displayName} (@${it.username})")};HorizontalDivider();AccountDropdown("Add student",selected,available){selected=it}}},confirmButton={Button(enabled=selected.isNotBlank(),onClick={onAdd(selected)}){Text("Add")}},dismissButton={TextButton(onClick=onDismiss){Text("Close")}})}

@Composable
private fun TeachingTeamDialog(classroom:Classroom,teachers:List<Account>,available:List<Account>,onDismiss:()->Unit,onAdd:(String)->Unit,onRemove:(String)->Unit){var selected by remember{mutableStateOf(available.firstOrNull()?.id.orEmpty())};AlertDialog(onDismissRequest=onDismiss,title={Text("Teaching team")},text={Column(verticalArrangement=Arrangement.spacedBy(9.dp)){Text("${classroom.name} always keeps at least one teacher.",fontSize=12.sp,color=Navy.copy(alpha=.65f));teachers.forEach{teacher->Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(teacher.displayName,fontWeight=FontWeight.Bold);Text(if(teacher.id==classroom.teacherId)"Lead teacher" else "Co-teacher",fontSize=12.sp,color=Navy.copy(alpha=.65f))};if(teachers.size>1)TextButton(onClick={onRemove(teacher.id)}){Text("Remove")}}};HorizontalDivider();AccountDropdown("Add co-teacher",selected,available){selected=it}}},confirmButton={Button(enabled=selected.isNotBlank(),onClick={onAdd(selected)}){Text("Add")}},dismissButton={TextButton(onClick=onDismiss){Text("Close")}})}

@Composable
private fun AccountDropdown(label:String,selected:String,accounts:List<Account>,onSelect:(String)->Unit){var open by remember{mutableStateOf(false)};Box{OutlinedButton(onClick={open=true},modifier=Modifier.fillMaxWidth()){Text("$label: ${accounts.firstOrNull{it.id==selected}?.displayName?:"Choose"}")};DropdownMenu(open,{open=false}){accounts.forEach{DropdownMenuItem({Text(it.displayName)},{onSelect(it.id);open=false})}}}}

@Composable
private fun TodayScreen(db:AppDatabase,account:Account,refresh:Int){val work=remember(refresh){db.assignmentsFor(account)};val classes=remember(refresh){db.classroomsFor(account)};val announcements=remember(refresh){db.announcementsFor(account)};val progress=remember(refresh,account.id){if(account.role==AccountRole.STUDENT)db.progress(account.id)else emptyList()};val submissions=remember(refresh,account.id){if(account.role==AccountRole.STUDENT)work.associate{it.id to db.submissionFor(it.id,account.id)}else emptyMap()};val workload=remember(work,submissions){if(account.role==AccountRole.STUDENT)WorkloadEngine.student(work,submissions)else null};Page("Salaam, ${account.displayName}","${hijriDate()} · ${work.count{it.state==AssignmentState.PUBLISHED}} active assignments across ${classes.size} classrooms"){
    if(workload!=null)item{StudentWorkloadOverview(workload,work,submissions)}else item{Card(colors=CardDefaults.cardColors(containerColor=Navy),shape=RoundedCornerShape(25.dp)){Column(Modifier.padding(20.dp)){Text("TEACHING TODAY",color=Gold,fontWeight=FontWeight.Bold,fontSize=12.sp);Spacer(Modifier.height(7.dp));Text("${classes.size} classrooms · ${work.count{it.state==AssignmentState.PUBLISHED}} live assignments",color=Color.White,style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold);Text("Open Insights to spot overloaded students and missing work early.",color=Color.White.copy(alpha=.7f))}}}
    item{Row(horizontalArrangement=Arrangement.spacedBy(12.dp)){Metric(if(workload==null)"Assignments" else "Open",(workload?.openCount?:work.size).toString(),Icons.Default.Schedule,Modifier.weight(1f));Metric("Classes",classes.size.toString(),Icons.Default.Groups,Modifier.weight(1f))}}
    if(workload==null)item{InfoCard(Icons.Default.QueryStats,"Workload intelligence","The new Insights area ranks students who need attention and shows estimated class workload, completion, and upcoming pressure.")}
    if(announcements.isNotEmpty()){item{SectionTitle("Latest announcements")};items(announcements.take(3),key={it.id}){AnnouncementCard(it)}}
    if(work.isNotEmpty()){item{SectionTitle("Recently published classwork")};items(work.filter{it.state==AssignmentState.PUBLISHED||it.state==AssignmentState.CLOSED}.sortedByDescending{it.publishAtMillis.takeIf{time->time>0}?:it.createdAtMillis}.take(5),key={"home-feed-${it.id}"}){assignment->AssignmentCard(assignment,if(account.role==AccountRole.STUDENT)"Open classwork" else "${assignment.state.name.lowercase()} · ${assignment.subject}",onClick={})}}
    if(progress.isNotEmpty()){item{SectionTitle("My progress")};items(progress.take(4),key={it.id}){ProgressCard(it)}}
}}

@Composable private fun GuardianDashboard(db:AppDatabase,account:Account,refresh:Int){val wards=remember(refresh){db.wards(account.id)};Page("Family view","Read-only learning summaries for linked students"){
    if(wards.isEmpty())item{EmptyCard("No student linked","An administrator can securely link this guardian account to a student.")}else wards.forEach{ward->item{SectionTitle(ward.displayName)};val assignments=db.assignmentsFor(ward);val submissions=assignments.associate{it.id to db.submissionFor(it.id,ward.id)};val workload=WorkloadEngine.student(assignments,submissions);val progress=db.progress(ward.id);val announcements=db.announcementsFor(ward);val classes=db.classroomsFor(ward).associateBy{it.id};item{StudentWorkloadOverview(workload,assignments,submissions)};items(announcements.take(3),key={"${ward.id}-announcement-${it.id}"}){AnnouncementCard(it)};items(assignments.take(5),key={"${ward.id}-${it.id}"}){a->val submission=submissions[a.id];val state=if(classes[a.classroomId]?.gradingEnabled==true&&a.pointsPossible!=null)submission?.gradePoints?.let{"$it / ${a.pointsPossible} points"}?:"Ungraded" else submission?.state?.name?.lowercase()?.replace('_',' ')?:"assigned";AssignmentCard(a,state,onClick={})};items(progress.take(3),key={"${ward.id}-${it.id}"}){ProgressCard(it)}}
}}

@Composable
private fun TeacherClassroom(db:AppDatabase,account:Account,refresh:Int,gateway:FirebaseClassroomGateway,cloudStatus:CloudClassroomStatus,onRefresh:()->Unit,perform:(FeedbackKind)->Unit){val context=LocalContext.current;val scope=rememberCoroutineScope();val classes=remember(refresh){db.classroomsFor(account)};val activeClasses=remember(classes){classes.filterNot{it.archived}};val work=remember(refresh){db.managedAssignmentsFor(account)};val announcements=remember(refresh){db.announcementsFor(account)};var cloudMessage by remember{mutableStateOf("")};var composer by rememberSaveable{mutableStateOf(false)};var composerClass by remember{mutableStateOf<Classroom?>(null)};var createClassOpen by rememberSaveable{mutableStateOf(false)};var announcementOpen by rememberSaveable{mutableStateOf(false)};var announcementClass by remember{mutableStateOf<Classroom?>(null)};var manageAnnouncement by remember{mutableStateOf<Announcement?>(null)};var progressOpen by rememberSaveable{mutableStateOf(false)};var openedClass by remember{mutableStateOf<Classroom?>(null)};var roster by remember{mutableStateOf<Classroom?>(null)};var manageClass by remember{mutableStateOf<Classroom?>(null)};var manageAssignment by remember{mutableStateOf<ClassroomAssignment?>(null)};var editAssignment by remember{mutableStateOf<ClassroomAssignment?>(null)};var review by remember{mutableStateOf<ClassroomAssignment?>(null)};if(openedClass!=null)ClassroomWorkspace(db,account,openedClass!!,refresh,cloudStatus,{openedClass=null},{a->manageAssignment=a},{composerClass=openedClass;composer=true},{announcementClass=openedClass;announcementOpen=true},{a->review=a},gateway,onRefresh,onManageAnnouncement={manageAnnouncement=it}) else Page("Classroom hub","Choose a class to open its Stream, Classwork, People, and Grades workspace"){
    item{InfoCard(if(cloudStatus.connection==CloudConnection.LIVE)Icons.Default.CloudDone else Icons.Default.CloudOff,if(cloudStatus.connection==CloudConnection.LIVE)"Students receive published work live" else "Server delivery unavailable",cloudMessage.ifBlank{cloudStatus.message})}
    item{OutlinedButton(onClick={createClassOpen=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.CreateNewFolder,null);Spacer(Modifier.width(8.dp));Text("Create classroom")}}
    item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(enabled=activeClasses.isNotEmpty(),onClick={composer=true},modifier=Modifier.weight(1f)){Icon(Icons.Default.Add,null);Spacer(Modifier.width(5.dp));Text("Assignment")};OutlinedButton(enabled=activeClasses.isNotEmpty(),onClick={announcementOpen=true},modifier=Modifier.weight(1f)){Icon(Icons.Default.Campaign,null);Spacer(Modifier.width(5.dp));Text("Post")}}}
    item{OutlinedButton(enabled=activeClasses.any{db.members(it.id).isNotEmpty()},onClick={progressOpen=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Insights,null);Spacer(Modifier.width(8.dp));Text("Record student progress")}}
    item{SectionTitle("Your classrooms")};items(classes,key={it.id}){c->Card(modifier=Modifier.fillMaxWidth().clickable(enabled=!c.archived){openedClass=c},colors=CardDefaults.cardColors(containerColor=if(c.archived)Canvas else Ivory),shape=RoundedCornerShape(18.dp)){Row(Modifier.fillMaxWidth().padding(15.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(42.dp).background(if(c.archived)Navy.copy(alpha=.12f)else Gold.copy(alpha=.22f),RoundedCornerShape(13.dp)),contentAlignment=Alignment.Center){Icon(if(c.archived)Icons.Default.Archive else Icons.Default.Groups,null,tint=Navy)};Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(c.name,fontWeight=FontWeight.Bold);Text("${c.section} · ${db.members(c.id).size} students${if(c.archived)" · Archived" else ""}",color=Navy.copy(alpha=.6f),fontSize=13.sp)};Icon(Icons.Default.ChevronRight,"Open classroom");IconButton(onClick={manageClass=c}){Icon(Icons.Default.Edit,"Manage classroom")}}}}
    if(announcements.isNotEmpty()){item{SectionTitle("Announcements")};items(announcements.take(5),key={it.id}){AnnouncementCard(it,onManage={manageAnnouncement=it})}}
    item{SectionTitle("Assignment lifecycle")};if(work.isEmpty())item{EmptyCard("No assignments","Create a draft, schedule it, or publish immediately.")}else items(work,key={it.id}){a->val count=db.submissionsForAssignment(a.id).count{it.state==SubmissionState.HANDED_IN};AssignmentCard(a,"${a.state.name.lowercase().replace('_',' ')} · $count in · r${a.revision}",onClick={manageAssignment=a})}
    item{Spacer(Modifier.height(80.dp))}
    }
    if(composer)AssignmentComposer(composerClass?.let{listOf(it)}?:activeClasses,cloudMessage,onDismiss={composer=false;composerClass=null;cloudMessage=""}){classId,title,instructions,subject,due,estimate,priority,type,steps,attachments,state,publishAt,points,comments->
        if(cloudStatus.connection==CloudConnection.LIVE){
            cloudMessage="Publishing securely…";scope.launch{runCatching{gateway.publishAssignment(context,classId,title,instructions,subject,due,estimate,priority,type,steps,state,publishAt,attachments.firstOrNull().orEmpty(),attachments,points,comments)}.onSuccess{cloudMessage="Published to students.";perform(FeedbackKind.CONFIRM);composer=false;onRefresh()}.onFailure{cloudMessage=it.message.orEmpty()}};null
        }else "Reconnect to publish or save server classwork."
    }
    if(createClassOpen)CreateClassDialog(listOf(account),{createClassOpen=false}){name,section,teacher->if(cloudStatus.connection!=CloudConnection.LIVE)"Connect to the server before creating a classroom." else {cloudMessage="Creating classroom…";scope.launch{runCatching{gateway.createClassroom(name,section,teacher)}.onSuccess{perform(FeedbackKind.CONFIRM);createClassOpen=false;cloudMessage="";onRefresh()}.onFailure{cloudMessage=it.message.orEmpty()}};null}}
    if(announcementOpen)AnnouncementComposer(announcementClass?.let{listOf(it)}?:activeClasses,{announcementOpen=false;announcementClass=null}){classId,title,body,attachments,state,publishAt,pinned,comments->if(cloudStatus.connection!=CloudConnection.LIVE)"Connect to the server before posting." else {cloudMessage="Posting announcement…";scope.launch{runCatching{gateway.postAnnouncement(context,classId,title,body,attachments,state,publishAt,pinned,comments)}.onSuccess{perform(FeedbackKind.CONFIRM);announcementOpen=false;announcementClass=null;cloudMessage="";onRefresh()}.onFailure{cloudMessage=it.message.orEmpty()}};null}}
    manageAnnouncement?.let{item->ManageAnnouncementDialog(item,{manageAnnouncement=null}){title,body,attachments,state,publishAt,pinned,comments->if(cloudStatus.connection!=CloudConnection.LIVE)"Reconnect before changing this post." else {cloudMessage="Updating announcement…";scope.launch{runCatching{gateway.updateAnnouncement(context,item,title,body,attachments,state,publishAt,pinned,comments)}.onSuccess{perform(if(state==AnnouncementState.ARCHIVED)FeedbackKind.WARNING else FeedbackKind.CONFIRM);manageAnnouncement=null;cloudMessage="";onRefresh()}.onFailure{cloudMessage=it.message.orEmpty()}};null}}}
    if(progressOpen)ProgressDialog(activeClasses.flatMap{db.members(it.id)}.distinctBy{it.id},{progressOpen=false}){student,subject,criterion,level,note->val classId=activeClasses.firstOrNull{c->db.members(c.id).any{it.id==student}}?.id;if(classId==null){cloudMessage="Student classroom not found.";progressOpen=false}else{cloudMessage="Saving progress…";scope.launch{runCatching{gateway.recordProgress(student,classId,subject,criterion,level,note)}.onSuccess{perform(FeedbackKind.CONFIRM);progressOpen=false;cloudMessage="";onRefresh()}.onFailure{cloudMessage=it.message.orEmpty();progressOpen=false}}}}
    roster?.let{c->RosterDialog(c,db.members(c.id),emptyList(),{roster=null}){}}
    manageClass?.let{c->ManageClassDialog(c,{manageClass=null}){name,section,archived,grading->if(cloudStatus.connection!=CloudConnection.LIVE)"Reconnect before changing a classroom." else {cloudMessage="Updating classroom…";scope.launch{runCatching{gateway.updateClassroom(c.id,name,section,archived,grading)}.onSuccess{perform(if(archived)FeedbackKind.WARNING else FeedbackKind.CONFIRM);manageClass=null;cloudMessage="";onRefresh()}.onFailure{cloudMessage=it.message.orEmpty();manageClass=null}};null}}}
    manageAssignment?.let{a->AssignmentManagerDialog(a,db.assignmentRevisionCount(a.id),{manageAssignment=null},{manageAssignment=null;editAssignment=a},{manageAssignment=null;review=a},{runCatching{db.duplicateAssignmentAsDraft(account,a.id,maxOf(System.currentTimeMillis()+86_400_000,a.dueAtMillis+7L*86_400_000))}.onSuccess{perform(FeedbackKind.CONFIRM);manageAssignment=null;onRefresh()}.exceptionOrNull()?.message}){state,publishAt->
        if(cloudStatus.connection==CloudConnection.LIVE){cloudMessage="Updating assignment on the server…";scope.launch{runCatching{gateway.transitionAssignment(a,state,publishAt)}.onSuccess{cloudMessage="Assignment updated for students.";perform(if(state==AssignmentState.ARCHIVED)FeedbackKind.WARNING else FeedbackKind.CONFIRM);manageAssignment=null;onRefresh()}.onFailure{cloudMessage=it.message.orEmpty();manageAssignment=null}};null}
        else runCatching{db.setAssignmentState(account,a.id,state,publishAt)}.onSuccess{perform(if(state==AssignmentState.ARCHIVED)FeedbackKind.WARNING else FeedbackKind.CONFIRM);manageAssignment=null;onRefresh()}.exceptionOrNull()?.message
    }}
    editAssignment?.let{a->EditAssignmentDialog(a,activeClasses.firstOrNull{it.id==a.classroomId}?.gradingEnabled==true,{editAssignment=null}){title,instructions,subject,due,estimate,priority,type,steps,attachments,points,comments->if(cloudStatus.connection!=CloudConnection.LIVE)"Reconnect before editing classwork." else {cloudMessage="Saving assignment revision…";scope.launch{runCatching{gateway.updateAssignment(context,a,title,instructions,subject,due,estimate,priority,type,steps,attachments.firstOrNull().orEmpty(),attachments,points,comments)}.onSuccess{perform(FeedbackKind.CONFIRM);editAssignment=null;cloudMessage="";onRefresh()}.onFailure{cloudMessage=it.message.orEmpty();editAssignment=null}};null}}}
    review?.let{a->val submissions=db.submissionsForAssignment(a.id);val grading=activeClasses.firstOrNull{it.id==a.classroomId}?.gradingEnabled==true;SubmissionReviewDialog(a,submissions,db.accounts().associateBy{it.id},grading,{review=null}){id,state,feedback,grade->
        val submission=submissions.firstOrNull{it.id==id}?:return@SubmissionReviewDialog
        if(cloudStatus.connection==CloudConnection.LIVE){cloudMessage="Saving private review…";scope.launch{runCatching{gateway.reviewSubmission(submission,state,feedback,grade)}.onSuccess{perform(if(state==SubmissionState.COMPLETED)FeedbackKind.COMPLETE else FeedbackKind.CONFIRM);cloudMessage="Review delivered to the student.";review=null;onRefresh()}.onFailure{cloudMessage=it.message.orEmpty();review=null}}}
        else{cloudMessage="Reconnect before sending feedback or grades.";review=null}
    }}
}

@Composable
private fun ClassroomWorkspace(
    db:AppDatabase,
    account:Account,
    classroom:Classroom,
    refresh:Int,
    cloudStatus:CloudClassroomStatus,
    onBack:()->Unit,
    onOpenAssignment:(ClassroomAssignment)->Unit,
    onCreateAssignment:(()->Unit)?=null,
    onPostAnnouncement:(()->Unit)?=null,
    onReviewAssignment:((ClassroomAssignment)->Unit)?=null,
    gateway:FirebaseClassroomGateway?=null,
    onRefresh:()->Unit={},
    onManageAnnouncement:((Announcement)->Unit)?=null
){
    var tab by rememberSaveable(classroom.id){mutableStateOf(ClassroomTab.STREAM)}
    var query by rememberSaveable(classroom.id){mutableStateOf("")}
    var discussion by remember{mutableStateOf<Pair<String,String>?>(null)}
    val scope=rememberCoroutineScope()
    val managed=account.role in setOf(AccountRole.ADMIN,AccountRole.TEACHER)
    val assignments=remember(refresh,classroom.id,account.id){
        (if(managed)db.managedAssignmentsFor(account) else db.assignmentsFor(account)).filter{it.classroomId==classroom.id}
    }
    val announcements=remember(refresh,classroom.id,account.id){db.announcementsFor(account).filter{it.classroomId==classroom.id}}
    val members=remember(refresh,classroom.id){db.members(classroom.id).filter{it.active}}
    val students=remember(members){members.filter{it.role==AccountRole.STUDENT}}
    val coTeachers=remember(members){members.filter{it.role==AccountRole.TEACHER&&it.id!=classroom.teacherId}}
    val teacher=remember(refresh,classroom.teacherId){db.account(classroom.teacherId)}
    val visibleAssignments=remember(assignments,query){assignments.filter{query.isBlank()||listOf(it.title,it.subject,it.type,it.instructions).any{field->field.contains(query,true)}}}
    val upcoming=remember(assignments){assignments.filter{it.state==AssignmentState.PUBLISHED&&it.dueAtMillis>=System.currentTimeMillis()}.sortedBy{it.dueAtMillis}}
    Page(classroom.name,"${classroom.section.ifBlank{"Sabaq classroom"}} · ${students.size} students"){
        item{
            OutlinedButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null);Spacer(Modifier.width(7.dp));Text("All classes")}
        }
        item{
            Surface(color=Navy,shape=RoundedCornerShape(24.dp),modifier=Modifier.fillMaxWidth()){
                Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                    Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.AutoMirrored.Filled.MenuBook,null,tint=Gold);Spacer(Modifier.width(10.dp));Text(classroom.name,color=Color.White,fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleLarge)}
                    Text(if(cloudStatus.connection==CloudConnection.LIVE)"Live · changes sync to every member" else "Offline cache · reconnect before making changes",color=Color.White.copy(alpha=.72f),fontSize=12.sp)
                    if(upcoming.isNotEmpty())Text("Next: ${upcoming.first().title} · ${dateTime(upcoming.first().dueAtMillis)}",color=Gold,fontWeight=FontWeight.Bold,fontSize=13.sp)
                }
            }
        }
        item{
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(5.dp)){
                ClassroomTab.entries.forEach{choice->FilterChip(selected=tab==choice,onClick={tab=choice},label={Text(choice.label,fontSize=11.sp,maxLines=1)},modifier=Modifier.weight(1f))}
            }
        }
        when(tab){
            ClassroomTab.STREAM->{
                if(managed&&(onCreateAssignment!=null||onPostAnnouncement!=null))item{
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                        onPostAnnouncement?.let{action->Button(enabled=cloudStatus.connection==CloudConnection.LIVE,onClick=action,modifier=Modifier.weight(1f)){Icon(Icons.Default.Campaign,null);Spacer(Modifier.width(5.dp));Text("Post")}}
                        onCreateAssignment?.let{action->OutlinedButton(enabled=cloudStatus.connection==CloudConnection.LIVE,onClick=action,modifier=Modifier.weight(1f)){Icon(Icons.Default.Add,null);Spacer(Modifier.width(5.dp));Text("Classwork")}}
                    }
                }
                if(announcements.isEmpty()&&upcoming.isEmpty())item{EmptyCard("The stream is quiet","Announcements and newly published work appear here for everyone in the class.")}
                if(upcoming.isNotEmpty()){item{SectionTitle("Upcoming")};items(upcoming.take(3),key={"workspace-upcoming-${it.id}"}){a->AssignmentCard(a,"Due ${dateTime(a.dueAtMillis)}",onClick={onOpenAssignment(a)})}}
                if(announcements.isNotEmpty()){item{SectionTitle("Announcements")};items(announcements,key={"workspace-stream-${it.id}"}){announcement->AnnouncementCard(announcement,onComments={if(announcement.commentsEnabled)discussion="announcement" to announcement.id},onManage=if(managed){{onManageAnnouncement?.invoke(announcement)}}else null)}}
            }
            ClassroomTab.CLASSWORK->{
                item{OutlinedTextField(query,{query=it},modifier=Modifier.fillMaxWidth(),singleLine=true,label={Text("Search this class")},leadingIcon={Icon(Icons.Default.Search,null)},trailingIcon={if(query.isNotBlank())IconButton(onClick={query=""}){Icon(Icons.Default.Clear,"Clear")}})}
                if(managed&&onCreateAssignment!=null)item{Button(enabled=cloudStatus.connection==CloudConnection.LIVE,onClick=onCreateAssignment,modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Add,null);Spacer(Modifier.width(7.dp));Text("Create classwork")}}
                if(visibleAssignments.isEmpty())item{EmptyCard("No classwork","Assignments, practice, Quran, dua, and revision work can be organized here.")}else visibleAssignments.groupBy{it.subject.ifBlank{"General"}}.toSortedMap().forEach{(topic,itemsForTopic)->
                    item{SectionTitle(topic)}
                    items(itemsForTopic.sortedBy{it.dueAtMillis},key={"workspace-work-${it.id}"}){a->val submission=if(account.role==AccountRole.STUDENT)db.submissionFor(a.id,account.id)else null;val state=if(managed)"${a.state.name.lowercase().replace('_',' ')} · ${db.submissionsForAssignment(a.id).count{it.state==SubmissionState.HANDED_IN}} handed in" else submission?.state?.name?.lowercase()?.replace('_',' ')?:"assigned";AssignmentCard(a,state,{onOpenAssignment(a)}){if(a.commentsEnabled)discussion="assignment" to a.id}}
                }
            }
            ClassroomTab.PEOPLE->{
                item{SectionTitle(if(coTeachers.isEmpty())"Teacher" else "Teaching team")}
                item{PersonRow(teacher?.displayName?:"Sabaq teacher","Teacher",Icons.Default.School)}
                if(coTeachers.isNotEmpty())items(coTeachers,key={"workspace-teacher-${it.id}"}){member->PersonRow(member.displayName,"Co-teacher",Icons.Default.School)}
                item{SectionTitle("Students · ${students.size}")}
                if(students.isEmpty())item{EmptyCard("No students yet",if(managed)"Invite students from the administrator account, then add them to this class." else "The class roster will appear after students join.")}else items(students,key={"workspace-person-${it.id}"}){member->PersonRow(member.displayName,"Student",Icons.Default.AccountCircle)}
            }
            ClassroomTab.GRADES->{
                if(managed){
                    item{InfoCard(Icons.Default.Lock,"Private teacher view",if(classroom.gradingEnabled)"Points, grades, completion, and review status are private to approved staff." else "Completion tracking is enabled; points are turned off for this class.")}
                    if(assignments.isEmpty())item{EmptyCard("No gradebook rows","Create classwork to begin tracking completion.")}else items(assignments,key={"workspace-grade-${it.id}"}){a->val submissions=db.submissionsForAssignment(a.id);val done=submissions.count{it.state==SubmissionState.COMPLETED};val handed=submissions.count{it.state==SubmissionState.HANDED_IN};val percent=if(students.isEmpty())0 else done*100/students.size;val grades=submissions.mapNotNull{it.gradePoints};val average=grades.takeIf{it.isNotEmpty()}?.average();Card(colors=CardDefaults.cardColors(containerColor=Ivory),shape=RoundedCornerShape(18.dp),modifier=Modifier.fillMaxWidth().clickable{onReviewAssignment?.invoke(a)}){Column(Modifier.padding(15.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){Text(a.title,fontWeight=FontWeight.Bold);Text("$done completed · $handed waiting for review · ${students.size} assigned",fontSize=12.sp,color=Navy.copy(alpha=.65f));if(classroom.gradingEnabled&&a.pointsPossible!=null)Text(average?.let{"Class average ${String.format("%.1f",it)} / ${a.pointsPossible} · ${grades.size} graded"}?:"No private grades yet",fontSize=12.sp,color=Sage,fontWeight=FontWeight.Bold);LinearProgressIndicator(progress={percent/100f},modifier=Modifier.fillMaxWidth());Text("$percent% complete",fontSize=11.sp,color=Sage,fontWeight=FontWeight.Bold)}}}
                }else{
                    item{InfoCard(Icons.Default.VerifiedUser,"Your private progress",if(classroom.gradingEnabled)"Only you, your approved guardian, and your teachers can view grades and feedback." else "This class uses completion and feedback without points.")}
                    if(assignments.isEmpty())item{EmptyCard("No results yet","Your assignment status and private teacher feedback will appear here.")}else items(assignments,key={"workspace-student-grade-${it.id}"}){a->val submission=db.submissionFor(a.id,account.id);Card(colors=CardDefaults.cardColors(containerColor=Ivory),shape=RoundedCornerShape(18.dp),modifier=Modifier.fillMaxWidth().clickable{onOpenAssignment(a)}){Column(Modifier.padding(15.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){Text(a.title,fontWeight=FontWeight.Bold);Text(submission?.state?.name?.lowercase()?.replace('_',' ')?.replaceFirstChar(Char::uppercase)?:"Assigned",color=if(submission?.state==SubmissionState.COMPLETED)Sage else Navy.copy(alpha=.65f));if(classroom.gradingEnabled&&a.pointsPossible!=null)Text(submission?.gradePoints?.let{"$it / ${a.pointsPossible} points"}?:"Ungraded",fontWeight=FontWeight.Bold,color=Sage);if(submission?.feedback?.isNotBlank()==true)Text("Teacher feedback: ${submission.feedback}",fontSize=12.sp)}}}
                }
            }
        }
    }
    discussion?.let{(type,id)->CommentsDialog(db,account,type,id,students,cloudStatus.connection==CloudConnection.LIVE,{discussion=null},{body,visibility,studentId->gateway?.let{target->scope.launch{runCatching{target.postComment(type,id,body,visibility,studentId)}.onSuccess{onRefresh()}}}},{commentId->gateway?.let{target->scope.launch{runCatching{target.removeComment(commentId)}.onSuccess{onRefresh()}}}})}
}

@Composable
private fun CommentsDialog(db:AppDatabase,account:Account,entityType:String,entityId:String,students:List<Account>,live:Boolean,onDismiss:()->Unit,onPost:(String,CommentVisibility,String?)->Unit,onRemove:(String)->Unit){val comments=db.commentsFor(entityType,entityId,account);val accounts=db.accounts().associateBy{it.id};var body by rememberSaveable(entityId){mutableStateOf("")};var visibility by rememberSaveable(entityId){mutableStateOf(CommentVisibility.PUBLIC)};var studentId by remember(entityId){mutableStateOf(students.firstOrNull()?.id.orEmpty())};AlertDialog(onDismissRequest=onDismiss,title={Text("Discussion")},text={Column(Modifier.heightIn(max=540.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(9.dp)){if(comments.isEmpty())Text("No comments yet.",color=Navy.copy(alpha=.65f))else comments.forEach{comment->Surface(color=if(comment.visibility==CommentVisibility.PRIVATE)Gold.copy(alpha=.13f)else Canvas,shape=RoundedCornerShape(14.dp)){Column(Modifier.fillMaxWidth().padding(11.dp)){Row{Text(accounts[comment.authorId]?.displayName?:"Member",fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));Text(if(comment.visibility==CommentVisibility.PRIVATE)"Private" else "Class",fontSize=11.sp,color=Sage)};Text(if(comment.removed)"Comment removed" else comment.body,color=Navy.copy(alpha=if(comment.removed).45f else .8f));Text(dateTime(comment.createdAt),fontSize=10.sp,color=Navy.copy(alpha=.5f));if(!comment.removed&&(comment.authorId==account.id||account.role in setOf(AccountRole.ADMIN,AccountRole.TEACHER)))TextButton(onClick={onRemove(comment.id)}){Text("Remove")}}}};HorizontalDivider();OutlinedTextField(body,{body=it.take(2000)},label={Text("Add a comment")},minLines=2);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){FilterChip(selected=visibility==CommentVisibility.PUBLIC,onClick={visibility=CommentVisibility.PUBLIC},label={Text("Class")});FilterChip(selected=visibility==CommentVisibility.PRIVATE,onClick={visibility=CommentVisibility.PRIVATE},label={Text("Private")})};if(visibility==CommentVisibility.PRIVATE&&account.role in setOf(AccountRole.ADMIN,AccountRole.TEACHER))AccountDropdown("Student",studentId,students){studentId=it};if(!live)Text("Reconnect to post or moderate comments.",color=MaterialTheme.colorScheme.error,fontSize=12.sp)}},confirmButton={Button(enabled=live&&body.isNotBlank()&&(visibility==CommentVisibility.PUBLIC||account.role==AccountRole.STUDENT||studentId.isNotBlank()),onClick={onPost(body,visibility,studentId.takeIf{visibility==CommentVisibility.PRIVATE&&account.role!=AccountRole.STUDENT});body=""}){Text("Post")}},dismissButton={TextButton(onClick=onDismiss){Text("Close")}})}

@Composable
private fun PersonRow(name:String,role:String,icon:ImageVector){
    Surface(color=Ivory,shape=RoundedCornerShape(16.dp),modifier=Modifier.fillMaxWidth()){
        Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(40.dp).background(Gold.copy(alpha=.2f),CircleShape),contentAlignment=Alignment.Center){Icon(icon,null,tint=Navy)};Spacer(Modifier.width(12.dp));Column{Text(name,fontWeight=FontWeight.Bold);Text(role,color=Navy.copy(alpha=.58f),fontSize=12.sp)}}
    }
}

@Composable
private fun AssignmentComposer(classes:List<Classroom>,statusMessage:String="",onDismiss:()->Unit,onPublish:(String,String,String,String,Long,Int,String,String,List<String>,List<String>,AssignmentState,Long,Int?,Boolean)->String?){
    val context=LocalContext.current;var classId by remember{mutableStateOf(classes.firstOrNull()?.id.orEmpty())};var title by rememberSaveable{mutableStateOf("")};var instructions by rememberSaveable{mutableStateOf("")};var subject by rememberSaveable{mutableStateOf("Quran")};var type by rememberSaveable{mutableStateOf("Sabaq")};var steps by rememberSaveable{mutableStateOf("")};var estimate by rememberSaveable{mutableStateOf("30")};var priority by rememberSaveable{mutableStateOf("Standard")};var dueAt by rememberSaveable{mutableLongStateOf(System.currentTimeMillis()+86_400_000)};var publishAt by rememberSaveable{mutableLongStateOf(System.currentTimeMillis()+3_600_000)};var state by rememberSaveable{mutableStateOf(AssignmentState.PUBLISHED)};var attachments by remember{mutableStateOf<List<String>>(emptyList())};var points by rememberSaveable{mutableStateOf("")};var comments by rememberSaveable{mutableStateOf(true)};var error by remember{mutableStateOf("")}
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()){uris->attachments=uris.take(10).onEach{persistReadPermission(context,it)}.map(Uri::toString)};val selectedClass=classes.firstOrNull{it.id==classId};val validSchedule=state!=AssignmentState.SCHEDULED||(publishAt>System.currentTimeMillis()&&publishAt<dueAt)
    AlertDialog(onDismissRequest=onDismiss,title={Text("Create assignment")},text={Column(Modifier.heightIn(max=590.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(9.dp)){ClassDropdown(classId,classes){classId=it};AssignmentStateDropdown(state,listOf(AssignmentState.DRAFT,AssignmentState.SCHEDULED,AssignmentState.PUBLISHED)){state=it};if(state==AssignmentState.SCHEDULED)OutlinedButton(onClick={pickDateTime(context,publishAt){publishAt=it}},modifier=Modifier.fillMaxWidth()){Icon(Icons.AutoMirrored.Filled.ScheduleSend,null);Spacer(Modifier.width(6.dp));Text("Publish ${dateTime(publishAt)}")};OutlinedTextField(title,{title=it},label={Text("Title")});OutlinedTextField(instructions,{instructions=it},label={Text("Instructions")},minLines=2);OutlinedTextField(subject,{subject=it},label={Text("Subject")});OutlinedTextField(type,{type=it},label={Text("Work type · Sabaq, Quran, Dua…")});OutlinedTextField(steps,{steps=it},label={Text("Steps · one per line")},minLines=2);OutlinedTextField(estimate,{estimate=it.filter(Char::isDigit)},label={Text("Estimated minutes")});OutlinedTextField(priority,{priority=it},label={Text("Priority")});if(selectedClass?.gradingEnabled==true)OutlinedTextField(points,{points=it.filter(Char::isDigit)},label={Text("Points · leave blank for ungraded")},singleLine=true);Row(verticalAlignment=Alignment.CenterVertically){Switch(comments,{comments=it});Spacer(Modifier.width(8.dp));Text(if(comments)"Class discussion allowed" else "Discussion locked")};OutlinedButton(onClick={pickDateTime(context,dueAt){dueAt=it}},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Event,null);Spacer(Modifier.width(6.dp));Text("Due ${dateTime(dueAt)}")};OutlinedButton(onClick={picker.launch(arrayOf("image/*","application/pdf","text/plain"))},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.AttachFile,null);Spacer(Modifier.width(6.dp));Text(if(attachments.isEmpty())"Add images or files" else "${attachments.size} attachment(s) selected")};if(!validSchedule)Text("Scheduled publication must be before the due time.",color=MaterialTheme.colorScheme.error);if(statusMessage.isNotBlank())Text(statusMessage,color=if(statusMessage.startsWith("Publishing"))Sage else MaterialTheme.colorScheme.error);if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)}},confirmButton={Button(enabled=title.isNotBlank()&&classId.isNotBlank()&&dueAt>System.currentTimeMillis()&&validSchedule&&!statusMessage.startsWith("Publishing"),onClick={error=onPublish(classId,title,instructions,subject,dueAt,estimate.toIntOrNull()?:30,priority,type,steps.lines().filter(String::isNotBlank),attachments,state,publishAt,points.toIntOrNull(),comments).orEmpty()}){Text(when(state){AssignmentState.DRAFT->"Save draft";AssignmentState.SCHEDULED->"Schedule";else->"Publish"})}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})
}

@Composable
private fun AssignmentManagerDialog(assignment:ClassroomAssignment,revisionCount:Int,onDismiss:()->Unit,onEdit:()->Unit,onReview:()->Unit,onDuplicate:()->String?,onState:(AssignmentState,Long)->String?){val context=LocalContext.current;val choices=DomainPolicy.nextAssignmentStates(assignment.state).toList();var target by remember(assignment.id){mutableStateOf(choices.firstOrNull()?:assignment.state)};var publishAt by remember(assignment.id){mutableLongStateOf((System.currentTimeMillis()+3_600_000).coerceAtMost(assignment.dueAtMillis-60_000))};var error by remember{mutableStateOf("")};val valid=target!=AssignmentState.SCHEDULED||(publishAt>System.currentTimeMillis()&&publishAt<assignment.dueAtMillis);AlertDialog(onDismissRequest=onDismiss,title={Text(assignment.title)},text={Column(Modifier.heightIn(max=560.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(10.dp)){InfoCard(Icons.Default.History,"Revision ${assignment.revision}","$revisionCount prior snapshots · Last changed ${dateTime(assignment.updatedAtMillis)}");Text("Current state: ${assignment.state.name.lowercase().replace('_',' ')}",fontWeight=FontWeight.Bold);if(choices.isNotEmpty())AssignmentStateDropdown(target,choices){target=it};if(target==AssignmentState.SCHEDULED)OutlinedButton(onClick={pickDateTime(context,publishAt){publishAt=it}},modifier=Modifier.fillMaxWidth()){Icon(Icons.AutoMirrored.Filled.ScheduleSend,null);Spacer(Modifier.width(6.dp));Text("Publish ${dateTime(publishAt)}")};OutlinedButton(enabled=DomainPolicy.canEditAssignment(assignment),onClick=onEdit,modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Edit,null);Spacer(Modifier.width(6.dp));Text("Edit assignment details")};OutlinedButton(enabled=assignment.state in setOf(AssignmentState.PUBLISHED,AssignmentState.CLOSED),onClick=onReview,modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.RateReview,null);Spacer(Modifier.width(6.dp));Text("Review submissions")};OutlinedButton(onClick={error=onDuplicate().orEmpty()},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.ContentCopy,null);Spacer(Modifier.width(6.dp));Text("Reuse as next week's draft")};if(!valid)Text("Scheduled publication must be before the due time.",color=MaterialTheme.colorScheme.error);if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)}},confirmButton={Button(enabled=choices.isNotEmpty()&&valid,onClick={error=onState(target,publishAt).orEmpty()}){Text("Apply state")}},dismissButton={TextButton(onClick=onDismiss){Text("Close")}})}

@Composable
private fun EditAssignmentDialog(assignment:ClassroomAssignment,gradingEnabled:Boolean,onDismiss:()->Unit,onSave:(String,String,String,Long,Int,String,String,List<String>,List<String>,Int?,Boolean)->String?){val context=LocalContext.current;var title by rememberSaveable(assignment.id){mutableStateOf(assignment.title)};var instructions by rememberSaveable(assignment.id){mutableStateOf(assignment.instructions)};var subject by rememberSaveable(assignment.id){mutableStateOf(assignment.subject)};var type by rememberSaveable(assignment.id){mutableStateOf(assignment.type)};var steps by rememberSaveable(assignment.id){mutableStateOf(assignment.steps.joinToString("\n"))};var estimate by rememberSaveable(assignment.id){mutableStateOf(assignment.estimateMinutes.toString())};var priority by rememberSaveable(assignment.id){mutableStateOf(assignment.priority)};var dueAt by rememberSaveable(assignment.id){mutableLongStateOf(assignment.dueAtMillis)};var attachments by remember(assignment.id){mutableStateOf(assignment.attachmentUris)};var points by rememberSaveable(assignment.id){mutableStateOf(assignment.pointsPossible?.toString().orEmpty())};var comments by rememberSaveable(assignment.id){mutableStateOf(assignment.commentsEnabled)};var error by remember{mutableStateOf("")};val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()){uris->attachments=uris.take(10).onEach{persistReadPermission(context,it)}.map(Uri::toString)};AlertDialog(onDismissRequest=onDismiss,title={Text("Edit assignment")},text={Column(Modifier.heightIn(max=590.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(9.dp)){Text("Saving creates revision ${assignment.revision+1} and preserves the previous snapshot.",fontSize=12.sp,color=Navy.copy(alpha=.65f));OutlinedTextField(title,{title=it},label={Text("Title")});OutlinedTextField(instructions,{instructions=it},label={Text("Instructions")},minLines=2);OutlinedTextField(subject,{subject=it},label={Text("Subject")});OutlinedTextField(type,{type=it},label={Text("Work type")});OutlinedTextField(steps,{steps=it},label={Text("Steps · one per line")},minLines=2);OutlinedTextField(estimate,{estimate=it.filter(Char::isDigit)},label={Text("Estimated minutes")});OutlinedTextField(priority,{priority=it},label={Text("Priority")});if(gradingEnabled)OutlinedTextField(points,{points=it.filter(Char::isDigit)},label={Text("Points · blank is ungraded")});Row(verticalAlignment=Alignment.CenterVertically){Switch(comments,{comments=it});Spacer(Modifier.width(8.dp));Text(if(comments)"Class discussion allowed" else "Discussion locked")};OutlinedButton(onClick={pickDateTime(context,dueAt){dueAt=it}},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Event,null);Spacer(Modifier.width(6.dp));Text("Due ${dateTime(dueAt)}")};OutlinedButton(onClick={picker.launch(arrayOf("image/*","application/pdf","text/plain"))},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.AttachFile,null);Spacer(Modifier.width(6.dp));Text(if(attachments.isEmpty())"Add images or files" else "Replace ${attachments.size} attachment(s)")};if(attachments.isNotEmpty())TextButton(onClick={attachments=emptyList()}){Text("Remove all attachments")};if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)}},confirmButton={Button(enabled=title.trim().length>=2&&subject.isNotBlank()&&dueAt>System.currentTimeMillis(),onClick={error=onSave(title,instructions,subject,dueAt,estimate.toIntOrNull()?:30,priority,type,steps.lines().filter(String::isNotBlank),attachments,points.toIntOrNull(),comments).orEmpty()}){Text("Save revision")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})}

@Composable
private fun AssignmentStateDropdown(selected:AssignmentState,options:List<AssignmentState>,onSelect:(AssignmentState)->Unit){var open by remember{mutableStateOf(false)};Box{OutlinedButton(onClick={open=true},modifier=Modifier.fillMaxWidth()){Text("State: ${selected.name.lowercase().replace('_',' ')}")};DropdownMenu(open,{open=false}){options.forEach{state->DropdownMenuItem({Text(state.name.lowercase().replace('_',' ').replaceFirstChar(Char::uppercase))},{onSelect(state);open=false})}}}}

@Composable private fun AnnouncementComposer(classes:List<Classroom>,onDismiss:()->Unit,onPost:(String,String,String,List<String>,AnnouncementState,Long,Boolean,Boolean)->String?){val context=LocalContext.current;var classId by remember{mutableStateOf(classes.firstOrNull()?.id.orEmpty())};var title by rememberSaveable{mutableStateOf("")};var body by rememberSaveable{mutableStateOf("")};var attachments by remember{mutableStateOf<List<String>>(emptyList())};var state by rememberSaveable{mutableStateOf(AnnouncementState.PUBLISHED)};var publishAt by rememberSaveable{mutableLongStateOf(System.currentTimeMillis()+3_600_000)};var pinned by rememberSaveable{mutableStateOf(false)};var comments by rememberSaveable{mutableStateOf(true)};var error by remember{mutableStateOf("")};val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()){uris->attachments=uris.take(10).onEach{persistReadPermission(context,it)}.map(Uri::toString)};AlertDialog(onDismissRequest=onDismiss,title={Text("Class announcement")},text={Column(Modifier.heightIn(max=560.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(9.dp)){ClassDropdown(classId,classes){classId=it};Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){FilterChip(selected=state==AnnouncementState.PUBLISHED,onClick={state=AnnouncementState.PUBLISHED},label={Text("Post now")});FilterChip(selected=state==AnnouncementState.SCHEDULED,onClick={state=AnnouncementState.SCHEDULED},label={Text("Schedule")})};if(state==AnnouncementState.SCHEDULED)OutlinedButton(onClick={pickDateTime(context,publishAt){publishAt=it}},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Schedule,null);Spacer(Modifier.width(6.dp));Text("Publish ${dateTime(publishAt)}")};OutlinedTextField(title,{title=it},label={Text("Title")});OutlinedTextField(body,{body=it},label={Text("Message")},minLines=4);OutlinedButton(onClick={picker.launch(arrayOf("image/*","application/pdf","text/plain"))},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.AttachFile,null);Spacer(Modifier.width(6.dp));Text(if(attachments.isEmpty())"Add images or files" else "${attachments.size} attachment(s)")};Row(verticalAlignment=Alignment.CenterVertically){Checkbox(pinned,{pinned=it});Text("Pin to top of the stream")};Row(verticalAlignment=Alignment.CenterVertically){Switch(comments,{comments=it});Spacer(Modifier.width(8.dp));Text(if(comments)"Discussion allowed" else "Discussion locked")};if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)}},confirmButton={Button(enabled=classId.isNotBlank()&&title.isNotBlank()&&body.isNotBlank()&&(state!=AnnouncementState.SCHEDULED||publishAt>System.currentTimeMillis()),onClick={error=onPost(classId,title,body,attachments,state,publishAt,pinned,comments).orEmpty()}){Text(if(state==AnnouncementState.SCHEDULED)"Schedule" else "Post")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})}

@Composable private fun ManageAnnouncementDialog(item:Announcement,onDismiss:()->Unit,onSave:(String,String,List<String>,AnnouncementState,Long,Boolean,Boolean)->String?){val context=LocalContext.current;var title by rememberSaveable(item.id){mutableStateOf(item.title)};var body by rememberSaveable(item.id){mutableStateOf(item.body)};var attachments by remember(item.id){mutableStateOf(item.attachmentUris)};var state by rememberSaveable(item.id){mutableStateOf(item.state)};var publishAt by rememberSaveable(item.id){mutableLongStateOf(item.publishAt.coerceAtLeast(System.currentTimeMillis()+60_000))};var pinned by rememberSaveable(item.id){mutableStateOf(item.pinned)};var comments by rememberSaveable(item.id){mutableStateOf(item.commentsEnabled)};var error by remember{mutableStateOf("")};val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()){uris->attachments=uris.take(10).onEach{persistReadPermission(context,it)}.map(Uri::toString)};AlertDialog(onDismissRequest=onDismiss,title={Text("Manage announcement")},text={Column(Modifier.heightIn(max=570.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(9.dp)){Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){FilterChip(selected=state==AnnouncementState.PUBLISHED,onClick={state=AnnouncementState.PUBLISHED},label={Text("Published")});FilterChip(selected=state==AnnouncementState.SCHEDULED,onClick={state=AnnouncementState.SCHEDULED},label={Text("Scheduled")});FilterChip(selected=state==AnnouncementState.ARCHIVED,onClick={state=AnnouncementState.ARCHIVED},label={Text("Archive")})};if(state==AnnouncementState.SCHEDULED)OutlinedButton(onClick={pickDateTime(context,publishAt){publishAt=it}},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Schedule,null);Spacer(Modifier.width(6.dp));Text("Publish ${dateTime(publishAt)}")};OutlinedTextField(title,{title=it},label={Text("Title")});OutlinedTextField(body,{body=it},label={Text("Message")},minLines=4);OutlinedButton(onClick={picker.launch(arrayOf("image/*","application/pdf","text/plain"))},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.AttachFile,null);Spacer(Modifier.width(6.dp));Text(if(attachments.isEmpty())"Add images or files" else "Replace ${attachments.size} attachment(s)")};if(attachments.isNotEmpty())TextButton(onClick={attachments=emptyList()}){Text("Remove all attachments")};Row(verticalAlignment=Alignment.CenterVertically){Checkbox(pinned,{pinned=it});Text("Pin to top of the stream")};Row(verticalAlignment=Alignment.CenterVertically){Switch(comments,{comments=it});Spacer(Modifier.width(8.dp));Text(if(comments)"Discussion allowed" else "Discussion locked")};if(state==AnnouncementState.ARCHIVED)Text("Archiving removes this announcement from student streams.",color=MaterialTheme.colorScheme.error,fontSize=12.sp);if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)}},confirmButton={Button(enabled=title.isNotBlank()&&body.isNotBlank()&&(state!=AnnouncementState.SCHEDULED||publishAt>System.currentTimeMillis()),onClick={error=onSave(title,body,attachments,state,publishAt,pinned,comments).orEmpty()}){Text(if(state==AnnouncementState.ARCHIVED)"Archive" else "Save")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})}

@Composable private fun ProgressDialog(students:List<Account>,onDismiss:()->Unit,onSave:(String,String,String,Int,String)->Unit){var student by remember{mutableStateOf(students.firstOrNull()?.id.orEmpty())};var subject by rememberSaveable{mutableStateOf("Quran")};var criterion by rememberSaveable{mutableStateOf("Fluency")};var level by rememberSaveable{mutableFloatStateOf(3f)};var note by rememberSaveable{mutableStateOf("")};AlertDialog(onDismissRequest=onDismiss,title={Text("Progress record")},text={Column(verticalArrangement=Arrangement.spacedBy(9.dp)){AccountDropdown("Student",student,students){student=it};OutlinedTextField(subject,{subject=it},label={Text("Subject")});OutlinedTextField(criterion,{criterion=it},label={Text("Criterion")});Text("Level ${level.toInt()} of 5",fontWeight=FontWeight.Bold);Slider(level,{level=it},valueRange=1f..5f,steps=3);OutlinedTextField(note,{note=it},label={Text("Private note")},minLines=2)}},confirmButton={Button(enabled=student.isNotBlank()&&subject.isNotBlank()&&criterion.isNotBlank(),onClick={onSave(student,subject,criterion,level.toInt(),note)}){Text("Save")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})}

@Composable private fun ClassDropdown(selected:String,classes:List<Classroom>,onSelect:(String)->Unit){var open by remember{mutableStateOf(false)};Box{OutlinedButton(onClick={open=true},modifier=Modifier.fillMaxWidth()){Text("Class: ${classes.firstOrNull{it.id==selected}?.name?:"Choose"}")};DropdownMenu(open,{open=false}){classes.forEach{DropdownMenuItem({Text(it.name)},{onSelect(it.id);open=false})}}}}

@Composable private fun StudentClassFilter(classes:List<Classroom>,selected:String,onSelect:(String)->Unit){var open by remember{mutableStateOf(false)};Box{OutlinedButton(onClick={open=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.FilterList,null);Spacer(Modifier.width(8.dp));Text(if(selected.isBlank())"All classrooms" else classes.firstOrNull{it.id==selected}?.name?:"All classrooms",modifier=Modifier.weight(1f));Icon(Icons.Default.ExpandMore,null)};DropdownMenu(open,{open=false}){DropdownMenuItem({Text("All classrooms")},{onSelect("");open=false});classes.forEach{item->DropdownMenuItem({Text(item.name)},{onSelect(item.id);open=false})}}}}

@Composable
private fun SubmissionReviewDialog(assignment:ClassroomAssignment,submissions:List<StudentSubmission>,accounts:Map<String,Account>,gradingEnabled:Boolean,onDismiss:()->Unit,onReview:(String,SubmissionState,String,Int?)->Unit){val context=LocalContext.current;var selected by remember{mutableStateOf<StudentSubmission?>(null)};var feedback by rememberSaveable{mutableStateOf("")};var grade by rememberSaveable{mutableStateOf("")};var result by remember{mutableStateOf(SubmissionState.RETURNED)};AlertDialog(onDismissRequest=onDismiss,title={Text(assignment.title)},text={Column(Modifier.heightIn(max=540.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){if(submissions.isEmpty())Text("No submissions yet.") else submissions.forEach{s->Surface(color=if(selected?.id==s.id)Gold.copy(alpha=.18f)else Canvas,shape=RoundedCornerShape(12.dp),modifier=Modifier.fillMaxWidth().clickable{selected=s;feedback=s.feedback;grade=s.gradePoints?.toString().orEmpty();result=if(s.state==SubmissionState.COMPLETED)SubmissionState.COMPLETED else SubmissionState.RETURNED}){Column(Modifier.padding(10.dp)){Text(accounts[s.studentId]?.displayName?:"Student",fontWeight=FontWeight.Bold);Text(s.note.ifBlank{"No written response"});if(s.attachmentUris.isNotEmpty())Text("${s.attachmentUris.size} attachment(s)",fontSize=12.sp,color=Sage,fontWeight=FontWeight.Bold);if(s.gradePoints!=null)Text("Grade: ${s.gradePoints}/${assignment.pointsPossible?:"—"}",fontWeight=FontWeight.Bold,color=Sage);Text(s.state.name.lowercase().replace('_',' '),fontSize=12.sp,color=Navy.copy(alpha=.6f))}}};selected?.attachmentUris?.forEachIndexed{index,uri->OutlinedButton(onClick={openAttachment(context,uri)},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.AttachFile,null);Spacer(Modifier.width(6.dp));Text("Open attachment ${index+1}")}};if(selected!=null){OutlinedTextField(feedback,{feedback=it},label={Text("Private feedback")});if(gradingEnabled&&assignment.pointsPossible!=null)OutlinedTextField(grade,{grade=it.filter(Char::isDigit)},label={Text("Private grade out of ${assignment.pointsPossible}")},singleLine=true);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){FilterChip(selected=result==SubmissionState.RETURNED,onClick={result=SubmissionState.RETURNED},label={Text("Return")});FilterChip(selected=result==SubmissionState.COMPLETED,onClick={result=SubmissionState.COMPLETED},label={Text("Complete")})}}}},confirmButton={Button(enabled=(selected?.state==SubmissionState.HANDED_IN||selected?.state==SubmissionState.RETURNED)&&(grade.toIntOrNull()?.let{it<=(assignment.pointsPossible?:it)}!=false),onClick={onReview(selected!!.id,result,feedback,grade.toIntOrNull())}){Text("Save review")}},dismissButton={TextButton(onClick=onDismiss){Text("Close")}})}

@Composable
private fun StudentClasswork(db:AppDatabase,account:Account,refresh:Int,gateway:FirebaseClassroomGateway,cloudStatus:CloudClassroomStatus,onRefresh:()->Unit,perform:(FeedbackKind)->Unit){val context=LocalContext.current;val scope=rememberCoroutineScope();val work=remember(refresh){db.assignmentsFor(account)};val submissions=remember(refresh){work.associate{it.id to db.submissionFor(it.id,account.id)}};val announcements=remember(refresh){db.announcementsFor(account)};val classes=remember(refresh){db.classroomsFor(account)};var cloudMessage by remember{mutableStateOf("")};var query by rememberSaveable{mutableStateOf("")};var classFilter by rememberSaveable{mutableStateOf("")};val visibleWork=remember(work,query,classFilter){work.filter{a->(classFilter.isBlank()||a.classroomId==classFilter)&&(query.isBlank()||listOf(a.title,a.subject,a.type,a.instructions).any{it.contains(query,true)})}};val sectioned=remember(visibleWork,submissions){visibleWork.map{it to submissions[it.id]}.groupBy{DomainPolicy.section(it.first,it.second)}};val now=System.currentTimeMillis();val dueSoon=remember(work,now){work.filter{it.dueAtMillis in now..(now+72L*60L*60L*1000L)}};val handedIn=remember(submissions){submissions.values.count{it?.state==SubmissionState.HANDED_IN||it?.state==SubmissionState.COMPLETED}};var openedClass by remember{mutableStateOf<Classroom?>(null)};var selected by remember{mutableStateOf<ClassroomAssignment?>(null)};if(openedClass!=null)ClassroomWorkspace(db,account,openedClass!!,refresh,cloudStatus,{openedClass=null},{a->selected=a},gateway=gateway,onRefresh=onRefresh) else Page("Classroom","Choose a class to open its Stream, Classwork, People, and Grades workspace"){
    item{InfoCard(if(cloudStatus.connection==CloudConnection.LIVE)Icons.Default.CloudDone else Icons.Default.CloudOff,if(cloudStatus.connection==CloudConnection.LIVE)"Live classroom connected" else "Using cached classroom data",cloudStatus.message)}
    item{Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){Metric("Assigned",work.size.toString(),Icons.AutoMirrored.Filled.Assignment,Modifier.weight(1f));Metric("Due soon",dueSoon.size.toString(),Icons.Default.NotificationsActive,Modifier.weight(1f));Metric("Handed in",handedIn.toString(),Icons.Default.TaskAlt,Modifier.weight(1f))}}
    item{OutlinedTextField(query,{query=it},modifier=Modifier.fillMaxWidth(),singleLine=true,label={Text("Search classwork")},leadingIcon={Icon(Icons.Default.Search,null)},trailingIcon={if(query.isNotBlank())IconButton(onClick={query=""}){Icon(Icons.Default.Clear,"Clear search")}})}
    if(classes.size>1)item{StudentClassFilter(classes,classFilter){classFilter=it}}
    if(classes.isEmpty())item{EmptyCard("No classroom yet","An administrator or teacher can add this account to a classroom.")}else{item{SectionTitle("My classrooms")};items(classes,key={"student-class-${it.id}"}){c->val teacher=db.account(c.teacherId);Card(modifier=Modifier.fillMaxWidth().clickable{openedClass=c},colors=CardDefaults.cardColors(containerColor=Ivory),shape=RoundedCornerShape(18.dp)){Row(Modifier.fillMaxWidth().padding(15.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(44.dp).background(Gold.copy(alpha=.2f),RoundedCornerShape(14.dp)),contentAlignment=Alignment.Center){Icon(Icons.Default.Groups,null,tint=Navy)};Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(c.name,fontWeight=FontWeight.Bold);Text("${c.section.ifBlank{"Classroom"}} · ${teacher?.displayName?:"Teacher"} · ${work.count{it.classroomId==c.id}} assignments",color=Navy.copy(alpha=.6f),fontSize=12.sp)};Icon(Icons.Default.ChevronRight,"Open classroom")}}}}
    if(announcements.isNotEmpty()){item{SectionTitle("Stream")};items(announcements.take(5),key={it.id}){AnnouncementCard(it)}}
    if(dueSoon.isNotEmpty()){item{SectionTitle("Upcoming reminders")};items(dueSoon,key={"reminder-${it.id}"}){a->InfoCard(Icons.Default.Alarm,"${a.title} · ${a.subject}","Due ${dateTime(a.dueAtMillis)} · ${a.estimateMinutes} min")}}
    if(work.isEmpty())item{EmptyCard("Nothing assigned","Published classroom work will appear here.")}else if(visibleWork.isEmpty())item{EmptyCard("No matching classwork","Try a different search or classroom filter.")}else WorkSection.entries.forEach{section->sectioned[section]?.takeIf{it.isNotEmpty()}?.let{group->item{SectionTitle(section.label)};items(group,key={it.first.id}){(a,_)->AssignmentCard(a,section.label.lowercase(),onClick={selected=a})}}}
    item{Spacer(Modifier.height(70.dp))}
    }
    selected?.let{a->val current=db.submissionFor(a.id,account.id);val reminder=db.reminderPreference(a.id,account.id);HandInDialog(a,current,reminder,cloudMessage,{selected=null;cloudMessage=""},{preference->db.saveReminderPreference(preference);NotificationScheduler.scheduleAssignment(context,a,preference);perform(FeedbackKind.SELECT);onRefresh()},{note,attachment->
        if(cloudStatus.connection==CloudConnection.LIVE){cloudMessage="Saving server draft…";scope.launch{runCatching{gateway.saveSubmission(context,a,note,current,false,attachment)}.onSuccess{perform(FeedbackKind.CONFIRM);selected=null;cloudMessage="";onRefresh()}.onFailure{cloudMessage=it.message.orEmpty()}}}
        else cloudMessage="Reconnect to save your draft securely."
    },{
        if(cloudStatus.connection==CloudConnection.LIVE&&current!=null){cloudMessage="Updating server submission…";scope.launch{runCatching{gateway.unsubmit(a.id,current)}.onSuccess{perform(FeedbackKind.WARNING);selected=null;cloudMessage="";onRefresh()}.onFailure{cloudMessage=it.message.orEmpty()}}}
        else cloudMessage="Reconnect before changing a handed-in submission."
    }){note,attachment->
        if(cloudStatus.connection==CloudConnection.LIVE){cloudMessage="Handing in securely…";scope.launch{runCatching{gateway.saveSubmission(context,a,note,current,true,attachment)}.onSuccess{perform(FeedbackKind.COMPLETE);selected=null;cloudMessage="";onRefresh()}.onFailure{cloudMessage=it.message.orEmpty()}}}
        else cloudMessage="Reconnect to hand in your work."
    }}
}

@Composable
private fun HandInDialog(assignment:ClassroomAssignment,current:StudentSubmission?,reminder:AssignmentReminderPreference,statusMessage:String="",onDismiss:()->Unit,onReminder:(AssignmentReminderPreference)->Unit,onSaveDraft:(String,String)->Unit,onUnsubmit:()->Unit,onHandIn:(String,String)->Unit){val context=LocalContext.current;var note by rememberSaveable{mutableStateOf(current?.note.orEmpty())};var attachment by rememberSaveable{mutableStateOf(current?.attachmentUri.orEmpty())};val busy=statusMessage.endsWith("…");val hasAnswer=note.isNotBlank()||attachment.isNotBlank();val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->uri?.let{persistReadPermission(context,it);attachment=it.toString()}};AlertDialog(onDismissRequest=onDismiss,title={Text(assignment.title)},text={Column(Modifier.heightIn(max=560.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(10.dp)){Text(assignment.instructions.ifBlank{"No additional instructions."});Text("${assignment.type} · Due ${dateTime(assignment.dueAtMillis)}",fontWeight=FontWeight.Bold);if(assignment.pointsPossible!=null)Text("${assignment.pointsPossible} points",color=Sage,fontWeight=FontWeight.Bold);assignment.steps.forEachIndexed{i,step->Text("${i+1}. $step")};assignment.attachmentUris.forEachIndexed{index,uri->OutlinedButton(onClick={openAttachment(context,uri)},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.AttachFile,null);Spacer(Modifier.width(6.dp));Text("Open teacher attachment ${index+1}")}};OutlinedButton(onClick={addToCalendar(context,assignment)},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.EventAvailable,null);Spacer(Modifier.width(6.dp));Text("Add due date to calendar")};Text("Remind me",fontWeight=FontWeight.Bold);Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){FilterChip(selected=!reminder.enabled,onClick={onReminder(reminder.copy(enabled=false))},label={Text("Off")});listOf(1,4).forEach{hours->FilterChip(selected=reminder.enabled&&reminder.leadHours==hours,onClick={onReminder(reminder.copy(enabled=true,leadHours=hours))},label={Text("${hours}h")})}};Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf(24,48).forEach{hours->FilterChip(selected=reminder.enabled&&reminder.leadHours==hours,onClick={onReminder(reminder.copy(enabled=true,leadHours=hours))},label={Text(if(hours==24)"1 day" else "2 days")})}};Text("Reminder notifications keep assignment details private on the lock screen.",fontSize=11.sp,color=Navy.copy(alpha=.6f));OutlinedTextField(note,{note=it},label={Text("Written response")},minLines=3);OutlinedButton(onClick={picker.launch(arrayOf("image/*","application/pdf","text/plain"))},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.UploadFile,null);Spacer(Modifier.width(6.dp));Text(if(attachment.isBlank())"Attach photo or document" else "Replace attachment")};if(attachment.isNotBlank())OutlinedButton(onClick={openAttachment(context,attachment)},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Visibility,null);Spacer(Modifier.width(6.dp));Text("Preview selected attachment")};current?.handedInAtMillis?.let{InfoCard(Icons.AutoMirrored.Filled.ReceiptLong,"Submission receipt","Handed in ${dateTime(it)}")};if(current?.gradePoints!=null)InfoCard(Icons.Default.Grade,"Private grade","${current.gradePoints} / ${assignment.pointsPossible?:"—"} points");if(current?.feedback?.isNotBlank()==true)InfoCard(Icons.Default.Feedback,"Teacher feedback",current.feedback);if(statusMessage.isNotBlank())Text(statusMessage,color=if(busy)Sage else MaterialTheme.colorScheme.error);if(DomainPolicy.canSaveSubmissionDraft(assignment,current))OutlinedButton(enabled=hasAnswer&&!busy,onClick={onSaveDraft(note,attachment)},modifier=Modifier.fillMaxWidth()){Text(if(statusMessage.contains("server",true))"Save server draft" else "Save draft")};if(DomainPolicy.canUnsubmit(assignment,current))OutlinedButton(enabled=!busy,onClick=onUnsubmit,modifier=Modifier.fillMaxWidth()){Icon(Icons.AutoMirrored.Filled.Undo,null);Spacer(Modifier.width(6.dp));Text("Unsubmit and continue editing")}}},confirmButton={Button(enabled=hasAnswer&&DomainPolicy.canSubmit(assignment,current)&&!busy,onClick={onHandIn(note,attachment)}){Text(if(current==null||current.state==SubmissionState.STARTED)"Hand in" else "Resubmit")}},dismissButton={TextButton(enabled=!busy,onClick=onDismiss){Text("Close")}})}

@Composable
private fun PlannerScreen(db:AppDatabase,account:Account,refresh:Int,onRefresh:()->Unit,perform:(FeedbackKind)->Unit){val tasks=remember(refresh){db.personalTasks(account.id)};var addOpen by rememberSaveable{mutableStateOf(false)};Page("My planner","Private tasks stay separate from teacher-controlled work"){
    item{InfoCard(Icons.Default.Lightbulb,"Planning coach",if(tasks.none{!it.completed})"Add a short revision task for the week." else "Start with ${tasks.first{!it.completed}.estimateMinutes.coerceAtMost(25)} minutes on ${tasks.first{!it.completed}.title}.")}
    item{Button(onClick={addOpen=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Add,null);Spacer(Modifier.width(8.dp));Text("Add personal task")}}
    if(tasks.isEmpty())item{EmptyCard("No personal tasks","Use this area for private revision and preparation.")}else items(tasks,key={it.id}){t->Surface(color=Ivory,shape=RoundedCornerShape(18.dp)){Row(Modifier.fillMaxWidth().padding(14.dp),verticalAlignment=Alignment.CenterVertically){Checkbox(t.completed,{db.togglePersonalTask(t.id,it);perform(if(it)FeedbackKind.COMPLETE else FeedbackKind.SELECT);onRefresh()});Column{Text(t.title,fontWeight=FontWeight.Bold);Text("${t.estimateMinutes} min · ${dateTime(t.dueAtMillis)}",color=Navy.copy(alpha=.6f),fontSize=12.sp)}}}}
    item{Spacer(Modifier.height(70.dp))}
    }
    if(addOpen)AddTaskDialog({addOpen=false}){title,minutes->db.addPersonalTask(account.id,title,System.currentTimeMillis()+86_400_000,minutes);perform(FeedbackKind.CONFIRM);addOpen=false;onRefresh()}
}

@Composable private fun AddTaskDialog(onDismiss:()->Unit,onAdd:(String,Int)->Unit){var title by rememberSaveable{mutableStateOf("")};var minutes by rememberSaveable{mutableStateOf("25")};AlertDialog(onDismissRequest=onDismiss,title={Text("Personal task")},text={Column{OutlinedTextField(title,{title=it},label={Text("Title")});OutlinedTextField(minutes,{minutes=it.filter(Char::isDigit)},label={Text("Minutes")})}},confirmButton={Button(enabled=title.isNotBlank(),onClick={onAdd(title,minutes.toIntOrNull()?:25)}){Text("Add")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})}

@Composable
private fun ClassroomList(db:AppDatabase,account:Account,refresh:Int,perform:(FeedbackKind)->Unit){val classes=remember(refresh){db.classroomsFor(account)};val accounts=remember(refresh){db.accounts().associateBy{it.id}};Page("Classrooms","Teachers and approved classroom members"){
    if(classes.isEmpty())item{EmptyCard("No classrooms","An administrator can add this account to a classroom.")}else items(classes,key={it.id}){c->Card(colors=CardDefaults.cardColors(containerColor=Ivory),shape=RoundedCornerShape(20.dp)){Column(Modifier.padding(16.dp)){Text(c.name,fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleMedium);Text("Teacher: ${accounts[c.teacherId]?.displayName?:"Not assigned"}");Text("${db.members(c.id).size} students",color=Navy.copy(alpha=.6f))}}}
}}

@Composable private fun GuardianClassrooms(db:AppDatabase,account:Account,refresh:Int){val wards=remember(refresh){db.wards(account.id)};val accounts=remember(refresh){db.accounts().associateBy{it.id}};val classrooms=remember(refresh){wards.flatMap{db.classroomsFor(it).map{c->it to c}}};Page("Family classrooms","Read-only rosters for linked students"){
    if(classrooms.isEmpty())item{EmptyCard("No classrooms","Linked student classrooms will appear here.")}else items(classrooms,key={"${it.first.id}-${it.second.id}"}){(ward,c)->Card(colors=CardDefaults.cardColors(containerColor=Ivory),shape=RoundedCornerShape(20.dp)){Column(Modifier.padding(16.dp)){Text(c.name,fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleMedium);Text("Student: ${ward.displayName}");Text("Teacher: ${accounts[c.teacherId]?.displayName?:"Not assigned"}",color=Navy.copy(alpha=.65f));Text("${db.members(c.id).size} students",color=Navy.copy(alpha=.65f))}}}
}}

@Composable
private fun SettingsScreen(db:AppDatabase,account:Account,settings:FeedbackSettings,firebaseIdentity:FirebaseIdentity?,googleBusy:Boolean,googleStatus:String,cloudStatus:CloudClassroomStatus,onRefresh:()->Unit,onReconnectCloud:()->Unit,onActivateCloudAccount:(String,String,(String?)->Unit)->Unit,onFeedback:(FeedbackSettings)->Unit,onUpdates:()->Unit,onNotifications:()->Unit,onLinkGoogle:()->Unit){
    val context=LocalContext.current
    val identityLink=db.federatedIdentityForAccount(account.id)
    var passwordOpen by rememberSaveable{mutableStateOf(false)}
    var historyOpen by rememberSaveable{mutableStateOf(false)}
    var invitationOpen by rememberSaveable{mutableStateOf(false)}
    var invitationStatus by remember{mutableStateOf("")}
    Page("Settings","Account, feedback, notifications, updates, and privacy"){
        item{SectionTitle("Feedback")}
        item{SettingPicker("Haptics",settings.haptics.name.lowercase().replaceFirstChar(Char::uppercase),HapticLevel.entries.map{it.name}){onFeedback(settings.copy(haptics=HapticLevel.valueOf(it)))}}
        item{SettingPicker("Interaction sounds",settings.sounds.name.lowercase().replaceFirstChar(Char::uppercase),SoundLevel.entries.map{it.name}){onFeedback(settings.copy(sounds=SoundLevel.valueOf(it)))}}
        item{SectionTitle("Notifications")}
        item{OutlinedButton(onClick=onNotifications,modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Notifications,null);Spacer(Modifier.width(8.dp));Text("Allow assignment reminders")}}
        item{OutlinedButton(onClick={if(!NotificationScheduler.sendTest(context))onNotifications()},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.NotificationAdd,null);Spacer(Modifier.width(8.dp));Text("Send test notification")}}
        item{SectionTitle("Account and data")}
        item{InfoCard(Icons.Default.AccountCircle,"Google account",when{
            identityLink!=null->"${identityLink.email.ifBlank{firebaseIdentity?.email.orEmpty()}} · linked to ${account.displayName} (${account.role.name.lowercase()})"
            firebaseIdentity!=null->"${firebaseIdentity.email.ifBlank{"Google account"}} is authenticated and ready to link to this approved Sabaq profile."
            else->"Not linked. Google verifies identity; the Sabaq backend or an administrator controls the classroom role."
        })}
        if(identityLink==null)item{Button(onClick=onLinkGoogle,enabled=!googleBusy,modifier=Modifier.fillMaxWidth()){
            if(googleBusy)CircularProgressIndicator(Modifier.size(18.dp),strokeWidth=2.dp,color=Color.White)else Icon(Icons.Default.Link,null)
            Spacer(Modifier.width(8.dp));Text("Link Google account")
        }}
        if(googleStatus.isNotBlank())item{Text(googleStatus,color=if(googleStatus.startsWith("Google account linked"))Sage else MaterialTheme.colorScheme.error,fontSize=13.sp)}
        item{OutlinedButton(onClick={passwordOpen=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Password,null);Spacer(Modifier.width(8.dp));Text("Change fallback password")}}
        item{BackupControls(db,account,onRefresh)}
        item{InfoCard(Icons.Default.PrivacyTip,"Privacy status","Server roles come only from administrator-issued invitations and Firebase custom claims. The app never grants itself teacher or administrator access.")}
        item{SectionTitle("Sync")}
        item{InfoCard(if(cloudStatus.connection==CloudConnection.LIVE)Icons.Default.CloudDone else Icons.Default.CloudOff,cloudStatus.connection.name.lowercase().replace('_',' ').replaceFirstChar(Char::uppercase),cloudStatus.message+" Cached work remains available on this device.")}
        if(cloudStatus.connection==CloudConnection.NEEDS_ACTIVATION)item{Button(onClick={invitationOpen=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.VpnKey,null);Spacer(Modifier.width(8.dp));Text("Activate with invitation code")}}
        if(cloudStatus.connection!=CloudConnection.LIVE&&identityLink!=null)item{OutlinedButton(onClick=onReconnectCloud,modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Sync,null);Spacer(Modifier.width(8.dp));Text("Retry server connection")}}
        if(invitationStatus.isNotBlank())item{Text(invitationStatus,color=if(invitationStatus.startsWith("Activated"))Sage else MaterialTheme.colorScheme.error,fontSize=13.sp)}
        item{SectionTitle("Updates and about")}
        item{InfoCard(Icons.Default.Info,"Installed version","$VERSION_NAME · Build $BUILD_NUMBER\nPackage: ${BuildConfig.APPLICATION_ID}")}
        item{Button(onClick=onUpdates,modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.SystemUpdate,null);Spacer(Modifier.width(8.dp));Text("Check for updates")}}
        item{OutlinedButton(onClick={historyOpen=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.History,null);Spacer(Modifier.width(8.dp));Text("View update history")}}
        ReleaseHistory.forBuild(BUILD_NUMBER)?.let{release->item{InfoCard(Icons.Default.NewReleases,"What’s new · Build ${release.buildNumber}",release.changes.joinToString("\n") { "• $it" })}}
    }
    if(passwordOpen)PasswordDialog({passwordOpen=false}){current,replacement->runCatching{db.changePassword(account,current.toCharArray(),replacement.toCharArray())}.onSuccess{passwordOpen=false}.exceptionOrNull()?.message}
    if(historyOpen)ReleaseHistoryDialog{historyOpen=false}
    if(invitationOpen)InvitationCodeDialog({invitationOpen=false}){code,password,complete->
        onActivateCloudAccount(code,password){message->
            if(message==null){invitationStatus="Activated securely.";invitationOpen=false;onRefresh();onReconnectCloud()}
            complete(message)
        }
    }
}

@Composable private fun InvitationCodeDialog(onDismiss:()->Unit,onActivate:(String,String,(String?)->Unit)->Unit){var code by rememberSaveable{mutableStateOf("")};var password by rememberSaveable{mutableStateOf("")};var confirmation by rememberSaveable{mutableStateOf("")};var error by remember{mutableStateOf("")};var busy by remember{mutableStateOf(false)};AlertDialog(onDismissRequest={if(!busy)onDismiss()},icon={Icon(Icons.Default.VpnKey,null,tint=Gold)},title={Text("Activate classroom account")},text={Column(verticalArrangement=Arrangement.spacedBy(9.dp)){Text("Use the one-time code from your madressah administrator. The invited email must exactly match this verified Google account.");OutlinedTextField(code,{code=it.trim()},label={Text("Invitation code")},singleLine=true);OutlinedTextField(password,{password=it},label={Text("Create Sabaq password · 10+ characters")},singleLine=true,visualTransformation=PasswordVisualTransformation());OutlinedTextField(confirmation,{confirmation=it},label={Text("Confirm password")},singleLine=true,visualTransformation=PasswordVisualTransformation());if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)}},confirmButton={Button(enabled=code.length>=40&&password.length>=10&&password==confirmation&&!busy,onClick={busy=true;error="";onActivate(code,password){message->busy=false;error=message.orEmpty()}}){if(busy)CircularProgressIndicator(Modifier.size(18.dp),strokeWidth=2.dp,color=Color.White)else Text("Activate securely")}},dismissButton={TextButton(enabled=!busy,onClick=onDismiss){Text("Cancel")}})}

@Composable private fun PasswordDialog(onDismiss:()->Unit,onChange:(String,String)->String?){var current by rememberSaveable{mutableStateOf("")};var replacement by rememberSaveable{mutableStateOf("")};var confirmation by rememberSaveable{mutableStateOf("")};var error by rememberSaveable{mutableStateOf("")};AlertDialog(onDismissRequest=onDismiss,title={Text("Change password")},text={Column(verticalArrangement=Arrangement.spacedBy(9.dp)){OutlinedTextField(current,{current=it},label={Text("Current password")},visualTransformation=PasswordVisualTransformation());OutlinedTextField(replacement,{replacement=it},label={Text("New password · 10+ characters")},visualTransformation=PasswordVisualTransformation());OutlinedTextField(confirmation,{confirmation=it},label={Text("Confirm new password")},visualTransformation=PasswordVisualTransformation());if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)}},confirmButton={Button(enabled=replacement.length>=10&&replacement==confirmation,onClick={error=onChange(current,replacement).orEmpty();if(error.isBlank()){current="";replacement="";confirmation=""}}){Text("Change")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})}

@Composable private fun SettingPicker(title:String,value:String,options:List<String>,onSelect:(String)->Unit){var open by remember{mutableStateOf(false)};Card(colors=CardDefaults.cardColors(containerColor=Ivory),shape=RoundedCornerShape(18.dp)){Row(Modifier.fillMaxWidth().clickable{open=true}.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(title,fontWeight=FontWeight.Bold);Text(value,color=Navy.copy(alpha=.6f))};Icon(Icons.Default.ExpandMore,null)};DropdownMenu(open,{open=false}){options.forEach{DropdownMenuItem({Text(it.lowercase().replaceFirstChar(Char::uppercase))},{onSelect(it);open=false})}}}}

@Composable
private fun UpdateDialog(onDismiss:()->Unit){val context=LocalContext.current;val scope=rememberCoroutineScope();var message by remember{mutableStateOf("Securely check the dedicated Sabaq Workspace release feed.")};var available by remember{mutableStateOf<UpdateInfo?>(null)};var busy by remember{mutableStateOf(false)};AlertDialog(onDismissRequest={if(!busy)onDismiss()},icon={Icon(Icons.Default.SystemUpdate,null,tint=Gold)},title={Text("App updates")},text={Column(verticalArrangement=Arrangement.spacedBy(10.dp)){Surface(color=Gold.copy(alpha=.14f),shape=RoundedCornerShape(14.dp)){Column(Modifier.fillMaxWidth().padding(12.dp)){Text("Installed",fontWeight=FontWeight.Bold);Text("$VERSION_NAME · Build $BUILD_NUMBER",color=Navy.copy(alpha=.7f))}};Text(message)}},confirmButton={Button(enabled=!busy,onClick={busy=true;scope.launch{val ready=available;if(ready==null){message="Checking…";runCatching{withContext(Dispatchers.IO){UpdateManager.check()}}.onSuccess{if(it.versionCode>UpdateManager.installedVersionCode(context)){available=it;message="Available: ${it.versionName} · Build ${it.versionCode}\n\n${it.notes}"}else message="You already have the newest published build."}.onFailure{message="Could not check safely. ${it.message.orEmpty()}"}}else{message="Downloading and verifying ${ready.versionName}…";runCatching{withContext(Dispatchers.IO){UpdateManager.downloadAndVerify(context,ready)}}.onSuccess{UpdateManager.openInstaller(context,it);onDismiss()}.onFailure{message="Update stopped safely. ${it.message.orEmpty()}"}};busy=false}}){Text(if(available==null)"Check" else "Download")}},dismissButton={TextButton(enabled=!busy,onClick=onDismiss){Text("Close")}})}

@Composable
private fun WhatsNewDialog(release:ReleaseLog,onDismiss:()->Unit){
    AlertDialog(
        onDismissRequest=onDismiss,
        icon={Box(Modifier.size(48.dp).background(Gold,CircleShape),contentAlignment=Alignment.Center){Icon(Icons.Default.AutoAwesome,null,tint=Navy)}},
        title={Text("Welcome to ${release.title}")},
        text={Column(Modifier.heightIn(max=500.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(10.dp)){
            Surface(color=Navy,shape=RoundedCornerShape(16.dp),modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){Text("Sabaq Workspace",color=Gold,fontWeight=FontWeight.Bold);Text("${release.versionName} · Build ${release.buildNumber}",color=Color.White,fontSize=12.sp)}}
            Text("What changed",fontWeight=FontWeight.Bold,color=Navy)
            release.changes.forEach{change->Row(verticalAlignment=Alignment.Top){Icon(Icons.Default.CheckCircle,null,tint=Sage,modifier=Modifier.size(18.dp));Spacer(Modifier.width(8.dp));Text(change,color=Navy.copy(alpha=.78f),fontSize=13.sp)}}
        }},
        confirmButton={Button(onClick=onDismiss){Text("Explore workspace")}}
    )
}

@Composable
private fun ReleaseHistoryDialog(onDismiss:()->Unit){
    AlertDialog(
        onDismissRequest=onDismiss,
        icon={Icon(Icons.Default.History,null,tint=Gold)},
        title={Text("Update history")},
        text={
            Column(Modifier.heightIn(max=520.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(12.dp)){
                ReleaseHistory.entries.forEach{release->
                    Surface(color=if(release.buildNumber==BUILD_NUMBER)Gold.copy(alpha=.16f)else Canvas,shape=RoundedCornerShape(16.dp)){
                        Column(Modifier.fillMaxWidth().padding(14.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){
                            Row(verticalAlignment=Alignment.CenterVertically){Text("Build ${release.buildNumber}",fontWeight=FontWeight.Bold,color=Navy,modifier=Modifier.weight(1f));Text(release.status,fontSize=10.sp,color=Sage,fontWeight=FontWeight.Bold)}
                            Text(release.versionName,fontSize=11.sp,color=Navy.copy(alpha=.58f));Text(release.title,fontWeight=FontWeight.Bold)
                            release.changes.forEach{Text("• $it",fontSize=12.sp,color=Navy.copy(alpha=.75f))}
                        }
                    }
                }
            }
        },
        confirmButton={Button(onClick=onDismiss){Text("Done")}}
    )
}

@Composable
private fun Page(title:String,subtitle:String,content:LazyListScope.()->Unit){LazyColumn(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Canvas,Color(0xFFF8F4E8)))),contentPadding=PaddingValues(20.dp,20.dp,20.dp,96.dp),verticalArrangement=Arrangement.spacedBy(13.dp)){item{Column(verticalArrangement=Arrangement.spacedBy(5.dp)){Row(verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(9.dp).background(Gold,CircleShape));Spacer(Modifier.width(8.dp));Text("MISHKAAT",fontSize=10.sp,letterSpacing=2.sp,fontWeight=FontWeight.Bold,color=Sage)};Text(title,style=MaterialTheme.typography.headlineMedium,color=Navy);Text(subtitle,color=Navy.copy(alpha=.68f));Box(Modifier.fillMaxWidth().height(2.dp).background(Brush.horizontalGradient(listOf(Gold,Navy.copy(alpha=.18f),Color.Transparent))))}};content()}}

@Composable private fun Metric(title:String,value:String,icon:ImageVector,modifier:Modifier=Modifier){Surface(modifier,color=Ivory,shape=RoundedCornerShape(20.dp)){Column(Modifier.padding(16.dp)){Icon(icon,null,tint=Gold);Spacer(Modifier.height(10.dp));Text(value,fontSize=27.sp,fontWeight=FontWeight.Bold,color=Navy);Text(title,color=Navy.copy(alpha=.62f))}}}
@Composable private fun InfoCard(icon:ImageVector,title:String,body:String){Surface(color=Gold.copy(alpha=.14f),shape=RoundedCornerShape(20.dp)){Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.Top){Icon(icon,null,tint=Navy);Spacer(Modifier.width(12.dp));Column{Text(title,fontWeight=FontWeight.Bold,color=Navy);Text(body,color=Navy.copy(alpha=.75f))}}}}
@Composable private fun SimpleRow(title:String,subtitle:String,icon:ImageVector,modifier:Modifier=Modifier){Surface(modifier.fillMaxWidth(),color=Ivory,shape=RoundedCornerShape(18.dp)){Row(Modifier.fillMaxWidth().padding(15.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(42.dp).background(Gold.copy(alpha=.22f),RoundedCornerShape(13.dp)),contentAlignment=Alignment.Center){Icon(icon,null,tint=Navy)};Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(title,fontWeight=FontWeight.Bold);Text(subtitle,color=Navy.copy(alpha=.6f),fontSize=13.sp)};Icon(Icons.Default.ChevronRight,null,tint=Navy.copy(alpha=.4f))}}}
@Composable private fun AssignmentCard(a:ClassroomAssignment,status:String,onClick:()->Unit,onComments:(()->Unit)?=null){Card(colors=CardDefaults.cardColors(containerColor=Ivory),shape=RoundedCornerShape(20.dp),modifier=Modifier.fillMaxWidth().clickable(onClick=onClick)){Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){Row{Box(Modifier.size(42.dp).background(Gold,CircleShape),contentAlignment=Alignment.Center){Icon(Icons.AutoMirrored.Filled.MenuBook,null,tint=Navy)};Spacer(Modifier.width(11.dp));Column(Modifier.weight(1f)){Text(a.title,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis);Text("${a.subject} · ${dateTime(a.dueAtMillis)}",color=Navy.copy(alpha=.6f),fontSize=12.sp)};Surface(color=Sage.copy(alpha=.14f),shape=RoundedCornerShape(30.dp)){Text(status,color=Sage,fontWeight=FontWeight.Bold,fontSize=11.sp,modifier=Modifier.padding(horizontal=8.dp,vertical=5.dp))}};if(a.instructions.isNotBlank())Text(a.instructions,maxLines=2,overflow=TextOverflow.Ellipsis,color=Navy.copy(alpha=.75f));Row(verticalAlignment=Alignment.CenterVertically){if(a.attachmentUris.isNotEmpty())Text("${a.attachmentUris.size} file(s)",fontSize=11.sp,color=Sage,fontWeight=FontWeight.Bold);Spacer(Modifier.weight(1f));onComments?.let{TextButton(onClick=it){Icon(Icons.Default.ChatBubbleOutline,"Open discussion");Spacer(Modifier.width(5.dp));Text("Discuss")}}}}}
}
@Composable private fun AnnouncementCard(item:Announcement,onComments:(()->Unit)?=null,onManage:(()->Unit)?=null){val context=LocalContext.current;Surface(color=Gold.copy(alpha=.12f),shape=RoundedCornerShape(18.dp)){Column(Modifier.fillMaxWidth().padding(15.dp)){Row(verticalAlignment=Alignment.CenterVertically){Icon(if(item.pinned)Icons.Default.PushPin else Icons.Default.Campaign,null,tint=Navy);Spacer(Modifier.width(8.dp));Text(item.title,fontWeight=FontWeight.Bold,color=Navy,modifier=Modifier.weight(1f));if(item.state!=AnnouncementState.PUBLISHED)Text(item.state.name.lowercase().replaceFirstChar(Char::uppercase),fontSize=11.sp,color=Sage,fontWeight=FontWeight.Bold)};Spacer(Modifier.height(5.dp));Text(item.body,color=Navy.copy(alpha=.78f));item.attachmentUris.forEachIndexed{index,uri->TextButton(onClick={openAttachment(context,uri)}){Icon(Icons.Default.AttachFile,"Open attachment");Spacer(Modifier.width(5.dp));Text("Attachment ${index+1}")}};Text(if(item.state==AnnouncementState.SCHEDULED)"Scheduled ${dateTime(item.publishAt)}" else dateTime(item.createdAt),fontSize=11.sp,color=Navy.copy(alpha=.52f));if(onComments!=null||onManage!=null)Row{onComments?.let{TextButton(onClick=it){Icon(Icons.Default.ChatBubbleOutline,"Open discussion");Spacer(Modifier.width(5.dp));Text("Discuss")}};Spacer(Modifier.weight(1f));onManage?.let{TextButton(onClick=it){Icon(Icons.Default.Edit,"Manage announcement");Spacer(Modifier.width(5.dp));Text("Manage")}}}}}}
@Composable private fun ProgressCard(item:ProgressRecord){Surface(color=Ivory,shape=RoundedCornerShape(18.dp)){Column(Modifier.fillMaxWidth().padding(15.dp)){Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Insights,null,tint=Gold);Spacer(Modifier.width(8.dp));Column(Modifier.weight(1f)){Text("${item.subject} · ${item.criterion}",fontWeight=FontWeight.Bold);Text(item.note.ifBlank{"Progress update"},color=Navy.copy(alpha=.65f))};Text("${item.level}/5",fontWeight=FontWeight.Bold,color=Sage)}}}}
@Composable private fun EmptyCard(title:String,body:String){Surface(color=Ivory,shape=RoundedCornerShape(20.dp)){Column(Modifier.fillMaxWidth().padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally){Icon(Icons.Default.Inbox,null,tint=Gold);Spacer(Modifier.height(8.dp));Text(title,fontWeight=FontWeight.Bold);Text(body,color=Navy.copy(alpha=.6f))}}}
@Composable private fun SectionTitle(text:String)=Text(text,style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold,color=Navy)
private fun dateTime(value:Long):String=DateFormat.getDateTimeInstance(DateFormat.MEDIUM,DateFormat.SHORT).format(Date(value))
private fun performNotificationFeedback(context:android.content.Context,granted:Boolean){FeedbackEngine.perform(context,FeedbackPreferences(context).load(),if(granted)FeedbackKind.CONFIRM else FeedbackKind.WARNING)}
private fun persistReadPermission(context:android.content.Context,uri:Uri){runCatching{context.contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)}}
private fun openAttachment(context:android.content.Context,value:String){
    if(!value.startsWith("cloud:")){runCatching{context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(value)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))};return}
    val path=value.removePrefix("cloud:")
    val extension=path.substringAfterLast('.',"").lowercase().takeIf{it.matches(Regex("[a-z0-9]{1,8}"))}.orEmpty()
    val folder=File(context.cacheDir,"cloud").apply{mkdirs()}
    val file=File(folder,"${path.hashCode().toUInt().toString(16)}${if(extension.isBlank())"" else ".$extension"}")
    FirebaseStorage.getInstance().reference.child(path).getFile(file).addOnSuccessListener{
        val uri=FileProvider.getUriForFile(context,"${BuildConfig.APPLICATION_ID}.fileprovider",file)
        val mime=MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension)?:"application/octet-stream"
        runCatching{context.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri,mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))}
    }
}
private fun addToCalendar(context:android.content.Context,item:ClassroomAssignment){runCatching{context.startActivity(Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI).putExtra(CalendarContract.Events.TITLE,item.title).putExtra(CalendarContract.Events.DESCRIPTION,item.instructions).putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME,item.dueAtMillis-3_600_000).putExtra(CalendarContract.EXTRA_EVENT_END_TIME,item.dueAtMillis))}}
private fun pickDateTime(context:android.content.Context,current:Long,onPicked:(Long)->Unit){val cal=Calendar.getInstance().apply{timeInMillis=current};DatePickerDialog(context,{_,year,month,day->TimePickerDialog(context,{_,hour,minute->onPicked(Calendar.getInstance().apply{set(year,month,day,hour,minute,0);set(Calendar.MILLISECOND,0)}.timeInMillis)},cal.get(Calendar.HOUR_OF_DAY),cal.get(Calendar.MINUTE),false).show()},cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH)).show()}
private fun hijriDate(value:Long=System.currentTimeMillis()):String{val months=listOf("Muharram","Safar","Rabi al-Awwal","Rabi al-Thani","Jumada al-Awwal","Jumada al-Thani","Rajab","Sha'ban","Ramadan","Shawwal","Dhu al-Qadah","Dhu al-Hijjah");val c=IslamicCalendar().apply{timeInMillis=value};return "${c.get(Calendar.DAY_OF_MONTH)} ${months[c.get(Calendar.MONTH).coerceIn(0,11)]} ${c.get(Calendar.YEAR)} AH"}
private fun friendlyGoogleAuthError(error:Throwable):String{val name=error::class.simpleName.orEmpty();return when{ name.contains("Cancellation",true)->"Google sign-in was canceled.";error.message.isNullOrBlank()->"Google sign-in could not be completed.";else->error.message!! }}
private fun friendlyEmailAuthError(error:Throwable):String{
    val name=error::class.simpleName.orEmpty()
    return when{
        name.contains("Network",true)->"Could not contact the secure sign-in service. Check your connection."
        name.contains("TooManyRequests",true)->"Too many attempts. Wait a moment or use password reset."
        else->"Email or password was not accepted, or this account is not active."
    }
}
