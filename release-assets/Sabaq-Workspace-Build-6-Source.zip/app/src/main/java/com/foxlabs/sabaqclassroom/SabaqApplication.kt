package com.foxlabs.sabaqclassroom

import android.app.Application
import com.google.firebase.FirebaseApp

class SabaqApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        FirebaseApp.initializeApp(this)
        AppCheckInitializer.install()
        NotificationScheduler.createChannels(this)
    }
}
