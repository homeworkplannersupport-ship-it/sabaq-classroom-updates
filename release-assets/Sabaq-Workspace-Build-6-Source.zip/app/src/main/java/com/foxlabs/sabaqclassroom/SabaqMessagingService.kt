package com.foxlabs.sabaqclassroom

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class SabaqMessagingService : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        CloudDeviceRegistration.register(token)
    }

    override fun onMessageReceived(message: RemoteMessage) {
        NotificationScheduler.showCloudUpdate(
            this,
            message.data["eventId"].orEmpty().ifBlank { message.messageId.orEmpty() },
            message.data["route"].orEmpty().ifBlank { "classwork" },
            message.notification?.title ?: "Sabaq Workspace update",
            message.notification?.body ?: "Open Classroom to review the latest activity."
        )
    }
}
