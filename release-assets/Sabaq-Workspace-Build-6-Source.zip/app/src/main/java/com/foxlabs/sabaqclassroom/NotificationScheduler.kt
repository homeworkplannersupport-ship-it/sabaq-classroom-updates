package com.foxlabs.sabaqclassroom

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.app.PendingIntent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.*
import java.util.concurrent.TimeUnit

object NotificationScheduler {
    private const val ASSIGNMENTS = "sabaq_assignments"
    private const val DAILY = "sabaq_daily"
    private const val CLASSROOM_UPDATES = "classroom_updates"

    fun createChannels(context: Context) {
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannels(listOf(
            NotificationChannel(ASSIGNMENTS,"Assignment reminders",NotificationManager.IMPORTANCE_DEFAULT).apply { description="Due-soon and returned-work reminders" },
            NotificationChannel(DAILY,"Daily planning",NotificationManager.IMPORTANCE_LOW).apply { description="Optional daily study summary" },
            NotificationChannel(CLASSROOM_UPDATES,"Classroom updates",NotificationManager.IMPORTANCE_DEFAULT).apply { description="Private server-delivered assignment and submission activity" }
        ))
    }

    fun scheduleAssignment(context: Context, assignment: ClassroomAssignment, preference:AssignmentReminderPreference=AssignmentReminderPreference(assignment.id,"")) {
        val workName="assignment-${assignment.id}"
        if(!preference.enabled||assignment.dueAtMillis<=System.currentTimeMillis()){
            WorkManager.getInstance(context).cancelUniqueWork(workName)
            return
        }
        val remindAt = assignment.dueAtMillis - TimeUnit.HOURS.toMillis(preference.leadHours.toLong())
        val delay = (remindAt - System.currentTimeMillis()).coerceAtLeast(TimeUnit.SECONDS.toMillis(10))
        val data = workDataOf("id" to assignment.id,"due" to assignment.dueAtMillis)
        val request = OneTimeWorkRequestBuilder<AssignmentReminderWorker>().setInitialDelay(delay,TimeUnit.MILLISECONDS).setInputData(data).build()
        WorkManager.getInstance(context).enqueueUniqueWork(workName,ExistingWorkPolicy.REPLACE,request)
    }

    fun scheduleDaily(context: Context) {
        val request = PeriodicWorkRequestBuilder<DailyPlanningWorker>(24,TimeUnit.HOURS).setInitialDelay(12,TimeUnit.HOURS).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork("daily-planning",ExistingPeriodicWorkPolicy.KEEP,request)
    }

    fun openIntent(context:Context,destination:String,requestCode:Int):PendingIntent=PendingIntent.getActivity(context,requestCode,Intent(context,MainActivity::class.java).putExtra("destination",destination).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun sendTest(context:Context):Boolean{
        if(Build.VERSION.SDK_INT>=33&&ContextCompat.checkSelfPermission(context,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return false
        val open=openIntent(context,"classwork",2203)
        val notification=NotificationCompat.Builder(context,ASSIGNMENTS).setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle("Sabaq Workspace test").setContentText("Reminders are ready. No private classwork details appear here.").setVisibility(NotificationCompat.VISIBILITY_PRIVATE).setContentIntent(open).setAutoCancel(true).build()
        NotificationManagerCompat.from(context).notify(2203,notification);return true
    }

    fun showCloudUpdate(context:Context,eventId:String,route:String,title:String,body:String){
        if(Build.VERSION.SDK_INT>=33&&ContextCompat.checkSelfPermission(context,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return
        val notificationId=eventId.ifBlank{"classroom-update"}.hashCode()
        val open=openIntent(context,if(route in setOf("classwork","submissions"))"classwork" else "today",notificationId)
        val notification=NotificationCompat.Builder(context,CLASSROOM_UPDATES)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(title.take(80))
            .setContentText(body.take(160))
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(context).notify(notificationId,notification)
    }
}

class AssignmentReminderWorker(context: Context,params: WorkerParameters):CoroutineWorker(context,params){
    override suspend fun doWork():Result{
        if(Build.VERSION.SDK_INT>=33&&ContextCompat.checkSelfPermission(applicationContext,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return Result.success()
        val id=inputData.getString("id")?:return Result.failure()
        val open=NotificationScheduler.openIntent(applicationContext,"classwork",id.hashCode())
        val notification=NotificationCompat.Builder(applicationContext,"sabaq_assignments").setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle("Sabaq work due soon").setContentText("Open Classroom to review your upcoming work.").setVisibility(NotificationCompat.VISIBILITY_PRIVATE).setContentIntent(open).addAction(0,"Open classwork",open).setAutoCancel(true).build()
        NotificationManagerCompat.from(applicationContext).notify(id.hashCode(),notification)
        return Result.success()
    }
}

class DailyPlanningWorker(context:Context,params:WorkerParameters):CoroutineWorker(context,params){
    override suspend fun doWork():Result{
        if(Build.VERSION.SDK_INT>=33&&ContextCompat.checkSelfPermission(applicationContext,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return Result.success()
        val open=NotificationScheduler.openIntent(applicationContext,"planner",2202)
        val notification=NotificationCompat.Builder(applicationContext,"sabaq_daily").setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle("Plan your sabaq study").setContentText("Open your planner to choose one focused next step.").setVisibility(NotificationCompat.VISIBILITY_PRIVATE).setContentIntent(open).addAction(0,"Open planner",open).setAutoCancel(true).build()
        NotificationManagerCompat.from(applicationContext).notify(2202,notification)
        return Result.success()
    }
}
