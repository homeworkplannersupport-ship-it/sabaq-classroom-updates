package com.foxlabs.sabaqclassroom

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.v2.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class RoleJourneyTest {
    @get:Rule val compose= createAndroidComposeRule<MainActivity>()

    @Test fun firstRunOffersAdministratorSetup(){
        compose.onNodeWithText("Set up Sabaq Workspace").assertIsDisplayed()
        compose.onNodeWithText("Create administrator").assertIsDisplayed()
    }
}
