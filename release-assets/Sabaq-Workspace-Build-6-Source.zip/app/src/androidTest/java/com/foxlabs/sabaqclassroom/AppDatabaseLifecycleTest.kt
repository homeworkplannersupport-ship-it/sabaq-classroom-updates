package com.foxlabs.sabaqclassroom

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class AppDatabaseLifecycleTest {
    private val context get() = InstrumentationRegistry.getInstrumentation().targetContext
    private lateinit var db: AppDatabase

    @Before
    fun setUp() {
        context.deleteDatabase("sabaq_classroom.db")
        db = AppDatabase(context)
    }

    @After
    fun tearDown() {
        db.close()
        context.deleteDatabase("sabaq_classroom.db")
    }

    @Test
    fun accountClassroomAndAssignmentLifecyclePreservesHistoryAndVisibility() {
        val admin = db.createAccount("Administrator", "admin.test", AccountRole.ADMIN, "Strong passphrase 123!".toCharArray())
        val teacher = db.createAccount("Teacher", "teacher.test", AccountRole.TEACHER, "Teacher passphrase 123!".toCharArray())
        val student = db.createAccount("Student", "student.test", AccountRole.STUDENT, "Student passphrase 123!".toCharArray())
        assertNotNull(db.authenticate(admin.username, "Strong passphrase 123!".toCharArray()))

        val classroom = db.createClassroom("Quran A", "Evening", teacher.id)
        db.addMember(classroom.id, student.id)
        val due = System.currentTimeMillis() + 3 * 60 * 60 * 1000
        val assignment = db.publishAssignment(teacher, classroom.id, "Revision", "Read carefully", "Quran", due, 25, "Standard", state = AssignmentState.DRAFT)
        assertTrue(db.assignmentsFor(student).isEmpty())

        db.setAssignmentState(teacher, assignment.id, AssignmentState.SCHEDULED, System.currentTimeMillis() + 60 * 60 * 1000)
        assertEquals(AssignmentState.SCHEDULED, db.managedAssignmentsFor(teacher).single().state)
        assertTrue(db.assignmentsFor(student).isEmpty())

        db.setAssignmentState(teacher, assignment.id, AssignmentState.PUBLISHED)
        assertEquals(1, db.assignmentsFor(student).size)
        db.updateAssignment(teacher, assignment.id, "Revision updated", "Read twice", "Quran", due, 30, "High", "Revision", listOf("Read", "Repeat"), "")
        val edited = db.managedAssignmentsFor(teacher).single()
        assertEquals(3, edited.revision)
        assertEquals(2, db.assignmentRevisionCount(edited.id))

        db.setAssignmentState(teacher, edited.id, AssignmentState.CLOSED)
        assertEquals(1, db.assignmentsFor(student).size)
        db.setAssignmentState(teacher, edited.id, AssignmentState.ARCHIVED)
        assertTrue(db.assignmentsFor(student).isEmpty())
        db.setAssignmentState(teacher, edited.id, AssignmentState.DRAFT)
        assertEquals(AssignmentState.DRAFT, db.managedAssignmentsFor(teacher).single().state)
    }

    @Test
    fun syncOutboxSurvivesDatabaseReopen() {
        val change = SyncChange(
            idempotencyKey = "teacher-1:assignment-7:update-2",
            entityType = "assignment",
            entityId = "assignment-7",
            operation = SyncOperation.UPDATE,
            expectedRevision = 2,
            payloadDigest = "sha256:instrumentation"
        )
        SyncOutbox(store = db).apply {
            assertTrue(enqueue(change))
            recordResult(change.idempotencyKey, SyncPushResult.Retryable("offline"), 10_000)
        }

        db.close()
        db = AppDatabase(context)
        val persisted = SyncOutbox(store = db).snapshot().single()
        assertEquals(change, persisted.change)
        assertEquals(OutboxState.RETRY_WAIT, persisted.state)
        assertEquals(1, persisted.attempts)
        assertEquals(15_000, persisted.nextAttemptAtMillis)
    }

    @Test
    fun firebaseIdentityLinksOnlyToOneApprovedProfile() {
        val teacher = db.createAccount("Teacher", "teacher.link", AccountRole.TEACHER, "Teacher passphrase 123!".toCharArray())
        val student = db.createAccount("Student", "student.link", AccountRole.STUDENT, "Student passphrase 123!".toCharArray())

        db.linkFirebaseIdentity(teacher.id, "firebase-teacher-uid", "teacher@example.test")
        assertEquals(teacher, db.accountForFirebaseUid("firebase-teacher-uid"))
        assertEquals("teacher@example.test", db.federatedIdentityForAccount(teacher.id)?.email)

        val reusedGoogleIdentity = runCatching {
            db.linkFirebaseIdentity(student.id, "firebase-teacher-uid", "teacher@example.test")
        }.exceptionOrNull()
        val secondIdentityForTeacher = runCatching {
            db.linkFirebaseIdentity(teacher.id, "different-firebase-uid", "other@example.test")
        }.exceptionOrNull()
        assertTrue(reusedGoogleIdentity is IllegalArgumentException)
        assertTrue(secondIdentityForTeacher is IllegalArgumentException)
    }

    @Test
    fun reminderReviewAndAssignmentReuseStayRoleScoped() {
        val teacher=db.createAccount("Teacher","teacher.workflow",AccountRole.TEACHER,"Teacher passphrase 123!".toCharArray())
        val student=db.createAccount("Student","student.workflow",AccountRole.STUDENT,"Student passphrase 123!".toCharArray())
        val classroom=db.createClassroom("Hifz","Morning",teacher.id)
        db.addMember(classroom.id,student.id)
        val assignment=db.publishAssignment(teacher,classroom.id,"Daily revision","Review yesterday's portion","Hifz",System.currentTimeMillis()+86_400_000,30,"High")

        val preference=AssignmentReminderPreference(assignment.id,student.id,true,4)
        db.saveReminderPreference(preference)
        assertEquals(preference,db.reminderPreference(assignment.id,student.id))

        db.handIn(student,assignment.id,"Ready for review")
        val submission=db.submissionFor(assignment.id,student.id)!!
        db.reviewSubmission(teacher,submission.id,SubmissionState.COMPLETED,"Strong revision")
        assertEquals(SubmissionState.COMPLETED,db.submissionFor(assignment.id,student.id)?.state)

        val reused=db.duplicateAssignmentAsDraft(teacher,assignment.id,System.currentTimeMillis()+8L*86_400_000)
        assertEquals(AssignmentState.DRAFT,reused.state)
        assertEquals(assignment.title,reused.title)
        assertEquals(2,db.managedAssignmentsFor(teacher).size)
    }
}
