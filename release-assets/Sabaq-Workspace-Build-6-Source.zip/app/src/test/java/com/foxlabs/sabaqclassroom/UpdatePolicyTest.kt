package com.foxlabs.sabaqclassroom

import org.junit.Assert.assertEquals
import org.junit.Test

class UpdatePolicyTest {
    private val hash="a".repeat(64)
    private val certificate="b".repeat(64)

    @Test fun dedicatedHttpsReleaseIsAccepted(){
        val item=UpdateInfo(2,"0.2.0-alpha-build-2","https://github.com/homeworkplannersupport-ship-it/sabaq-classroom-updates/releases/download/build-2/Sabaq-Classroom-Build-2.apk",hash,certificate,"")
        assertEquals(item,UpdateManager.validate(item))
    }

    @Test(expected=IllegalArgumentException::class) fun lookalikeHostIsRejected(){
        UpdateManager.validate(UpdateInfo(2,"Build 2","https://github.com.evil.example/homeworkplannersupport-ship-it/sabaq-classroom-updates/releases/download/build-2/app.apk",hash,certificate,""))
    }

    @Test(expected=IllegalArgumentException::class) fun wrongRepositoryPathIsRejected(){
        UpdateManager.validate(UpdateInfo(2,"Build 2","https://github.com/another/repository/releases/download/build-2/app.apk",hash,certificate,""))
    }

    @Test(expected=IllegalArgumentException::class) fun malformedChecksumIsRejected(){
        UpdateManager.validate(UpdateInfo(2,"Build 2","https://github.com/homeworkplannersupport-ship-it/sabaq-classroom-updates/releases/download/build-2/app.apk","abc",certificate,""))
    }

    @Test(expected=IllegalArgumentException::class) fun malformedCertificateIsRejected(){
        UpdateManager.validate(UpdateInfo(2,"Build 2","https://github.com/homeworkplannersupport-ship-it/sabaq-classroom-updates/releases/download/build-2/app.apk",hash,"abc",""))
    }
}
