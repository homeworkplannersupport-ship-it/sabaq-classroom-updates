package com.foxlabs.sabaqclassroom

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class CloudWirePolicyTest {
    @Test fun clientAssignmentIdentityMatchesServerPolicy(){
        assertEquals("fdaccbdde103712f35e5fefd94f4ef4cdf95c56c60c12e8f8a71a559d8b56df4",CloudWirePolicy.assignmentId("teacher-1","request_123"))
    }
    @Test fun clientSubmissionIdentityMatchesServerPolicy(){
        assertEquals("e6ef97b33b0c0a9de9b99cb7e81fbc865a8127dbcfe8c2c871db1f0d58e64cb6",CloudWirePolicy.submissionId("assignment-1","student-1"))
    }
    @Test fun richPostIdentitiesAreStableAndTypeScoped(){
        val announcement=CloudWirePolicy.stableEntityId("teacher-1","request_123","announcement")
        assertEquals(announcement,CloudWirePolicy.stableEntityId("teacher-1","request_123","announcement"))
        assertNotEquals(announcement,CloudWirePolicy.stableEntityId("teacher-1","request_123","comment"))
    }
    @Test fun lifecycleNamesMatchCallableFunctions(){
        assertEquals("scheduled",CloudWirePolicy.assignmentState(AssignmentState.SCHEDULED))
        assertEquals("returned",CloudWirePolicy.reviewState(SubmissionState.RETURNED))
        assertThrows(IllegalStateException::class.java){CloudWirePolicy.reviewState(SubmissionState.STARTED)}
    }
    @Test fun attachmentMimeAllowlistMatchesStorageRules(){
        assertEquals("pdf",CloudWirePolicy.extensionForMime("application/pdf"))
        assertThrows(IllegalStateException::class.java){CloudWirePolicy.extensionForMime("application/zip")}
    }
}
