package com.foxlabs.sabaqclassroom

import java.time.LocalDate
import java.time.ZoneId
import org.junit.Assert.*
import org.junit.Test

class WorkloadEngineTest {
    private val now=1_800_000_000_000L
    private fun assignment(id:String,due:Long,minutes:Int=30,priority:String="Standard")=ClassroomAssignment(id,"class","teacher",id,"","Quran",due,minutes,priority,AssignmentState.PUBLISHED,now-1000)
    private fun submission(id:String,state:SubmissionState)=StudentSubmission("s-$id",id,"student","",state,now-500,"","")

    @Test fun recommendsMissingBeforeDueSoonAndCountsOnlyActionableWork(){
        val items=listOf(assignment("later",now+3*24*60*60*1000,40),assignment("soon",now+2*60*60*1000,35),assignment("late",now-1000,20))
        val result=WorkloadEngine.student(items,mapOf("later" to submission("later",SubmissionState.COMPLETED)),now)
        assertEquals("late",result.recommended?.id)
        assertEquals(2,result.openCount)
        assertEquals(55,result.remainingMinutes)
        assertEquals(1,result.missingCount)
        assertEquals(WorkloadRisk.NEEDS_ATTENTION,result.risk)
    }

    @Test fun allFinishedProducesFullCompletionAndNoRecommendation(){
        val item=assignment("done",now+10000)
        val result=WorkloadEngine.student(listOf(item),mapOf(item.id to submission(item.id,SubmissionState.HANDED_IN)),now)
        assertEquals(100,result.completionPercent)
        assertEquals(0,result.remainingMinutes)
        assertNull(result.recommended)
        assertEquals(WorkloadRisk.ON_TRACK,result.risk)
    }

    @Test fun classroomRanksStudentsNeedingAttentionFirst(){
        val students=listOf(Account("a","On Track","a",AccountRole.STUDENT),Account("b","Behind","b",AccountRole.STUDENT))
        val item=assignment("work",now-1000)
        val rows=WorkloadEngine.classroom(students,listOf(item),{_,student->if(student=="a")submission("work",SubmissionState.COMPLETED) else null},now)
        assertEquals("b",rows.first().student.id)
    }

    @Test fun crowdedDayAndStudyBlocksAreConcrete(){
        val zone=ZoneId.of("UTC")
        val due=LocalDate.of(2027,1,2).atStartOfDay(zone).toInstant().toEpochMilli()
        val items=listOf(assignment("a",due,50),assignment("b",due+1000,50),assignment("c",due+2000,40))
        assertEquals(setOf(LocalDate.of(2027,1,2)),WorkloadEngine.crowdedDays(items,emptyMap(),zone))
        assertEquals(listOf(25,25,15),WorkloadEngine.studyBlocks(65))
    }
}
