package com.foxlabs.sabaqclassroom

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PasswordHasherTest {
    @Test fun correctPasswordVerifiesAndWrongPasswordDoesNot() {
        val record = PasswordHasher.create("A-long-test-password-42".toCharArray())
        assertTrue(PasswordHasher.verify("A-long-test-password-42".toCharArray(), record.salt, record.hash))
        assertFalse(PasswordHasher.verify("wrong-password".toCharArray(), record.salt, record.hash))
    }

    @Test(expected = IllegalArgumentException::class)
    fun shortPasswordsAreRejected() {
        PasswordHasher.create("short".toCharArray())
    }
}
