package com.foxlabs.sabaqclassroom

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ReleaseHistoryTest {
    @Test fun historyIsUniqueAndNewestFirst() {
        val builds = ReleaseHistory.entries.map { it.buildNumber }
        assertEquals(builds.distinct(), builds)
        assertEquals(builds.sortedDescending(), builds)
        assertEquals(6, builds.first())
    }

    @Test fun everyBuildHasVisibleVersionAndChanges() {
        ReleaseHistory.entries.forEach {
            assertTrue(it.versionName.endsWith("build-${it.buildNumber}"))
            assertTrue(it.title.isNotBlank())
            assertTrue(it.status.isNotBlank())
            assertTrue(it.changes.isNotEmpty())
        }
        assertNotNull(ReleaseHistory.forBuild(2))
    }
}
