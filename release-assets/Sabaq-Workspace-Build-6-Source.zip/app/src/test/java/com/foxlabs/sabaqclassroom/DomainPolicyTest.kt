package com.foxlabs.sabaqclassroom

import org.junit.Assert.*
import org.junit.Test

class DomainPolicyTest {
    private fun assignment(due:Long)=ClassroomAssignment("a","class-a","teacher","Read","", "Quran",due,20,"Standard",AssignmentState.PUBLISHED,0)
    private fun submission(student:String,state:SubmissionState)=StudentSubmission("s","a",student,"",state,null,"")

    @Test fun deadlinesProduceAssignedDueSoonAndMissing(){
        val now=1_000_000L
        assertEquals(WorkSection.ASSIGNED,DomainPolicy.section(assignment(now+48*60*60*1000),null,now))
        assertEquals(WorkSection.DUE_SOON,DomainPolicy.section(assignment(now+2*60*60*1000),null,now))
        assertEquals(WorkSection.MISSING,DomainPolicy.section(assignment(now-1),null,now))
    }

    @Test fun submissionStateWinsOverDeadline(){
        val late=assignment(1)
        assertEquals(WorkSection.HANDED_IN,DomainPolicy.section(late,submission("student-a",SubmissionState.HANDED_IN),2))
        assertEquals(WorkSection.RETURNED,DomainPolicy.section(late,submission("student-a",SubmissionState.RETURNED),2))
        assertEquals(WorkSection.COMPLETED,DomainPolicy.section(late,submission("student-a",SubmissionState.COMPLETED),2))
    }

    @Test fun rolesStaySeparated(){
        assertTrue(DomainPolicy.canManageClassroom(AccountRole.TEACHER))
        assertTrue(DomainPolicy.canManageClassroom(AccountRole.ADMIN))
        assertFalse(DomainPolicy.canManageClassroom(AccountRole.STUDENT))
        assertTrue(DomainPolicy.canHandIn(AccountRole.STUDENT))
        assertFalse(DomainPolicy.canHandIn(AccountRole.GUARDIAN))
    }

    @Test fun submissionActionsRespectAssignmentAndSubmissionState(){
        val published=assignment(Long.MAX_VALUE)
        val draft=submission("student-a",SubmissionState.STARTED)
        val handedIn=submission("student-a",SubmissionState.HANDED_IN)
        val completed=submission("student-a",SubmissionState.COMPLETED)
        val closed=published.copy(state=AssignmentState.CLOSED)
        assertTrue(DomainPolicy.canSaveSubmissionDraft(published,null))
        assertTrue(DomainPolicy.canSaveSubmissionDraft(published,draft))
        assertFalse(DomainPolicy.canSaveSubmissionDraft(published,handedIn))
        assertTrue(DomainPolicy.canUnsubmit(published,handedIn))
        assertFalse(DomainPolicy.canUnsubmit(closed,handedIn))
        assertTrue(DomainPolicy.canSubmit(published,handedIn))
        assertFalse(DomainPolicy.canSubmit(published,completed))
        assertFalse(DomainPolicy.canSubmit(closed,draft))
    }

    @Test fun assignmentLifecycleAllowsOnlyExplicitTransitions(){
        assertTrue(DomainPolicy.canTransitionAssignment(AssignmentState.DRAFT,AssignmentState.SCHEDULED))
        assertTrue(DomainPolicy.canTransitionAssignment(AssignmentState.SCHEDULED,AssignmentState.PUBLISHED))
        assertTrue(DomainPolicy.canTransitionAssignment(AssignmentState.PUBLISHED,AssignmentState.CLOSED))
        assertTrue(DomainPolicy.canTransitionAssignment(AssignmentState.CLOSED,AssignmentState.PUBLISHED))
        assertTrue(DomainPolicy.canTransitionAssignment(AssignmentState.ARCHIVED,AssignmentState.DRAFT))
        assertFalse(DomainPolicy.canTransitionAssignment(AssignmentState.PUBLISHED,AssignmentState.DRAFT))
        assertFalse(DomainPolicy.canTransitionAssignment(AssignmentState.CLOSED,AssignmentState.SCHEDULED))
        assertTrue(DomainPolicy.canEditAssignment(assignment(Long.MAX_VALUE)))
        assertFalse(DomainPolicy.canEditAssignment(assignment(Long.MAX_VALUE).copy(state=AssignmentState.ARCHIVED)))
    }

    @Test fun privateSubmissionAccessIsOwnerTeacherAdminOrLinkedGuardian(){
        val work=assignment(Long.MAX_VALUE);val item=submission("student-a",SubmissionState.HANDED_IN)
        assertTrue(DomainPolicy.canReadPrivateSubmission(Account("student-a","A","a",AccountRole.STUDENT),item,emptySet(),work))
        assertFalse(DomainPolicy.canReadPrivateSubmission(Account("student-b","B","b",AccountRole.STUDENT),item,emptySet(),work))
        assertTrue(DomainPolicy.canReadPrivateSubmission(Account("teacher","T","t",AccountRole.TEACHER),item,setOf("class-a"),work))
        assertTrue(DomainPolicy.canReadPrivateSubmission(Account("guardian","G","g",AccountRole.GUARDIAN),item,emptySet(),work,setOf("student-a")))
    }
}
