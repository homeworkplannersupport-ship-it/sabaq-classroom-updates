package com.foxlabs.sabaqclassroom

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SyncGatewayTest {
    private class TestStore : SyncQueueStore {
        val entries = linkedMapOf<String, OutboxEntry>()
        override fun putIfAbsent(entry: OutboxEntry): Boolean {
            if (entries.containsKey(entry.change.idempotencyKey)) return false
            entries[entry.change.idempotencyKey] = entry
            return true
        }
        override fun find(idempotencyKey: String) = entries[idempotencyKey]
        override fun list() = entries.values.toList()
        override fun put(entry: OutboxEntry) { entries[entry.change.idempotencyKey] = entry }
        override fun remove(idempotencyKey: String) { entries.remove(idempotencyKey) }
    }

    private fun change(revision: Long = 1) = SyncChange(
        idempotencyKey = "teacher-1:assignment-7:update-2",
        entityType = "assignment",
        entityId = "assignment-7",
        operation = SyncOperation.UPDATE,
        expectedRevision = revision,
        payloadDigest = "sha256:example"
    )

    @Test fun localOnlyGatewayIsExplicitAndHasNoFakePendingWork() {
        val status = LocalOnlySyncGateway.status()
        assertEquals(SyncAvailability.LOCAL_ONLY, status.availability)
        assertEquals(SyncPhase.IDLE, status.phase)
        assertEquals(0, status.pendingChanges)
        assertTrue(status.message.contains("local only", ignoreCase = true))
    }

    @Test fun idempotencyKeyPreventsDuplicateQueueEntries() {
        val outbox = SyncOutbox()
        assertTrue(outbox.enqueue(change()))
        assertFalse(outbox.enqueue(change()))
        assertEquals(1, outbox.snapshot().size)
    }

    @Test fun retryUsesBoundedExponentialBackoffAndEventuallyBecomesDue() {
        val outbox = SyncOutbox(initialRetryMillis = 100, maximumRetryMillis = 250)
        outbox.enqueue(change())
        outbox.recordResult(change().idempotencyKey, SyncPushResult.Retryable("offline"), 1_000)
        assertTrue(outbox.due(1_099).isEmpty())
        assertEquals(1, outbox.due(1_100).size)

        outbox.recordResult(change().idempotencyKey, SyncPushResult.Retryable("offline"), 2_000)
        assertEquals(2_200, outbox.snapshot().single().nextAttemptAtMillis)
        outbox.recordResult(change().idempotencyKey, SyncPushResult.Retryable("offline"), 3_000)
        assertEquals(3_250, outbox.snapshot().single().nextAttemptAtMillis)
    }

    @Test fun conflictStopsAutomaticRetryUntilRevisionIsResolved() {
        val outbox = SyncOutbox()
        outbox.enqueue(change())
        outbox.recordResult(change().idempotencyKey, SyncPushResult.Conflict(8, "stale revision"), 1_000)
        assertTrue(outbox.due(Long.MAX_VALUE).isEmpty())
        assertEquals(OutboxState.CONFLICT, outbox.snapshot().single().state)
        assertEquals(8L, outbox.snapshot().single().serverRevision)

        assertTrue(outbox.resolveConflict(change().idempotencyKey, change(revision = 8)))
        assertEquals(1, outbox.due(1_001).size)
        assertEquals(8L, outbox.snapshot().single().change.expectedRevision)
    }

    @Test fun acceptedChangesLeaveTheQueueWhileRejectedChangesRemainVisible() {
        val accepted = SyncOutbox().also { it.enqueue(change()) }
        accepted.recordResult(change().idempotencyKey, SyncPushResult.Accepted(2), 1_000)
        assertTrue(accepted.snapshot().isEmpty())

        val rejected = SyncOutbox().also { it.enqueue(change()) }
        rejected.recordResult(change().idempotencyKey, SyncPushResult.Rejected("not authorized"), 1_000)
        assertEquals(OutboxState.REJECTED, rejected.snapshot().single().state)
        assertTrue(rejected.due(Long.MAX_VALUE).isEmpty())
    }

    @Test fun queueStateSurvivesOutboxRecreationWhenBackedByADurableStore() {
        val store = TestStore()
        SyncOutbox(store = store).apply {
            enqueue(change())
            recordResult(change().idempotencyKey, SyncPushResult.Retryable("offline"), 10_000)
        }

        val recreated = SyncOutbox(store = store)
        assertEquals(OutboxState.RETRY_WAIT, recreated.snapshot().single().state)
        assertEquals(1, recreated.snapshot().single().attempts)
        assertEquals(1, recreated.due(15_000).size)
    }
}
