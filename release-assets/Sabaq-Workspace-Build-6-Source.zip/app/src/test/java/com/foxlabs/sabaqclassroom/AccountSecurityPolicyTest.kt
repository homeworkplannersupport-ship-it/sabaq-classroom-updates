package com.foxlabs.sabaqclassroom

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class AccountSecurityPolicyTest {
    @Test fun invitedGoogleEmailIsNormalized() {
        assertEquals("teacher@example.com", AccountSecurityPolicy.normalizeEmail(" Teacher@Example.COM "))
    }

    @Test fun malformedEmailIsRejected() {
        assertThrows(IllegalArgumentException::class.java) {
            AccountSecurityPolicy.normalizeEmail("teacher@example")
        }
    }

    @Test fun shortNewPasswordIsRejected() {
        assertThrows(IllegalArgumentException::class.java) {
            AccountSecurityPolicy.requireNewPassword("shortpass")
        }
    }

    @Test fun tenCharacterPasswordIsAccepted() {
        AccountSecurityPolicy.requireNewPassword("ten-chars!")
    }
}
