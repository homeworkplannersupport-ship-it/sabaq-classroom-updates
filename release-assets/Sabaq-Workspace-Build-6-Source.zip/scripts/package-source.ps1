param(
    [Parameter(Mandatory = $true)][int]$BuildNumber,
    [string]$Destination
)

$ErrorActionPreference = "Stop"
$projectRoot = Split-Path -Parent $PSScriptRoot
$rootUri = [Uri]($projectRoot.TrimEnd("\") + "\")
if (-not $Destination) { $Destination = Join-Path $projectRoot "release-staging\Build-$BuildNumber\Sabaq-Workspace-Build-$BuildNumber-Source.zip" }
$destinationPath = [IO.Path]::GetFullPath($Destination)
$allowedRoots = @("app\src", "gradle", "functions", "scripts")
$allowedFiles = @(
    "app\build.gradle.kts", "app\proguard-rules.pro", "build.gradle.kts", "settings.gradle.kts",
    "gradle.properties", "gradlew", "gradlew.bat", "firebase.json", "firestore.rules",
    "firestore.indexes.json", "storage.rules", "functions\index.js", "functions\package.json",
    "functions\package-lock.json", "README.md", "BACKEND.md", "PRIVACY-SAFETY.md", "THREAT-MODEL.md", "UPDATES.md"
)
$allowedFiles += "RELEASE-NOTES-BUILD-$BuildNumber.md"
$files = [Collections.Generic.List[IO.FileInfo]]::new()
foreach ($root in $allowedRoots) {
    $path = Join-Path $projectRoot $root
    if (Test-Path -LiteralPath $path -PathType Container) {
        Get-ChildItem -LiteralPath $path -Recurse -File | Where-Object {
            $_.FullName -notmatch "[\\/]build[\\/]|[\\/]node_modules[\\/]|[\\/]signing[\\/]" -and
            $_.Name -notmatch "\.(log|jks)$"
        } | ForEach-Object { $files.Add($_) }
    }
}
foreach ($relative in $allowedFiles) {
    $path = Join-Path $projectRoot $relative
    if (Test-Path -LiteralPath $path -PathType Leaf) { $files.Add((Get-Item -LiteralPath $path)) }
}

$parent = Split-Path -Parent $destinationPath
New-Item -ItemType Directory -Force -Path $parent | Out-Null
Add-Type -AssemblyName System.IO.Compression
$stream = [IO.File]::Open($destinationPath, [IO.FileMode]::Create)
try {
    $zip = [IO.Compression.ZipArchive]::new($stream, [IO.Compression.ZipArchiveMode]::Create, $false)
    try {
        foreach ($file in $files | Sort-Object FullName -Unique) {
            $relative = [Uri]::UnescapeDataString($rootUri.MakeRelativeUri([Uri]$file.FullName).ToString())
            $entry = $zip.CreateEntry($relative, [IO.Compression.CompressionLevel]::Optimal)
            $entryStream = $entry.Open()
            try {
                $source = [IO.File]::OpenRead($file.FullName)
                try { $source.CopyTo($entryStream) } finally { $source.Dispose() }
            } finally { $entryStream.Dispose() }
        }
    } finally { $zip.Dispose() }
} finally { $stream.Dispose() }

Write-Host "Created secret-free source package: $destinationPath"
Write-Host "Files: $($files.Count)"
