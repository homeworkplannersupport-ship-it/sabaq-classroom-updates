param(
    [Parameter(Mandatory = $true)][int]$BuildNumber,
    [Parameter(Mandatory = $true)][string]$VersionName,
    [Parameter(Mandatory = $true)][string]$ApkPath,
    [string]$Notes = "Sabaq Workspace update"
)

$ErrorActionPreference = "Stop"
$expectedPackage = "com.foxlabs.sabaqclassroom"
$expectedCertificate = "236578ddfbd57a801a0c67592e4c5f40e02fade9a774b8a973f97c9eac7c413a"
$tag = "build-$BuildNumber"
$releaseFile = "Sabaq-Workspace-Build-$BuildNumber.apk"
$sourceFile = "Sabaq-Workspace-Build-$BuildNumber-Source.zip"
$releaseUrl = "https://github.com/homeworkplannersupport-ship-it/sabaq-classroom-updates/releases/download/$tag/$releaseFile"
$projectRoot = Split-Path -Parent $PSScriptRoot
$resolvedApk = (Resolve-Path -LiteralPath $ApkPath).Path
$gradleText = Get-Content -LiteralPath (Join-Path $projectRoot "app\build.gradle.kts") -Raw

if ($BuildNumber -lt 1) { throw "BuildNumber must be positive." }
if ($VersionName -notmatch "build-$BuildNumber$") { throw "VersionName must end with build-$BuildNumber." }
if ($gradleText -notmatch "versionCode\s*=\s*$BuildNumber\b") { throw "Gradle versionCode does not match Build $BuildNumber." }
if (-not $gradleText.Contains("versionName = `"$VersionName`"")) { throw "Gradle versionName does not match $VersionName." }
if (-not $gradleText.Contains("applicationId = `"$expectedPackage`"")) { throw "Unexpected Android package." }

$sdkLine = Get-Content -LiteralPath (Join-Path $projectRoot "local.properties") | Where-Object { $_ -like "sdk.dir=*" } | Select-Object -First 1
$sdkRoot = $sdkLine.Substring(8).Replace("\:", ":").Replace("\\", "\")
$apksigner = Get-ChildItem -LiteralPath (Join-Path $sdkRoot "build-tools") -Recurse -Filter "apksigner.bat" | Sort-Object FullName -Descending | Select-Object -First 1
if (-not $apksigner) { throw "Android apksigner was not found." }
$certificateOutput = & $apksigner.FullName verify --print-certs $resolvedApk
if ($LASTEXITCODE -ne 0) { throw "APK signature verification failed." }
$certificateLine = $certificateOutput | Where-Object { $_ -match "Signer #1 certificate SHA-256 digest:" } | Select-Object -First 1
$certificate = (($certificateLine -split ":", 2)[1]).Trim().Replace(":", "").ToLowerInvariant()
if ($certificate -ne $expectedCertificate) { throw "Signing certificate does not match the permanent Sabaq Workspace update identity." }

$checksum = (Get-FileHash -LiteralPath $resolvedApk -Algorithm SHA256).Hash.ToLowerInvariant()
$staging = Join-Path $projectRoot "release-staging\Build-$BuildNumber"
New-Item -ItemType Directory -Force -Path $staging | Out-Null
Copy-Item -LiteralPath $resolvedApk -Destination (Join-Path $staging $releaseFile) -Force

$manifest = [ordered]@{
    versionCode = $BuildNumber
    versionName = $VersionName
    buildName = "Build $BuildNumber"
    packageName = $expectedPackage
    apkUrl = $releaseUrl
    sha256 = $checksum
    signingCertificateSha256 = $certificate
    notes = $Notes
}
$manifest | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $staging "update.json") -Encoding utf8

$releaseReport = @(
    "Sabaq Workspace - Build $BuildNumber"
    "Tag: $tag"
    "Package: $expectedPackage"
    "Version code: $BuildNumber"
    "Version name: $VersionName"
    "APK: $releaseFile"
    "Source: $sourceFile"
    "SHA-256: $checksum"
    "Certificate SHA-256: $certificate"
    "URL: $releaseUrl"
) -join [Environment]::NewLine
$releaseReport | Set-Content -LiteralPath (Join-Path $staging "release-verification.txt") -Encoding utf8

Write-Host $releaseReport
Write-Host "Release gate passed. Publish only after the public APK, update.json, and GitHub release match this report."
