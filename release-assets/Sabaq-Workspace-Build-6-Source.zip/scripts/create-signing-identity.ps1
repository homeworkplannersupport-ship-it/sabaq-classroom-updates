$ErrorActionPreference = "Stop"
$projectRoot = Split-Path -Parent $PSScriptRoot
$signingDir = Join-Path $projectRoot "signing"
$keystore = Join-Path $signingDir "sabaq-classroom-release.jks"
$properties = Join-Path $signingDir "keystore.properties"
if (Test-Path -LiteralPath $keystore) { throw "Signing identity already exists; refusing to replace it." }

New-Item -ItemType Directory -Force -Path $signingDir | Out-Null
$bytes = New-Object byte[] 32
[Security.Cryptography.RandomNumberGenerator]::Fill($bytes)
$password = [Convert]::ToBase64String($bytes).Replace("+","-").Replace("/","_").TrimEnd("=")
$keytool = "C:\Program Files\Java\jdk-21\bin\keytool.exe"
if (-not (Test-Path -LiteralPath $keytool)) { throw "keytool not found at $keytool" }

& $keytool -genkeypair -v -keystore $keystore -storepass $password -keypass $password -alias sabaq-classroom -keyalg RSA -keysize 4096 -validity 10000 -dname "CN=Sabaq Classroom, OU=FoxLabs, O=FoxLabs, L=Toronto, ST=Ontario, C=CA"
if ($LASTEXITCODE -ne 0) { throw "keytool failed" }

@(
    "storeFile=$($keystore.Replace('\','\\'))"
    "storePassword=$password"
    "keyAlias=sabaq-classroom"
    "keyPassword=$password"
) | Set-Content -LiteralPath $properties -Encoding utf8

$acl = Get-Acl -LiteralPath $properties
$acl.SetAccessRuleProtection($true, $false)
$rule = New-Object Security.AccessControl.FileSystemAccessRule([Security.Principal.WindowsIdentity]::GetCurrent().Name,"FullControl","Allow")
$acl.SetAccessRule($rule)
Set-Acl -LiteralPath $properties -AclObject $acl

Write-Host "Created permanent Sabaq Classroom signing identity. Back up the signing directory securely and never commit it."
