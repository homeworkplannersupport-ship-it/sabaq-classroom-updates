const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { onSchedule } = require("firebase-functions/v2/scheduler");
const { onDocumentCreated } = require("firebase-functions/v2/firestore");
const { setGlobalOptions } = require("firebase-functions/v2");
const { initializeApp } = require("firebase-admin/app");
const { getAuth } = require("firebase-admin/auth");
const { getMessaging } = require("firebase-admin/messaging");
const { getFirestore, FieldValue, Timestamp } = require("firebase-admin/firestore");
const crypto = require("node:crypto");
const {
  expirationFromHours,
  hasRecentAuthentication,
  invitationId,
  invitationMatchesVerifiedEmail,
  invitationToken,
  isInvitationUsable,
  isLastAssignedTeacher,
  transferMembership,
} = require("./security");
const {
  assignmentSnapshot,
  assignmentState,
  canEditAssignment,
  canTransitionAssignment,
  idempotentAssignmentId,
  publicationTime,
  validDate,
} = require("./assignment-policy");
const {
  canStudentAction,
  canTeacherReview,
  submissionId,
  submissionMutationKey,
  submissionSnapshot,
  submissionState,
  validateMutation,
} = require("./submission-policy");
const {
  genericNotification,
  notificationDecision,
  notificationKind,
  normalizePreferences,
} = require("./notification-policy");

initializeApp();
// Keep the private pilot inexpensive and contain unexpected traffic. Two
// instances still provide ample concurrency for the initial classrooms.
setGlobalOptions({ region: "us-central1", maxInstances: 2, memory: "256MiB" });
const db = getFirestore();
const roles = new Set(["student", "teacher", "guardian", "admin"]);
// SHA-256 of the approved pilot owner's normalized Google email. The email is
// never returned by this function and no second owner can claim the workspace.
const initialOwnerEmailHash = "ca21e35df85187daf00035ce77d3fe63b62c3ccfc226e337229c7cc570579d89";

function requireAuth(request) {
  if (!request.auth) throw new HttpsError("unauthenticated", "Sign in required.");
  return request.auth;
}
function requireRole(request, ...allowed) {
  const auth = requireAuth(request);
  if (!allowed.includes(auth.token.role)) throw new HttpsError("permission-denied", "Role not permitted.");
  return auth;
}
function requireRecentRole(request, ...allowed) {
  const auth = requireRole(request, ...allowed);
  if (!hasRecentAuthentication(auth.token)) {
    throw new HttpsError("failed-precondition", "Sign in again before this sensitive action.");
  }
  return auth;
}

exports.claimInitialAdministrator = onCall({ enforceAppCheck: true }, async request => {
  const actor = requireAuth(request);
  const email = String(actor.token.email || "").trim().toLowerCase();
  if (actor.token.email_verified !== true || !email) {
    throw new HttpsError("permission-denied", "A verified Google email is required.");
  }
  const emailHash = crypto.createHash("sha256").update(email).digest("hex");
  if (emailHash !== initialOwnerEmailHash) {
    throw new HttpsError("permission-denied", "This Google account is not approved as the workspace owner.");
  }
  const ownerRef = db.doc("system/workspaceOwner");
  const profileRef = db.doc(`profiles/${actor.uid}`);
  await db.runTransaction(async transaction => {
    const [owner, profile] = await Promise.all([transaction.get(ownerRef), transaction.get(profileRef)]);
    if (owner.exists && owner.data().uid !== actor.uid) {
      throw new HttpsError("already-exists", "The workspace owner has already been activated.");
    }
    if (profile.exists && profile.data().role !== "admin") {
      throw new HttpsError("failed-precondition", "This account already has a different role.");
    }
    if (!owner.exists) transaction.create(ownerRef, { uid: actor.uid, createdAt: FieldValue.serverTimestamp() });
    transaction.set(profileRef, {
      displayName: text(actor.token.name || "Workspace owner", "displayName", 2, 80),
      role: "admin",
      active: true,
      classroomIds: [],
      createdAt: profile.exists ? profile.data().createdAt || FieldValue.serverTimestamp() : FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
    }, { merge: true });
    transaction.set(db.doc(`privateAccounts/${actor.uid}`), {
      email,
      provider: "google.com",
      ownerBootstrap: true,
      updatedAt: FieldValue.serverTimestamp(),
    }, { merge: true });
    transaction.set(db.collection("audit").doc(), {
      actorId: actor.uid,
      action: "workspace.owner.claim",
      targetId: actor.uid,
      details: {},
      at: FieldValue.serverTimestamp(),
    });
  });
  await getAuth().setCustomUserClaims(actor.uid, { role: "admin" });
  return { uid: actor.uid, role: "admin" };
});
function text(value, name, min = 1, max = 100) {
  if (typeof value !== "string" || value.trim().length < min || value.trim().length > max) throw new HttpsError("invalid-argument", `${name} is invalid.`);
  return value.trim();
}
function secret(value, name, min = 12, max = 128) {
  if (typeof value !== "string" || value.length < min || value.length > max) {
    throw new HttpsError("invalid-argument", `${name} is invalid.`);
  }
  return value;
}
function optionalText(value, name, max) {
  if (value === undefined || value === null) return "";
  if (typeof value !== "string" || value.length > max) {
    throw new HttpsError("invalid-argument", `${name} is invalid.`);
  }
  return value.trim();
}
function stringList(value, name, maxItems, maxLength) {
  if (!Array.isArray(value) || value.length > maxItems) {
    throw new HttpsError("invalid-argument", `${name} is invalid.`);
  }
  return value.map(item => text(item, name, 1, maxLength));
}
function authorizedPaths(value, name, prefix, maxItems = 10) {
  const paths = stringList(value, name, maxItems, 1024);
  if (paths.some(path => !path.startsWith(prefix) || path.includes(".."))) {
    throw new HttpsError("invalid-argument", `${name} contains an unauthorized path.`);
  }
  return paths;
}
function stableDocumentId(actorId, requestId, kind) {
  const request = text(requestId, "requestId", 20, 128);
  return crypto.createHash("sha256").update(`${kind}:${actorId}:${request}`).digest("hex");
}
function optionalPoints(value, name = "points") {
  if (value === undefined || value === null || value === "") return null;
  const points = Number(value);
  if (!Number.isInteger(points) || points < 0 || points > 10000) throw new HttpsError("invalid-argument", `${name} is invalid.`);
  return points;
}
function ensureClassroomManager(actor, snapshot) {
  if (!snapshot.exists) throw new HttpsError("not-found", "Classroom not found.");
  if (snapshot.data().archived === true) throw new HttpsError("failed-precondition", "Classroom is archived.");
  if (actor.token.role === "teacher" && !(snapshot.data().teacherIds || []).includes(actor.uid)) {
    throw new HttpsError("permission-denied", "Not your classroom.");
  }
}
async function requireClassroomManager(actor, classId) {
  const snapshot = await db.doc(`classrooms/${classId}`).get();
  ensureClassroomManager(actor, snapshot);
  return snapshot;
}
async function audit(actorId, action, targetId, details = {}) {
  await db.collection("audit").add({ actorId, action, targetId, details, at: FieldValue.serverTimestamp() });
}
function enqueueNotification(writer, kind, recipientIds, route, entityId) {
  const recipients = [...new Set((recipientIds || []).filter(Boolean))].slice(0, 500);
  if (recipients.length === 0) return;
  writer.set(db.collection("notificationEvents").doc(), {
    kind: notificationKind(kind),
    recipientIds: recipients,
    route: text(route, "route", 1, 80),
    entityId: text(entityId, "entityId", 1, 128),
    status: "pending",
    createdAt: FieldValue.serverTimestamp(),
  });
}

function tokenValue(value) {
  if (typeof value !== "string" || value.length < 20 || value.length > 4096 || /\s/.test(value)) {
    throw new HttpsError("invalid-argument", "Device token is invalid.");
  }
  return value;
}

async function tokenRecordsForUsers(userIds) {
  const records = [];
  for (let start = 0; start < userIds.length; start += 30) {
    const chunk = userIds.slice(start, start + 30);
    if (chunk.length === 0) continue;
    const snapshot = await db.collection("deviceTokens").where("uid", "in", chunk).where("active", "==", true).get();
    snapshot.docs.forEach(document => records.push({ id: document.id, ...document.data() }));
  }
  return records;
}

async function sendGenericToTokens(tokens, notification, data) {
  let successCount = 0;
  const invalidTokenIds = [];
  for (let start = 0; start < tokens.length; start += 500) {
    const chunk = tokens.slice(start, start + 500);
    const response = await getMessaging().sendEachForMulticast({
      tokens: chunk.map(record => record.token),
      notification,
      data,
      android: {
        priority: "normal",
        notification: { channelId: "classroom_updates", visibility: "private" },
      },
    });
    successCount += response.successCount;
    response.responses.forEach((item, index) => {
      if (!item.success && new Set([
        "messaging/registration-token-not-registered",
        "messaging/invalid-registration-token",
      ]).has(item.error?.code)) invalidTokenIds.push(chunk[index].id);
    });
  }
  if (invalidTokenIds.length > 0) {
    const batch = db.batch();
    invalidTokenIds.forEach(id => batch.delete(db.doc(`deviceTokens/${id}`)));
    await batch.commit();
  }
  return successCount;
}

exports.registerDeviceToken = onCall({ enforceAppCheck: true }, async request => {
  const actor = requireAuth(request);
  const profile = await db.doc(`profiles/${actor.uid}`).get();
  if (!profile.exists || profile.data().active !== true) throw new HttpsError("permission-denied", "Active account required.");
  const token = tokenValue(request.data.token);
  const id = crypto.createHash("sha256").update(token).digest("hex");
  await db.doc(`deviceTokens/${id}`).set({
    uid: actor.uid,
    token,
    platform: "android",
    active: true,
    updatedAt: FieldValue.serverTimestamp(),
  });
  return { id };
});

exports.unregisterDeviceToken = onCall({ enforceAppCheck: true }, async request => {
  const actor = requireAuth(request);
  const id = text(request.data.tokenId, "tokenId", 64, 64);
  if (!/^[a-f0-9]{64}$/.test(id)) throw new HttpsError("invalid-argument", "tokenId is invalid.");
  const ref = db.doc(`deviceTokens/${id}`);
  const current = await ref.get();
  if (current.exists && current.data().uid !== actor.uid && actor.token.role !== "admin") {
    throw new HttpsError("permission-denied", "Not your device token.");
  }
  await ref.delete();
  return { ok: true };
});

exports.setNotificationPreferences = onCall({ enforceAppCheck: true }, async request => {
  const actor = requireAuth(request);
  const profile = await db.doc(`profiles/${actor.uid}`).get();
  if (!profile.exists || profile.data().active !== true) throw new HttpsError("permission-denied", "Active account required.");
  let preferences;
  try {
    preferences = normalizePreferences(request.data || {});
  } catch (error) {
    throw new HttpsError("invalid-argument", error.message);
  }
  await db.doc(`notificationPreferences/${actor.uid}`).set({
    ...preferences,
    updatedAt: FieldValue.serverTimestamp(),
  });
  return { ok: true };
});

exports.dispatchNotificationEvent = onDocumentCreated("notificationEvents/{eventId}", async event => {
  const snapshot = event.data;
  if (!snapshot) return;
  const record = snapshot.data();
  let kind;
  try {
    kind = notificationKind(record.kind);
  } catch {
    await snapshot.ref.update({ status: "rejected", processedAt: FieldValue.serverTimestamp() });
    return;
  }
  const recipientIds = [...new Set((record.recipientIds || []).filter(value => typeof value === "string"))].slice(0, 500);
  if (recipientIds.length === 0) {
    await snapshot.ref.update({ status: "processed", successCount: 0, deferredCount: 0, droppedCount: 0, processedAt: FieldValue.serverTimestamp() });
    return;
  }
  const profileRefs = recipientIds.map(uid => db.doc(`profiles/${uid}`));
  const preferenceRefs = recipientIds.map(uid => db.doc(`notificationPreferences/${uid}`));
  const [profiles, preferences] = await Promise.all([db.getAll(...profileRefs), db.getAll(...preferenceRefs)]);
  const immediateIds = [];
  const deferred = [];
  let droppedCount = 0;
  recipientIds.forEach((uid, index) => {
    if (!profiles[index].exists || profiles[index].data().active !== true) {
      droppedCount += 1;
      return;
    }
    let decision;
    try {
      decision = notificationDecision(preferences[index].exists ? preferences[index].data() : {}, kind, new Date());
    } catch {
      decision = notificationDecision({}, kind, new Date());
    }
    if (decision.action === "send") immediateIds.push(uid);
    else if (decision.action === "defer") deferred.push({ uid, dueAt: decision.dueAt, reason: decision.reason });
    else droppedCount += 1;
  });
  const tokens = await tokenRecordsForUsers(immediateIds);
  const notification = genericNotification(kind);
  const successCount = await sendGenericToTokens(tokens, notification, {
    eventId: snapshot.id,
    kind,
    route: String(record.route || "classroom").slice(0, 80),
  });
  const batch = db.batch();
  deferred.forEach(item => {
    const digestId = crypto.createHash("sha256").update(`${snapshot.id}:${item.uid}`).digest("hex");
    batch.set(db.doc(`notificationDigests/${digestId}`), {
      uid: item.uid,
      eventId: snapshot.id,
      kind,
      route: String(record.route || "classroom").slice(0, 80),
      dueAt: Timestamp.fromDate(item.dueAt),
      reason: item.reason,
      status: "pending",
      createdAt: FieldValue.serverTimestamp(),
    });
  });
  batch.update(snapshot.ref, {
    status: "processed",
    successCount,
    deferredCount: deferred.length,
    droppedCount,
    processedAt: FieldValue.serverTimestamp(),
  });
  await batch.commit();
});

exports.deliverNotificationDigests = onSchedule({ schedule: "every 15 minutes", timeZone: "UTC" }, async () => {
  const due = await db.collection("notificationDigests")
    .where("status", "==", "pending")
    .where("dueAt", "<=", Timestamp.now())
    .orderBy("dueAt")
    .limit(100)
    .get();
  const groups = new Map();
  due.docs.forEach(document => {
    const uid = document.data().uid;
    if (!groups.has(uid)) groups.set(uid, []);
    groups.get(uid).push(document);
  });
  for (const [uid, documents] of groups.entries()) {
    const tokens = await tokenRecordsForUsers([uid]);
    const successCount = await sendGenericToTokens(tokens, {
      title: "Classroom updates",
      body: "Open Sabaq Workspace when you’re ready.",
    }, { eventId: documents.map(document => document.id).join(",").slice(0, 900), kind: "digest", route: "classroom" });
    const batch = db.batch();
    documents.forEach(document => batch.update(document.ref, {
      status: tokens.length === 0 ? "no_device" : "delivered",
      successCount,
      deliveredAt: FieldValue.serverTimestamp(),
    }));
    await batch.commit();
  }
});

exports.createAccount = onCall({ enforceAppCheck: true }, async (request) => {
  const actor = requireRecentRole(request, "admin");
  const displayName = text(request.data.displayName, "displayName", 2, 80);
  const email = text(request.data.email, "email", 5, 200).toLowerCase();
  const role = text(request.data.role, "role", 4, 10);
  if (!roles.has(role)) throw new HttpsError("invalid-argument", "Unsupported role.");
  const temporaryPassword = secret(request.data.temporaryPassword, "temporaryPassword");
  const user = await getAuth().createUser({ email, password: temporaryPassword, displayName, disabled: false });
  await getAuth().setCustomUserClaims(user.uid, { role });
  const batch = db.batch();
  batch.set(db.doc(`profiles/${user.uid}`), { displayName, role, active: true, classroomIds: [], createdAt: FieldValue.serverTimestamp() });
  batch.set(db.doc(`privateAccounts/${user.uid}`), { email, mustChangePassword: true, createdBy: actor.uid, createdAt: FieldValue.serverTimestamp() });
  await batch.commit(); await audit(actor.uid, "account.create", user.uid, { role });
  return { uid: user.uid };
});

exports.setAccountActive = onCall({ enforceAppCheck: true }, async (request) => {
  const actor = requireRecentRole(request, "admin");
  const uid = text(request.data.uid, "uid", 10, 128);
  const active = request.data.active === true;
  if (uid === actor.uid) throw new HttpsError("failed-precondition", "Administrators cannot change their own access.");
  const profileRef = db.doc(`profiles/${uid}`);
  const [profile, authUser] = await Promise.all([profileRef.get(), getAuth().getUser(uid)]);
  if (!profile.exists) throw new HttpsError("not-found", "Account profile not found.");
  if (profile.data().role === "admin") throw new HttpsError("permission-denied", "Administrator access requires the protected operator process.");
  if (active && profile.data().offboardedAt) throw new HttpsError("failed-precondition", "Offboarded accounts cannot be reactivated directly.");
  await getAuth().updateUser(uid, { disabled: !active });
  try {
    const batch = db.batch();
    batch.update(profileRef, { active, updatedAt: FieldValue.serverTimestamp() });
    batch.set(db.collection("audit").doc(), {
      actorId: actor.uid,
      action: active ? "account.activate" : "account.suspend",
      targetId: uid,
      details: {},
      at: FieldValue.serverTimestamp(),
    });
    await batch.commit();
    if (!active) await getAuth().revokeRefreshTokens(uid);
    return { ok: true };
  } catch {
    await getAuth().updateUser(uid, { disabled: authUser.disabled }).catch(() => undefined);
    throw new HttpsError("internal", "Account access change failed.");
  }
});

exports.changeAccountRole = onCall({ enforceAppCheck: true }, async (request) => {
  const actor = requireRecentRole(request, "admin");
  const uid = text(request.data.uid, "uid", 10, 128);
  const role = text(request.data.role, "role", 4, 10);
  if (!roles.has(role) || role === "admin" || uid === actor.uid) {
    throw new HttpsError("invalid-argument", "Unsupported role change.");
  }
  const profileRef = db.doc(`profiles/${uid}`);
  const [profile, authUser] = await Promise.all([profileRef.get(), getAuth().getUser(uid)]);
  if (!profile.exists) throw new HttpsError("not-found", "Account profile not found.");
  const priorRole = profile.data().role;
  if (priorRole === "admin") throw new HttpsError("permission-denied", "Administrator roles use the protected operator process.");
  if (priorRole === role) return { ok: true };
  const linkedIds = [
    ...(profile.data().classroomIds || []),
    ...(profile.data().studentIds || []),
    ...(profile.data().guardianIds || []),
  ];
  if (linkedIds.length > 0) {
    throw new HttpsError("failed-precondition", "Remove classroom and guardian links before changing role.");
  }
  await getAuth().setCustomUserClaims(uid, { ...(authUser.customClaims || {}), role });
  try {
    const batch = db.batch();
    batch.update(profileRef, { role, updatedAt: FieldValue.serverTimestamp() });
    batch.set(db.collection("audit").doc(), {
      actorId: actor.uid,
      action: "account.role.change",
      targetId: uid,
      details: { from: priorRole, to: role },
      at: FieldValue.serverTimestamp(),
    });
    await batch.commit();
    await getAuth().revokeRefreshTokens(uid);
    return { ok: true };
  } catch {
    await getAuth().setCustomUserClaims(uid, authUser.customClaims || { role: priorRole }).catch(() => undefined);
    throw new HttpsError("internal", "Role change failed.");
  }
});

exports.transferClassroomMember = onCall({ enforceAppCheck: true }, async (request) => {
  const actor = requireRecentRole(request, "admin");
  const uid = text(request.data.uid, "uid", 10, 128);
  const fromClassroomId = text(request.data.fromClassroomId, "fromClassroomId", 5, 128);
  const toClassroomId = text(request.data.toClassroomId, "toClassroomId", 5, 128);
  if (fromClassroomId === toClassroomId) throw new HttpsError("invalid-argument", "Choose a different destination classroom.");
  const profileRef = db.doc(`profiles/${uid}`);
  const fromRef = db.doc(`classrooms/${fromClassroomId}`);
  const toRef = db.doc(`classrooms/${toClassroomId}`);
  await db.runTransaction(async transaction => {
    const [profile, fromClassroom, toClassroom] = await Promise.all([
      transaction.get(profileRef),
      transaction.get(fromRef),
      transaction.get(toRef),
    ]);
    if (!profile.exists || profile.data().role !== "student" || profile.data().active !== true) {
      throw new HttpsError("failed-precondition", "Choose an active student account.");
    }
    if (!fromClassroom.exists || !(fromClassroom.data().memberIds || []).includes(uid)) {
      throw new HttpsError("failed-precondition", "Student is not in the source classroom.");
    }
    if (!toClassroom.exists || toClassroom.data().archived === true) {
      throw new HttpsError("failed-precondition", "Destination classroom is unavailable.");
    }
    transaction.update(fromRef, { memberIds: FieldValue.arrayRemove(uid) });
    transaction.update(toRef, { memberIds: FieldValue.arrayUnion(uid) });
    const transfer = transferMembership(
      profile.data().classroomIds || [],
      profile.data().historicalClassroomIds || [],
      fromClassroomId,
      toClassroomId,
    );
    transaction.update(profileRef, { ...transfer, updatedAt: FieldValue.serverTimestamp() });
    transaction.set(db.collection("audit").doc(), {
      actorId: actor.uid,
      action: "classroom.member.transfer",
      targetId: uid,
      details: { fromClassroomId, toClassroomId },
      at: FieldValue.serverTimestamp(),
    });
  });
  return { ok: true };
});

exports.offboardAccount = onCall({ enforceAppCheck: true }, async (request) => {
  const actor = requireRecentRole(request, "admin");
  const uid = text(request.data.uid, "uid", 10, 128);
  if (uid === actor.uid) throw new HttpsError("failed-precondition", "Administrators cannot offboard themselves.");
  const profileRef = db.doc(`profiles/${uid}`);
  const profile = await profileRef.get();
  if (!profile.exists) throw new HttpsError("not-found", "Account profile not found.");
  if (profile.data().role === "admin") throw new HttpsError("permission-denied", "Administrator offboarding requires the protected operator process.");
  const authUser = await getAuth().getUser(uid);
  await getAuth().updateUser(uid, { disabled: true });
  try {
    await db.runTransaction(async transaction => {
      const current = await transaction.get(profileRef);
      if (!current.exists || current.data().active !== true) {
        throw new HttpsError("failed-precondition", "Account is not active.");
      }
      const classroomIds = current.data().classroomIds || [];
      const linkedIds = current.data().role === "guardian"
        ? current.data().studentIds || []
        : current.data().role === "student" ? current.data().guardianIds || [] : [];
      const classroomRefs = classroomIds.map(id => db.doc(`classrooms/${id}`));
      const linkedRefs = linkedIds.map(id => db.doc(`profiles/${id}`));
      const [classrooms, linkedProfiles] = await Promise.all([
        Promise.all(classroomRefs.map(ref => transaction.get(ref))),
        Promise.all(linkedRefs.map(ref => transaction.get(ref))),
      ]);
      if (current.data().role === "teacher" && classrooms.some(snapshot =>
        snapshot.exists && isLastAssignedTeacher(snapshot.data().teacherIds || [], uid))) {
        throw new HttpsError("failed-precondition", "Assign another teacher before offboarding the classroom’s last teacher.");
      }
      classrooms.forEach((snapshot, index) => {
        if (!snapshot.exists) return;
        transaction.update(classroomRefs[index], {
          memberIds: FieldValue.arrayRemove(uid),
          teacherIds: FieldValue.arrayRemove(uid),
        });
      });
      linkedProfiles.forEach((snapshot, index) => {
        if (!snapshot.exists) return;
        transaction.update(linkedRefs[index], profile.data().role === "guardian"
          ? { guardianIds: FieldValue.arrayRemove(uid), updatedAt: FieldValue.serverTimestamp() }
          : { studentIds: FieldValue.arrayRemove(uid), updatedAt: FieldValue.serverTimestamp() });
      });
      transaction.update(profileRef, {
        active: false,
        classroomIds: [],
        historicalClassroomIds: [...new Set((current.data().historicalClassroomIds || []).concat(classroomIds))],
        studentIds: [],
        guardianIds: [],
        offboardedAt: FieldValue.serverTimestamp(),
        updatedAt: FieldValue.serverTimestamp(),
      });
      transaction.set(db.collection("audit").doc(), {
        actorId: actor.uid,
        action: "account.offboard",
        targetId: uid,
        details: { role: current.data().role, classroomIds },
        at: FieldValue.serverTimestamp(),
      });
    });
    await getAuth().revokeRefreshTokens(uid);
    return { ok: true };
  } catch (error) {
    await getAuth().updateUser(uid, { disabled: authUser.disabled }).catch(() => undefined);
    if (error instanceof HttpsError) throw error;
    throw new HttpsError("internal", "Account offboarding failed.");
  }
});

exports.createClassroom = onCall({ enforceAppCheck: true }, async (request) => {
  const actor = requireRecentRole(request, "admin"); const name = text(request.data.name,"name",2,80); const section = text(request.data.section || "General","section",1,80); const teacherId = text(request.data.teacherId,"teacherId",10,128);
  const teacher = await db.doc(`profiles/${teacherId}`).get(); if (!teacher.exists || teacher.data().role !== "teacher") throw new HttpsError("failed-precondition","Teacher not found.");
  const ref = db.collection("classrooms").doc(); await ref.set({ name, section, teacherIds:[teacherId], memberIds:[teacherId], archived:false, gradingEnabled:false, createdAt:FieldValue.serverTimestamp(), updatedAt:FieldValue.serverTimestamp() });
  await db.doc(`profiles/${teacherId}`).update({ classroomIds:FieldValue.arrayUnion(ref.id) }); await audit(actor.uid,"classroom.create",ref.id,{teacherId}); return { id:ref.id };
});

exports.updateClassroom = onCall({ enforceAppCheck: true }, async request => {
  const actor = requireRole(request, "admin", "teacher");
  const classId = text(request.data.classroomId, "classroomId", 5, 128);
  const classroom = await db.doc(`classrooms/${classId}`).get();
  if (!classroom.exists) throw new HttpsError("not-found", "Classroom not found.");
  if (actor.token.role === "teacher" && !(classroom.data().teacherIds || []).includes(actor.uid)) {
    throw new HttpsError("permission-denied", "Not your classroom.");
  }
  const archived = request.data.archived === true;
  const gradingEnabled = request.data.gradingEnabled === undefined ? classroom.data().gradingEnabled === true : request.data.gradingEnabled === true;
  await classroom.ref.update({
    name: text(request.data.name, "name", 2, 80),
    section: text(request.data.section || "General", "section", 1, 80),
    archived,
    gradingEnabled,
    updatedAt: FieldValue.serverTimestamp(),
  });
  await audit(actor.uid, archived ? "classroom.archive" : "classroom.update", classId, {});
  return { ok: true };
});

exports.addClassroomMember = onCall({ enforceAppCheck: true }, async (request) => {
  const actor = requireRole(request,"admin","teacher"); const classId=text(request.data.classroomId,"classroomId",5,128); const uid=text(request.data.uid,"uid",10,128); const classRef=db.doc(`classrooms/${classId}`); const snap=await classRef.get();
  if(!snap.exists)throw new HttpsError("not-found","Classroom not found."); if(actor.token.role==="teacher"&&!snap.data().teacherIds.includes(actor.uid))throw new HttpsError("permission-denied","Not your classroom.");
  const profileRef=db.doc(`profiles/${uid}`); const profile=await profileRef.get();
  if(!profile.exists||!["student","teacher"].includes(profile.data().role))throw new HttpsError("failed-precondition","Only active students or teachers can join a classroom.");
  await db.runTransaction(async tx=>{tx.update(classRef,{memberIds:FieldValue.arrayUnion(uid),...(profile.data().role==="teacher"?{teacherIds:FieldValue.arrayUnion(uid)}:{})});tx.update(profileRef,{classroomIds:FieldValue.arrayUnion(classId),updatedAt:FieldValue.serverTimestamp()});}); await audit(actor.uid,profile.data().role==="teacher"?"classroom.co_teacher.add":"classroom.member.add",uid,{classId}); return {ok:true};
});

exports.removeClassroomMember = onCall({ enforceAppCheck: true }, async (request) => {
  const actor = requireRole(request, "admin", "teacher");
  const classId = text(request.data.classroomId, "classroomId", 5, 128);
  const uid = text(request.data.uid, "uid", 10, 128);
  const classRef = db.doc(`classrooms/${classId}`);
  const profileRef = db.doc(`profiles/${uid}`);
  await db.runTransaction(async tx => {
    const [classroom, profile] = await Promise.all([tx.get(classRef), tx.get(profileRef)]);
    if (!classroom.exists || !profile.exists) throw new HttpsError("not-found", "Classroom member not found.");
    const data = classroom.data();
    if (actor.token.role === "teacher" && !(data.teacherIds || []).includes(actor.uid)) throw new HttpsError("permission-denied", "Not your classroom.");
    if (!(data.memberIds || []).includes(uid)) throw new HttpsError("failed-precondition", "This account is not in the classroom.");
    const isTeacher = profile.data().role === "teacher";
    if (isTeacher && (data.teacherIds || []).filter(id => id !== uid).length === 0) throw new HttpsError("failed-precondition", "A classroom must keep at least one teacher.");
    tx.update(classRef, { memberIds: FieldValue.arrayRemove(uid), ...(isTeacher ? { teacherIds: FieldValue.arrayRemove(uid) } : {}) });
    tx.update(profileRef, { classroomIds: FieldValue.arrayRemove(classId), updatedAt: FieldValue.serverTimestamp() });
  });
  await audit(actor.uid, "classroom.member.remove", uid, { classId });
  return { ok: true };
});

exports.linkGuardian = onCall({ enforceAppCheck: true }, async (request) => {
  const actor=requireRecentRole(request,"admin"); const guardianId=text(request.data.guardianId,"guardianId",10,128); const studentId=text(request.data.studentId,"studentId",10,128);
  const [guardian,student]=await Promise.all([db.doc(`profiles/${guardianId}`).get(),db.doc(`profiles/${studentId}`).get()]);
  if(!guardian.exists||guardian.data().role!=="guardian"||!student.exists||student.data().role!=="student")throw new HttpsError("failed-precondition","Choose valid guardian and student accounts.");
  await db.runTransaction(async tx=>{
    tx.update(db.doc(`profiles/${guardianId}`),{studentIds:FieldValue.arrayUnion(studentId),classroomIds:FieldValue.arrayUnion(...(student.data().classroomIds||[])),updatedAt:FieldValue.serverTimestamp()});
    tx.update(db.doc(`profiles/${studentId}`),{guardianIds:FieldValue.arrayUnion(guardianId),updatedAt:FieldValue.serverTimestamp()});
  });
  await audit(actor.uid,"guardian.link",studentId,{guardianId}); return {ok:true};
});

exports.publishAssignment = onCall({ enforceAppCheck: true }, async (request) => {
  const actor = requireRole(request, "teacher", "admin");
  const classId = text(request.data.classroomId, "classroomId", 5, 128);
  let state;
  let dueAt;
  let publishAt;
  try {
    state = assignmentState(request.data.state, true);
    dueAt = validDate(request.data.dueAt, "dueAt");
    publishAt = publicationTime(state, request.data.publishAt, dueAt);
  } catch (error) {
    throw new HttpsError("invalid-argument", error.message);
  }
  const estimateMinutes = Number(request.data.estimateMinutes || 30);
  if (!Number.isInteger(estimateMinutes) || estimateMinutes < 5 || estimateMinutes > 600) {
    throw new HttpsError("invalid-argument", "estimateMinutes must be between 5 and 600.");
  }
  const requestId = request.data.requestId || crypto.randomUUID();
  let id;
  try {
    id = idempotentAssignmentId(actor.uid, requestId);
  } catch (error) {
    throw new HttpsError("invalid-argument", error.message);
  }
  const ref = db.doc(`assignments/${id}`);
  if ((await ref.get()).exists) return { id, created: false };
  const assignment = {
    classroomId: classId,
    teacherId: actor.uid,
    requestId,
    title: text(request.data.title, "title", 2, 160),
    instructions: text(request.data.instructions || " ", "instructions", 1, 5000),
    subject: text(request.data.subject || "Sabaq", "subject", 1, 80),
    type: text(request.data.type || "Sabaq", "type", 1, 80),
    steps: stringList(request.data.steps || [], "step", 50, 500),
    attachmentPaths: authorizedPaths(request.data.attachmentPaths || [], "attachmentPath", `classrooms/${classId}/assignments/${id}/`),
    pointsPossible: optionalPoints(request.data.pointsPossible, "pointsPossible"),
    commentsEnabled: request.data.commentsEnabled !== false,
    dueAt: Timestamp.fromDate(dueAt),
    publishAt: publishAt ? Timestamp.fromDate(publishAt) : null,
    estimateMinutes,
    priority: text(request.data.priority || "Standard", "priority", 1, 40),
    state,
    revision: 1,
    createdAt: FieldValue.serverTimestamp(),
    updatedAt: FieldValue.serverTimestamp(),
  };
  let created = false;
  await db.runTransaction(async transaction => {
    const [classroom, existing] = await Promise.all([
      transaction.get(db.doc(`classrooms/${classId}`)),
      transaction.get(ref),
    ]);
    ensureClassroomManager(actor, classroom);
    if (existing.exists) return;
    transaction.create(ref, assignment);
    transaction.set(db.collection("audit").doc(), {
      actorId: actor.uid,
      action: "assignment.create",
      targetId: id,
      details: { classId, state, requestId },
      at: FieldValue.serverTimestamp(),
    });
    if (state === "published") {
      enqueueNotification(transaction, "assignment_new", (classroom.data().memberIds || []).filter(uid => uid !== actor.uid), "classwork", id);
    }
    created = true;
  });
  return { id, created };
});

exports.createAssignment = exports.publishAssignment;

exports.updateAssignment = onCall({ enforceAppCheck: true }, async request => {
  const actor = requireRole(request, "teacher", "admin");
  const assignmentId = text(request.data.assignmentId, "assignmentId", 20, 128);
  const ref = db.doc(`assignments/${assignmentId}`);
  const initial = await ref.get();
  if (!initial.exists) throw new HttpsError("not-found", "Assignment not found.");
  await requireClassroomManager(actor, initial.data().classroomId);
  let dueAt;
  try {
    dueAt = validDate(request.data.dueAt, "dueAt");
    if (dueAt.getTime() <= Date.now()) throw new Error("Due time must be in the future.");
  } catch (error) {
    throw new HttpsError("invalid-argument", error.message);
  }
  const estimateMinutes = Number(request.data.estimateMinutes || initial.data().estimateMinutes);
  if (!Number.isInteger(estimateMinutes) || estimateMinutes < 5 || estimateMinutes > 600) {
    throw new HttpsError("invalid-argument", "estimateMinutes must be between 5 and 600.");
  }
  await db.runTransaction(async transaction => {
    const current = await transaction.get(ref);
    if (!current.exists || !canEditAssignment(current.data().state)) {
      throw new HttpsError("failed-precondition", "Assignment can no longer be edited.");
    }
    const classroom = await transaction.get(db.doc(`classrooms/${current.data().classroomId}`));
    ensureClassroomManager(actor, classroom);
    if (current.data().state === "scheduled" && current.data().publishAt?.toMillis?.() >= dueAt.getTime()) {
      throw new HttpsError("invalid-argument", "Due time must remain after scheduled publication.");
    }
    const revision = Number(current.data().revision || 1);
    transaction.set(db.collection("assignmentRevisions").doc(), {
      assignmentId,
      classroomId: current.data().classroomId,
      revision,
      snapshot: assignmentSnapshot(current.data()),
      editedBy: actor.uid,
      editedAt: FieldValue.serverTimestamp(),
    });
    transaction.update(ref, {
      title: text(request.data.title, "title", 2, 160),
      instructions: text(request.data.instructions || " ", "instructions", 1, 5000),
      subject: text(request.data.subject || "Sabaq", "subject", 1, 80),
      type: text(request.data.type || "Sabaq", "type", 1, 80),
      steps: stringList(request.data.steps || [], "step", 50, 500),
      attachmentPaths: authorizedPaths(request.data.attachmentPaths || [], "attachmentPath", `classrooms/${current.data().classroomId}/assignments/${assignmentId}/`),
      pointsPossible: optionalPoints(request.data.pointsPossible, "pointsPossible"),
      commentsEnabled: request.data.commentsEnabled !== false,
      dueAt: Timestamp.fromDate(dueAt),
      estimateMinutes,
      priority: text(request.data.priority || "Standard", "priority", 1, 40),
      revision: revision + 1,
      updatedAt: FieldValue.serverTimestamp(),
    });
    transaction.set(db.collection("audit").doc(), {
      actorId: actor.uid,
      action: "assignment.update",
      targetId: assignmentId,
      details: { classId: current.data().classroomId, fromRevision: revision },
      at: FieldValue.serverTimestamp(),
    });
    if (current.data().state === "published") {
      enqueueNotification(transaction, "assignment_changed", (classroom.data().memberIds || []).filter(uid => uid !== actor.uid), "classwork", assignmentId);
    }
  });
  return { ok: true };
});

exports.transitionAssignment = onCall({ enforceAppCheck: true }, async request => {
  const actor = requireRole(request, "teacher", "admin");
  const assignmentId = text(request.data.assignmentId, "assignmentId", 20, 128);
  const ref = db.doc(`assignments/${assignmentId}`);
  const initial = await ref.get();
  if (!initial.exists) throw new HttpsError("not-found", "Assignment not found.");
  await requireClassroomManager(actor, initial.data().classroomId);
  let destination;
  try {
    destination = assignmentState(request.data.state);
  } catch (error) {
    throw new HttpsError("invalid-argument", error.message);
  }
  await db.runTransaction(async transaction => {
    const current = await transaction.get(ref);
    if (!current.exists || !canTransitionAssignment(current.data().state, destination)) {
      throw new HttpsError("failed-precondition", "Invalid assignment state change.");
    }
    const classroom = await transaction.get(db.doc(`classrooms/${current.data().classroomId}`));
    ensureClassroomManager(actor, classroom);
    let publishAt = current.data().publishAt || null;
    if (destination === "draft" || destination === "archived") publishAt = null;
    if (destination === "published") publishAt = FieldValue.serverTimestamp();
    if (destination === "scheduled") {
      let scheduled;
      try {
        scheduled = publicationTime("scheduled", request.data.publishAt, current.data().dueAt.toDate());
      } catch (error) {
        throw new HttpsError("invalid-argument", error.message);
      }
      publishAt = Timestamp.fromDate(scheduled);
    }
    const revision = Number(current.data().revision || 1);
    transaction.set(db.collection("assignmentRevisions").doc(), {
      assignmentId,
      classroomId: current.data().classroomId,
      revision,
      snapshot: assignmentSnapshot(current.data()),
      editedBy: actor.uid,
      editedAt: FieldValue.serverTimestamp(),
    });
    transaction.update(ref, {
      state: destination,
      publishAt,
      revision: revision + 1,
      updatedAt: FieldValue.serverTimestamp(),
    });
    transaction.set(db.collection("audit").doc(), {
      actorId: actor.uid,
      action: "assignment.state.change",
      targetId: assignmentId,
      details: { from: current.data().state, to: destination, classId: current.data().classroomId },
      at: FieldValue.serverTimestamp(),
    });
    if (destination === "published") {
      enqueueNotification(transaction, current.data().state === "closed" ? "assignment_changed" : "assignment_new", (classroom.data().memberIds || []).filter(uid => uid !== actor.uid), "classwork", assignmentId);
    }
  });
  return { ok: true };
});

exports.promoteScheduledAssignments = onSchedule({ schedule: "every 5 minutes", timeZone: "UTC" }, async () => {
  const now = Timestamp.now();
  const due = await db.collection("assignments")
    .where("state", "==", "scheduled")
    .where("publishAt", "<=", now)
    .orderBy("publishAt")
    .limit(100)
    .get();
  await Promise.all(due.docs.map(document => db.runTransaction(async transaction => {
    const current = await transaction.get(document.ref);
    if (!current.exists || current.data().state !== "scheduled" || current.data().publishAt.toMillis() > Date.now()) return;
    const classroom = await transaction.get(db.doc(`classrooms/${current.data().classroomId}`));
    const revision = Number(current.data().revision || 1);
    transaction.set(db.collection("assignmentRevisions").doc(), {
      assignmentId: current.id,
      classroomId: current.data().classroomId,
      revision,
      snapshot: assignmentSnapshot(current.data()),
      editedBy: "system",
      editedAt: FieldValue.serverTimestamp(),
    });
    transaction.update(current.ref, {
      state: "published",
      revision: revision + 1,
      updatedAt: FieldValue.serverTimestamp(),
    });
    transaction.set(db.collection("audit").doc(), {
      actorId: "system",
      action: "assignment.schedule.publish",
      targetId: current.id,
      details: { classId: current.data().classroomId },
      at: FieldValue.serverTimestamp(),
    });
    if (classroom.exists && classroom.data().archived !== true) {
      enqueueNotification(transaction, "assignment_new", (classroom.data().memberIds || []).filter(uid => uid !== current.data().teacherId), "classwork", current.id);
    }
  })));
});

exports.postAnnouncement = onCall({ enforceAppCheck: true }, async request => {
  const actor = requireRole(request, "teacher", "admin");
  const classId = text(request.data.classroomId, "classroomId", 5, 128);
  const classroom = await requireClassroomManager(actor, classId);
  const id = stableDocumentId(actor.uid, request.data.requestId || crypto.randomUUID(), "announcement");
  const ref = db.doc(`announcements/${id}`);
  if ((await ref.get()).exists) return { id, created: false };
  const scheduled = request.data.state === "scheduled";
  const publishAt = scheduled ? Timestamp.fromDate(validDate(request.data.publishAt, "publishAt")) : FieldValue.serverTimestamp();
  const batch = db.batch();
  batch.create(ref, {
    classroomId: classId,
    authorId: actor.uid,
    title: text(request.data.title, "title", 2, 160),
    body: text(request.data.body, "body", 1, 5000),
    attachmentPaths: authorizedPaths(request.data.attachmentPaths || [], "attachmentPath", `classrooms/${classId}/announcements/${ref.id}/`),
    state: scheduled ? "scheduled" : "published",
    publishAt,
    pinned: request.data.pinned === true,
    commentsEnabled: request.data.commentsEnabled !== false,
    createdAt: FieldValue.serverTimestamp(),
    updatedAt: FieldValue.serverTimestamp(),
  });
  batch.set(db.collection("audit").doc(), { actorId: actor.uid, action: "announcement.post", targetId: ref.id, details: { classId }, at: FieldValue.serverTimestamp() });
  if (!scheduled) enqueueNotification(batch, "announcement_new", (classroom.data().memberIds || []).filter(uid => uid !== actor.uid), "classroom", ref.id);
  await batch.commit();
  return { id: ref.id, created: true };
});

exports.updateAnnouncement = onCall({ enforceAppCheck: true }, async request => {
  const actor = requireRole(request, "teacher", "admin");
  const id = text(request.data.announcementId, "announcementId", 20, 128);
  const ref = db.doc(`announcements/${id}`);
  await db.runTransaction(async transaction => {
    const current = await transaction.get(ref);
    if (!current.exists) throw new HttpsError("not-found", "Announcement not found.");
    const classroom = await transaction.get(db.doc(`classrooms/${current.data().classroomId}`));
    ensureClassroomManager(actor, classroom);
    const state = request.data.state || current.data().state || "published";
    if (!["scheduled", "published", "archived"].includes(state)) throw new HttpsError("invalid-argument", "Announcement state is invalid.");
    const publishAt = state === "scheduled" ? Timestamp.fromDate(validDate(request.data.publishAt, "publishAt")) : (state === "published" ? FieldValue.serverTimestamp() : null);
    transaction.update(ref, {
      title: text(request.data.title, "title", 2, 160),
      body: text(request.data.body, "body", 1, 5000),
      attachmentPaths: authorizedPaths(request.data.attachmentPaths || [], "attachmentPath", `classrooms/${current.data().classroomId}/announcements/${id}/`),
      state,
      publishAt,
      pinned: request.data.pinned === true,
      commentsEnabled: request.data.commentsEnabled !== false,
      updatedAt: FieldValue.serverTimestamp(),
    });
    transaction.set(db.collection("audit").doc(), { actorId: actor.uid, action: state === "archived" ? "announcement.remove" : "announcement.update", targetId: id, details: { classId: current.data().classroomId, state }, at: FieldValue.serverTimestamp() });
    if (state === "published" && current.data().state !== "published") enqueueNotification(transaction, "announcement_new", (classroom.data().memberIds || []).filter(uid => uid !== actor.uid), "classroom", id);
  });
  return { ok: true };
});

exports.promoteScheduledAnnouncements = onSchedule({ schedule: "every 5 minutes", timeZone: "UTC" }, async () => {
  const due = await db.collection("announcements").where("state", "==", "scheduled").where("publishAt", "<=", Timestamp.now()).orderBy("publishAt").limit(100).get();
  await Promise.all(due.docs.map(document => db.runTransaction(async transaction => {
    const current = await transaction.get(document.ref);
    if (!current.exists || current.data().state !== "scheduled" || current.data().publishAt.toMillis() > Date.now()) return;
    const classroom = await transaction.get(db.doc(`classrooms/${current.data().classroomId}`));
    transaction.update(current.ref, { state: "published", updatedAt: FieldValue.serverTimestamp() });
    transaction.set(db.collection("audit").doc(), { actorId: "system", action: "announcement.schedule.publish", targetId: current.id, details: { classId: current.data().classroomId }, at: FieldValue.serverTimestamp() });
    if (classroom.exists && classroom.data().archived !== true) enqueueNotification(transaction, "announcement_new", (classroom.data().memberIds || []).filter(uid => uid !== current.data().authorId), "classroom", current.id);
  })));
});

exports.postComment = onCall({ enforceAppCheck: true }, async request => {
  const actor = requireRole(request, "student", "teacher", "admin");
  const entityType = text(request.data.entityType, "entityType", 8, 12);
  if (!new Set(["assignment", "announcement"]).has(entityType)) throw new HttpsError("invalid-argument", "Comment target is invalid.");
  const entityId = text(request.data.entityId, "entityId", 20, 128);
  const entity = await db.doc(`${entityType === "assignment" ? "assignments" : "announcements"}/${entityId}`).get();
  if (!entity.exists || entity.data().state === "archived") throw new HttpsError("not-found", "Post not found.");
  const classId = entity.data().classroomId;
  const classroom = await db.doc(`classrooms/${classId}`).get();
  const profile = await db.doc(`profiles/${actor.uid}`).get();
  if (!profile.exists || profile.data().active !== true || !(profile.data().classroomIds || []).includes(classId)) throw new HttpsError("permission-denied", "Not in this classroom.");
  if (entity.data().commentsEnabled === false) throw new HttpsError("failed-precondition", "Discussion is locked for this post.");
  const visibility = request.data.visibility === "private" ? "private" : "public";
  const studentId = visibility === "private" ? (actor.token.role === "student" ? actor.uid : text(request.data.studentId, "studentId", 10, 128)) : null;
  if (visibility === "private" && actor.token.role !== "student" && !(classroom.data().memberIds || []).includes(studentId)) throw new HttpsError("failed-precondition", "Student is not in this classroom.");
  const id = stableDocumentId(actor.uid, request.data.requestId || crypto.randomUUID(), "comment");
  const ref = db.doc(`comments/${id}`);
  if ((await ref.get()).exists) return { id, created: false };
  const recipients = visibility === "private" ? (actor.token.role === "student" ? classroom.data().teacherIds || [] : [studentId]) : (classroom.data().memberIds || []).filter(uid => uid !== actor.uid);
  const batch = db.batch();
  batch.create(ref, { classId, entityType, entityId, authorId: actor.uid, visibility, studentId, body: text(request.data.body, "body", 1, 2000), createdAt: FieldValue.serverTimestamp(), updatedAt: FieldValue.serverTimestamp(), removed: false });
  batch.set(db.collection("audit").doc(), { actorId: actor.uid, action: `comment.${visibility}.post`, targetId: id, details: { classId, entityType, entityId }, at: FieldValue.serverTimestamp() });
  enqueueNotification(batch, "comment_new", recipients, "classroom", entityId);
  await batch.commit();
  return { id, created: true };
});

exports.removeComment = onCall({ enforceAppCheck: true }, async request => {
  const actor = requireRole(request, "student", "teacher", "admin");
  const id = text(request.data.commentId, "commentId", 20, 128);
  const ref = db.doc(`comments/${id}`);
  await db.runTransaction(async transaction => {
    const current = await transaction.get(ref);
    if (!current.exists) throw new HttpsError("not-found", "Comment not found.");
    const classroom = await transaction.get(db.doc(`classrooms/${current.data().classId}`));
    const canModerate = actor.token.role === "admin" || (actor.token.role === "teacher" && (classroom.data().teacherIds || []).includes(actor.uid));
    if (current.data().authorId !== actor.uid && !canModerate) throw new HttpsError("permission-denied", "Comment cannot be removed.");
    transaction.update(ref, { body: "", removed: true, removedBy: actor.uid, updatedAt: FieldValue.serverTimestamp() });
    transaction.set(db.collection("audit").doc(), { actorId: actor.uid, action: "comment.remove", targetId: id, details: { classId: current.data().classId }, at: FieldValue.serverTimestamp() });
  });
  return { ok: true };
});

exports.recordProgress = onCall({ enforceAppCheck: true }, async(request)=>{
  const actor=requireRole(request,"teacher","admin"); const studentId=text(request.data.studentId,"studentId",10,128); const classId=text(request.data.classroomId,"classroomId",5,128); const classroom=await db.doc(`classrooms/${classId}`).get();
  if(!classroom.exists||!classroom.data().memberIds.includes(studentId))throw new HttpsError("failed-precondition","Student is not in this classroom."); if(actor.token.role==="teacher"&&!classroom.data().teacherIds.includes(actor.uid))throw new HttpsError("permission-denied","Not your classroom.");
  const level=Number(request.data.level);if(!Number.isInteger(level)||level<1||level>5)throw new HttpsError("invalid-argument","Level must be 1–5.");
  const ref=db.collection("progress").doc();await ref.set({studentId,classroomId:classId,teacherId:actor.uid,subject:text(request.data.subject,"subject",1,80),criterion:text(request.data.criterion,"criterion",1,120),level,note:text(request.data.note||" ","note",1,2000),createdAt:FieldValue.serverTimestamp()});
  await audit(actor.uid,"progress.record",ref.id,{classId,studentId});return{id:ref.id};
});

function studentSubmissionHandler(action) {
  return async request => {
    const actor = requireRole(request, "student");
    const assignmentId = text(request.data.assignmentId, "assignmentId", 20, 128);
    const id = submissionId(assignmentId, actor.uid);
    const ref = db.doc(`submissions/${id}`);
    const note = action === "unsubmit" ? "" : optionalText(request.data.note, "note", 10000);
    const expectedRevision = request.data.expectedRevision;
    const requestId = request.data.requestId;
    const result = await db.runTransaction(async transaction => {
      const assignmentRef = db.doc(`assignments/${assignmentId}`);
      const profileRef = db.doc(`profiles/${actor.uid}`);
      const [assignment, profile, current] = await Promise.all([
        transaction.get(assignmentRef),
        transaction.get(profileRef),
        transaction.get(ref),
      ]);
      if (!assignment.exists) throw new HttpsError("not-found", "Assignment not found.");
      const classId = assignment.data().classroomId;
      const classroom = await transaction.get(db.doc(`classrooms/${classId}`));
      if (!profile.exists || profile.data().active !== true || !(profile.data().classroomIds || []).includes(classId)) {
        throw new HttpsError("permission-denied", "Not in this classroom.");
      }
      if (assignment.data().state !== "published") {
        throw new HttpsError("failed-precondition", "Assignment is not accepting work.");
      }
      const currentRevision = current.exists ? Number(current.data().revision || 1) : 0;
      let mutationKey;
      let mutation;
      try {
        mutationKey = submissionMutationKey(actor.uid, requestId);
        mutation = validateMutation(currentRevision, expectedRevision, current.exists ? current.data().lastMutationKey : null, mutationKey);
      } catch (error) {
        throw new HttpsError("aborted", error.message);
      }
      if (mutation === "retry") return { id, revision: currentRevision, retry: true };
      if (!canStudentAction(current.exists ? current.data().state : null, action)) {
        throw new HttpsError("failed-precondition", "Submission state does not allow this action.");
      }
      const targetState = action === "hand_in" ? "handed_in" : "draft";
      const attachmentPaths = action === "unsubmit"
        ? current.data().attachmentPaths || []
        : authorizedPaths(request.data.attachmentPaths || [], "attachmentPath", `classrooms/${classId}/submissions/${actor.uid}/${id}/`);
      const nextNote = action === "unsubmit" ? current.data().note || "" : note;
      if (action === "hand_in" && nextNote.length === 0 && attachmentPaths.length === 0) {
        throw new HttpsError("invalid-argument", "Add a written answer or attachment before handing in.");
      }
      if (current.exists) {
        transaction.set(db.collection("submissionRevisions").doc(), {
          submissionId: id,
          assignmentId,
          classroomId: classId,
          studentId: actor.uid,
          revision: currentRevision,
          snapshot: submissionSnapshot(current.data()),
          editedBy: actor.uid,
          editedAt: FieldValue.serverTimestamp(),
        });
      }
      const nextRevision = currentRevision + 1;
      transaction.set(ref, {
        assignmentId,
        classroomId: classId,
        studentId: actor.uid,
        note: nextNote,
        attachmentPaths,
        state: targetState,
        feedback: current.exists ? current.data().feedback || "" : "",
        handedInAt: targetState === "handed_in" ? FieldValue.serverTimestamp() : null,
        revision: nextRevision,
        lastMutationKey: mutationKey,
        ...(current.exists ? {} : { createdAt: FieldValue.serverTimestamp() }),
        updatedAt: FieldValue.serverTimestamp(),
      }, { merge: true });
      transaction.set(db.collection("audit").doc(), {
        actorId: actor.uid,
        action: `submission.${action}`,
        targetId: id,
        details: { assignmentId, classId, revision: nextRevision },
        at: FieldValue.serverTimestamp(),
      });
      if (action === "hand_in" && classroom.exists) {
        enqueueNotification(transaction, "submission_handed_in", classroom.data().teacherIds || [], "submissions", id);
      }
      return { id, revision: nextRevision, retry: false };
    });
    return result;
  };
}

exports.saveSubmissionDraft = onCall({ enforceAppCheck: true }, studentSubmissionHandler("save_draft"));
exports.handIn = onCall({ enforceAppCheck: true }, studentSubmissionHandler("hand_in"));
exports.unsubmit = onCall({ enforceAppCheck: true }, studentSubmissionHandler("unsubmit"));

exports.reviewSubmission = onCall({ enforceAppCheck: true }, async request => {
  const actor = requireRole(request, "teacher", "admin");
  const id = text(request.data.submissionId, "submissionId", 20, 128);
  const ref = db.doc(`submissions/${id}`);
  let destination;
  try {
    destination = submissionState(request.data.state || "returned");
  } catch (error) {
    throw new HttpsError("invalid-argument", error.message);
  }
  if (!new Set(["returned", "completed"]).has(destination)) {
    throw new HttpsError("invalid-argument", "Unsupported review state.");
  }
  const feedback = optionalText(request.data.feedback, "feedback", 5000);
  const gradePoints = optionalPoints(request.data.gradePoints, "gradePoints");
  if (destination === "returned" && feedback.length === 0) {
    throw new HttpsError("invalid-argument", "Private feedback is required when returning work.");
  }
  const result = await db.runTransaction(async transaction => {
    const current = await transaction.get(ref);
    if (!current.exists) throw new HttpsError("not-found", "Submission not found.");
    const classroom = await transaction.get(db.doc(`classrooms/${current.data().classroomId}`));
    ensureClassroomManager(actor, classroom);
    const assignment = await transaction.get(db.doc(`assignments/${current.data().assignmentId}`));
    if (!assignment.exists) throw new HttpsError("not-found", "Assignment not found.");
    const maxPoints = assignment.data().pointsPossible;
    if (classroom.data().gradingEnabled !== true && gradePoints !== null) throw new HttpsError("failed-precondition", "Grading is disabled for this classroom.");
    if (gradePoints !== null && (maxPoints === null || gradePoints > maxPoints)) throw new HttpsError("invalid-argument", "Grade exceeds the assignment points.");
    const currentRevision = Number(current.data().revision || 1);
    let mutationKey;
    let mutation;
    try {
      mutationKey = submissionMutationKey(actor.uid, request.data.requestId);
      mutation = validateMutation(currentRevision, request.data.expectedRevision, current.data().lastMutationKey, mutationKey);
    } catch (error) {
      throw new HttpsError("aborted", error.message);
    }
    if (mutation === "retry") return { id, revision: currentRevision, retry: true };
    if (!canTeacherReview(current.data().state, destination)) {
      throw new HttpsError("failed-precondition", "Submission cannot move to that review state.");
    }
    transaction.set(db.collection("submissionRevisions").doc(), {
      submissionId: id,
      assignmentId: current.data().assignmentId,
      classroomId: current.data().classroomId,
      studentId: current.data().studentId,
      revision: currentRevision,
      snapshot: submissionSnapshot(current.data()),
      editedBy: actor.uid,
      editedAt: FieldValue.serverTimestamp(),
    });
    const nextRevision = currentRevision + 1;
    transaction.update(ref, {
      state: destination,
      feedback,
      gradePoints,
      returnedAt: destination === "returned" ? FieldValue.serverTimestamp() : null,
      completedAt: destination === "completed" ? FieldValue.serverTimestamp() : null,
      revision: nextRevision,
      lastMutationKey: mutationKey,
      updatedAt: FieldValue.serverTimestamp(),
    });
    transaction.set(db.collection("audit").doc(), {
      actorId: actor.uid,
      action: `submission.${destination}`,
      targetId: id,
      details: { classId: current.data().classroomId, studentId: current.data().studentId, revision: nextRevision },
      at: FieldValue.serverTimestamp(),
    });
    enqueueNotification(transaction, destination === "returned" ? "submission_returned" : "submission_completed", [current.data().studentId], "classwork", current.data().assignmentId);
    return { id, revision: nextRevision, retry: false };
  });
  return result;
});

exports.returnSubmission = exports.reviewSubmission;

exports.createInvitation = onCall({ enforceAppCheck: true }, async (request) => {
  const actor = requireRecentRole(request, "admin");
  const displayName = text(request.data.displayName, "displayName", 2, 80);
  const email = text(request.data.email, "email", 5, 200).toLowerCase();
  const role = text(request.data.role, "role", 4, 10);
  if (!roles.has(role)) {
    throw new HttpsError("invalid-argument", "Unsupported role.");
  }
  const classroomIds = Array.isArray(request.data.classroomIds)
    ? [...new Set(request.data.classroomIds.map(value => text(value, "classroomId", 5, 128)))]
    : [];
  if (classroomIds.length > 20) throw new HttpsError("invalid-argument", "Choose no more than 20 classrooms.");
  const classroomSnapshots = await Promise.all(classroomIds.map(id => db.doc(`classrooms/${id}`).get()));
  if (classroomSnapshots.some(snapshot => !snapshot.exists || snapshot.data().archived === true)) {
    throw new HttpsError("failed-precondition", "Choose active classrooms only.");
  }
  const token = invitationToken();
  const id = invitationId(token);
  let expiresAt;
  try {
    expiresAt = expirationFromHours(request.data.expiresInHours ?? 24);
  } catch (error) {
    throw new HttpsError("invalid-argument", error.message);
  }
  const invitationRef = db.doc(`invitations/${id}`);
  const batch = db.batch();
  batch.create(invitationRef, {
    displayName,
    email,
    role,
    classroomIds,
    createdBy: actor.uid,
    createdAt: FieldValue.serverTimestamp(),
    expiresAt: Timestamp.fromDate(expiresAt),
    redeemedAt: null,
    redeemedBy: null,
    revokedAt: null,
  });
  batch.set(db.collection("audit").doc(), {
    actorId: actor.uid,
    action: "invitation.create",
    targetId: id,
    details: { role, classroomIds, expiresAt: expiresAt.toISOString() },
    at: FieldValue.serverTimestamp(),
  });
  await batch.commit();
  return { invitationId: id, code: token, expiresAt: expiresAt.toISOString() };
});

exports.revokeInvitation = onCall({ enforceAppCheck: true }, async (request) => {
  const actor = requireRecentRole(request, "admin");
  const id = text(request.data.invitationId, "invitationId", 64, 64);
  if (!/^[a-f0-9]{64}$/.test(id)) throw new HttpsError("invalid-argument", "invitationId is invalid.");
  const ref = db.doc(`invitations/${id}`);
  await db.runTransaction(async transaction => {
    const snapshot = await transaction.get(ref);
    if (!snapshot.exists) throw new HttpsError("not-found", "Invitation not found.");
    if (snapshot.data().redeemedAt) throw new HttpsError("failed-precondition", "Invitation was already redeemed.");
    if (snapshot.data().revokedAt) throw new HttpsError("failed-precondition", "Invitation was already revoked.");
    transaction.update(ref, { revokedAt: FieldValue.serverTimestamp(), revokedBy: actor.uid });
    transaction.set(db.collection("audit").doc(), {
      actorId: actor.uid,
      action: "invitation.revoke",
      targetId: id,
      details: {},
      at: FieldValue.serverTimestamp(),
    });
  });
  return { ok: true };
});

exports.redeemInvitation = onCall({ enforceAppCheck: true }, async (request) => {
  const code = text(request.data.code, "code", 40, 100);
  const password = secret(request.data.password, "password");
  const id = invitationId(code);
  const invitationRef = db.doc(`invitations/${id}`);
  const initial = await invitationRef.get();
  if (!initial.exists || !isInvitationUsable(initial.data())) {
    throw new HttpsError("permission-denied", "Invitation is invalid or expired.");
  }
  const invitation = initial.data();
  let user;
  try {
    user = await getAuth().createUser({
      email: invitation.email,
      password,
      displayName: invitation.displayName,
      disabled: false,
    });
    await getAuth().setCustomUserClaims(user.uid, { role: invitation.role });
    await db.runTransaction(async transaction => {
      const current = await transaction.get(invitationRef);
      if (!current.exists || !isInvitationUsable(current.data())) {
        throw new HttpsError("aborted", "Invitation was already used or revoked.");
      }
      const classroomIds = current.data().classroomIds || [];
      const classroomRefs = classroomIds.map(classroomId => db.doc(`classrooms/${classroomId}`));
      const classrooms = await Promise.all(classroomRefs.map(ref => transaction.get(ref)));
      if (classrooms.some(snapshot => !snapshot.exists || snapshot.data().archived === true)) {
        throw new HttpsError("failed-precondition", "An invited classroom is unavailable.");
      }
      transaction.set(db.doc(`profiles/${user.uid}`), {
        displayName: current.data().displayName,
        role: current.data().role,
        active: true,
        classroomIds,
        createdAt: FieldValue.serverTimestamp(),
      });
      transaction.set(db.doc(`privateAccounts/${user.uid}`), {
        email: current.data().email,
        mustChangePassword: false,
        invitationId: id,
        createdAt: FieldValue.serverTimestamp(),
      });
      classroomRefs.forEach(ref => transaction.update(ref, {
        memberIds: FieldValue.arrayUnion(user.uid),
        ...(current.data().role === "teacher" ? { teacherIds: FieldValue.arrayUnion(user.uid) } : {}),
      }));
      transaction.update(invitationRef, {
        redeemedAt: FieldValue.serverTimestamp(),
        redeemedBy: user.uid,
      });
      transaction.set(db.collection("audit").doc(), {
        actorId: user.uid,
        action: "invitation.redeem",
        targetId: id,
        details: { role: current.data().role, classroomIds },
        at: FieldValue.serverTimestamp(),
      });
    });
    return { uid: user.uid };
  } catch (error) {
    if (user) await getAuth().deleteUser(user.uid).catch(() => undefined);
    if (error instanceof HttpsError) throw error;
    throw new HttpsError("internal", "Account activation failed.");
  }
});

exports.redeemGoogleInvitation = onCall({ enforceAppCheck: true }, async request => {
  const actor = requireAuth(request);
  const code = text(request.data.code, "code", 40, 100);
  const id = invitationId(code);
  const invitationRef = db.doc(`invitations/${id}`);
  const initial = await invitationRef.get();
  if (!initial.exists || !isInvitationUsable(initial.data())) {
    throw new HttpsError("permission-denied", "Invitation is invalid or expired.");
  }
  if (!invitationMatchesVerifiedEmail(initial.data(), actor.token)) {
    throw new HttpsError("permission-denied", "Use the verified Google email address that was invited.");
  }
  if ((await db.doc(`profiles/${actor.uid}`).get()).exists) {
    throw new HttpsError("already-exists", "This Google account is already activated.");
  }
  await getAuth().setCustomUserClaims(actor.uid, { role: initial.data().role });
  try {
    await db.runTransaction(async transaction => {
      const current = await transaction.get(invitationRef);
      if (!current.exists || !isInvitationUsable(current.data()) || !invitationMatchesVerifiedEmail(current.data(), actor.token)) {
        throw new HttpsError("aborted", "Invitation was already used, revoked, or changed.");
      }
      const classroomIds = current.data().classroomIds || [];
      const classroomRefs = classroomIds.map(classroomId => db.doc(`classrooms/${classroomId}`));
      const classrooms = await Promise.all(classroomRefs.map(ref => transaction.get(ref)));
      if (classrooms.some(snapshot => !snapshot.exists || snapshot.data().archived === true)) {
        throw new HttpsError("failed-precondition", "An invited classroom is unavailable.");
      }
      transaction.create(db.doc(`profiles/${actor.uid}`), {
        displayName: current.data().displayName,
        role: current.data().role,
        active: true,
        classroomIds,
        createdAt: FieldValue.serverTimestamp(),
      });
      transaction.create(db.doc(`privateAccounts/${actor.uid}`), {
        email: current.data().email,
        provider: "google.com",
        invitationId: id,
        createdAt: FieldValue.serverTimestamp(),
      });
      classroomRefs.forEach(ref => transaction.update(ref, {
        memberIds: FieldValue.arrayUnion(actor.uid),
        ...(current.data().role === "teacher" ? { teacherIds: FieldValue.arrayUnion(actor.uid) } : {}),
      }));
      transaction.update(invitationRef, { redeemedAt: FieldValue.serverTimestamp(), redeemedBy: actor.uid });
      transaction.set(db.collection("audit").doc(), {
        actorId: actor.uid,
        action: "invitation.google.redeem",
        targetId: id,
        details: { role: current.data().role, classroomIds },
        at: FieldValue.serverTimestamp(),
      });
    });
  } catch (error) {
    await getAuth().setCustomUserClaims(actor.uid, {}).catch(() => undefined);
    throw error;
  }
  return { uid: actor.uid, role: initial.data().role };
});
