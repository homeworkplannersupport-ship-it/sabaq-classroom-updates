const crypto = require("node:crypto");

const assignmentStates = new Set(["draft", "scheduled", "published", "closed", "archived"]);
const editableStates = new Set(["draft", "scheduled", "published"]);
const transitions = new Map([
  ["draft", new Set(["scheduled", "published", "archived"])],
  ["scheduled", new Set(["draft", "published", "archived"])],
  ["published", new Set(["closed", "archived"])],
  ["closed", new Set(["published", "archived"])],
  ["archived", new Set(["draft"])],
]);

function assignmentState(value, creation = false) {
  const state = String(value || "published").toLowerCase();
  if (!assignmentStates.has(state) || (creation && !editableStates.has(state))) {
    throw new Error("Unsupported assignment state.");
  }
  return state;
}

function canEditAssignment(state) {
  return editableStates.has(assignmentState(state));
}

function canTransitionAssignment(from, to) {
  const source = assignmentState(from);
  const destination = assignmentState(to);
  return transitions.get(source)?.has(destination) === true;
}

function validDate(value, name) {
  const date = value instanceof Date ? value : new Date(value);
  if (!Number.isFinite(date.getTime())) throw new Error(`${name} is invalid.`);
  return date;
}

function publicationTime(state, requestedPublishAt, dueAt, nowMillis = Date.now()) {
  const normalizedState = assignmentState(state, true);
  const due = validDate(dueAt, "dueAt");
  if (due.getTime() <= nowMillis) throw new Error("Due time must be in the future.");
  if (normalizedState === "draft") return null;
  if (normalizedState === "published") return new Date(nowMillis);
  const publishAt = validDate(requestedPublishAt, "publishAt");
  if (publishAt.getTime() <= nowMillis || publishAt.getTime() >= due.getTime()) {
    throw new Error("Scheduled publication must be after now and before the due time.");
  }
  return publishAt;
}

function idempotentAssignmentId(actorId, requestId) {
  if (typeof requestId !== "string" || !/^[A-Za-z0-9_-]{8,128}$/.test(requestId)) {
    throw new Error("requestId is invalid.");
  }
  return crypto.createHash("sha256").update(`assignment:${actorId}:${requestId}`).digest("hex");
}

function assignmentSnapshot(data) {
  return {
    title: data.title,
    instructions: data.instructions,
    subject: data.subject,
    dueAt: data.dueAt,
    estimateMinutes: data.estimateMinutes,
    priority: data.priority,
    type: data.type,
    steps: data.steps || [],
    attachmentPaths: data.attachmentPaths || [],
    state: data.state,
    publishAt: data.publishAt || null,
  };
}

module.exports = {
  assignmentSnapshot,
  assignmentState,
  canEditAssignment,
  canTransitionAssignment,
  idempotentAssignmentId,
  publicationTime,
  validDate,
};
