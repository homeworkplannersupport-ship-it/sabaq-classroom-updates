const test = require("node:test");
const assert = require("node:assert/strict");
const {
  assignmentSnapshot,
  assignmentState,
  canEditAssignment,
  canTransitionAssignment,
  idempotentAssignmentId,
  publicationTime,
} = require("../assignment-policy");

test("server lifecycle matches the Android transition policy", () => {
  assert.equal(canTransitionAssignment("draft", "scheduled"), true);
  assert.equal(canTransitionAssignment("scheduled", "published"), true);
  assert.equal(canTransitionAssignment("published", "closed"), true);
  assert.equal(canTransitionAssignment("closed", "published"), true);
  assert.equal(canTransitionAssignment("archived", "draft"), true);
  assert.equal(canTransitionAssignment("published", "draft"), false);
  assert.equal(canTransitionAssignment("archived", "published"), false);
  assert.equal(canEditAssignment("published"), true);
  assert.equal(canEditAssignment("closed"), false);
});

test("only draft, scheduled, and published assignments can be created", () => {
  assert.equal(assignmentState("DRAFT", true), "draft");
  assert.throws(() => assignmentState("closed", true));
  assert.throws(() => assignmentState("unknown"));
});

test("scheduled publication stays between now and due time", () => {
  const now = 1_700_000_000_000;
  const due = new Date(now + 3_600_000);
  assert.equal(publicationTime("draft", null, due, now), null);
  assert.equal(publicationTime("published", null, due, now).getTime(), now);
  assert.equal(publicationTime("scheduled", new Date(now + 60_000), due, now).getTime(), now + 60_000);
  assert.throws(() => publicationTime("scheduled", new Date(now - 1), due, now));
  assert.throws(() => publicationTime("scheduled", due, due, now));
});

test("idempotency is stable per actor and request", () => {
  const first = idempotentAssignmentId("teacher-a", "request_1234");
  assert.equal(first, idempotentAssignmentId("teacher-a", "request_1234"));
  assert.notEqual(first, idempotentAssignmentId("teacher-b", "request_1234"));
  assert.match(first, /^[a-f0-9]{64}$/);
  assert.throws(() => idempotentAssignmentId("teacher-a", "short"));
});

test("revision snapshots contain controlled assignment fields only", () => {
  const snapshot = assignmentSnapshot({ title: "A", instructions: "B", subject: "Quran", dueAt: 1, estimateMinutes: 20, priority: "Standard", type: "Sabaq", steps: ["Read"], attachmentPaths: [], state: "draft", secret: "exclude" });
  assert.equal(snapshot.secret, undefined);
  assert.equal(snapshot.title, "A");
  assert.deepEqual(snapshot.steps, ["Read"]);
});
