const test = require("node:test");
const assert = require("node:assert/strict");
const {
  canStudentAction,
  canTeacherReview,
  submissionId,
  submissionMutationKey,
  submissionSnapshot,
  validateMutation,
} = require("../submission-policy");

test("student submission actions use explicit transitions", () => {
  assert.equal(canStudentAction(null, "save_draft"), true);
  assert.equal(canStudentAction("draft", "hand_in"), true);
  assert.equal(canStudentAction("returned", "hand_in"), true);
  assert.equal(canStudentAction("handed_in", "save_draft"), false);
  assert.equal(canStudentAction("handed_in", "unsubmit"), true);
  assert.equal(canStudentAction("completed", "unsubmit"), false);
});

test("teacher review supports return, completion, and reopening", () => {
  assert.equal(canTeacherReview("handed_in", "returned"), true);
  assert.equal(canTeacherReview("handed_in", "completed"), true);
  assert.equal(canTeacherReview("returned", "completed"), true);
  assert.equal(canTeacherReview("completed", "returned"), true);
  assert.equal(canTeacherReview("draft", "returned"), false);
});

test("submission identity is stable per assignment and learner", () => {
  const id = submissionId("assignment-a", "student-a");
  assert.equal(id, submissionId("assignment-a", "student-a"));
  assert.notEqual(id, submissionId("assignment-a", "student-b"));
  assert.match(id, /^[a-f0-9]{64}$/);
});

test("mutations reject stale revisions but accept exact retries", () => {
  const prior = submissionMutationKey("student-a", "prior_req_123");
  const next = submissionMutationKey("student-a", "next_req_1234");
  assert.equal(validateMutation(3, 3, prior, next), "apply");
  assert.equal(validateMutation(3, 0, prior, prior), "retry");
  assert.throws(() => validateMutation(3, 2, prior, next));
  assert.throws(() => submissionMutationKey("student-a", "short"));
});

test("submission snapshots exclude synchronization metadata", () => {
  const snapshot = submissionSnapshot({ note: "Answer", attachmentPaths: ["a"], state: "draft", feedback: "", revision: 9, lastMutationKey: "secret" });
  assert.equal(snapshot.revision, undefined);
  assert.equal(snapshot.lastMutationKey, undefined);
  assert.equal(snapshot.note, "Answer");
});
