const test = require("node:test");
const assert = require("node:assert/strict");
const {
  genericNotification,
  notificationDecision,
  normalizePreferences,
} = require("../notification-policy");

test("notification preferences validate time zones and bounds", () => {
  assert.equal(normalizePreferences({ timeZone: "America/Toronto" }).timeZone, "America/Toronto");
  assert.throws(() => normalizePreferences({ timeZone: "Not/AZone" }));
  assert.throws(() => normalizePreferences({ quietStartMinutes: 1440 }));
  assert.throws(() => normalizePreferences({ digestMode: "weekly" }));
});

test("overnight quiet hours defer until the configured local end", () => {
  const now = new Date("2026-08-21T02:30:00.000Z");
  const decision = notificationDecision({ timeZone: "UTC", quietStartMinutes: 21 * 60, quietEndMinutes: 7 * 60 }, "assignment_new", now);
  assert.equal(decision.action, "defer");
  assert.equal(decision.reason, "quiet_hours");
  assert.equal(decision.dueAt.toISOString(), "2026-08-21T07:00:00.000Z");
});

test("category opt-out drops events and daytime sends immediately", () => {
  const now = new Date("2026-08-21T15:00:00.000Z");
  assert.equal(notificationDecision({ timeZone: "UTC", assignmentUpdates: false }, "assignment_changed", now).action, "drop");
  assert.equal(notificationDecision({ timeZone: "UTC" }, "submission_returned", now).action, "send");
});

test("daily digest defers to the next local digest hour", () => {
  const now = new Date("2026-08-21T15:00:00.000Z");
  const decision = notificationDecision({ timeZone: "UTC", digestMode: "daily", digestHourLocal: 18 }, "announcement_new", now);
  assert.equal(decision.action, "defer");
  assert.equal(decision.dueAt.toISOString(), "2026-08-21T18:00:00.000Z");
});

test("payloads are generic and contain no classroom or learner content", () => {
  const payload = genericNotification("submission_returned");
  assert.deepEqual(payload, { title: "Work returned", body: "Open Sabaq Workspace to read private feedback." });
  assert.equal(JSON.stringify(payload).includes("student"), false);
});

test("comment notifications stay generic and respect announcement preferences", () => {
  const now = new Date("2026-08-21T15:00:00.000Z");
  const payload = genericNotification("comment_new");
  assert.deepEqual(payload, { title: "New classroom comment", body: "Open Sabaq Workspace to continue the discussion." });
  assert.equal(notificationDecision({ timeZone: "UTC", announcements: false }, "comment_new", now).action, "drop");
});
