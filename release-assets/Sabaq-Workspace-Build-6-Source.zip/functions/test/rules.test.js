const { before, beforeEach, after, test } = require("node:test");
const fs = require("node:fs");
const path = require("node:path");
const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { doc, getDoc, setDoc } = require("firebase/firestore");
const { getBytes, ref, uploadBytes } = require("firebase/storage");

let env;
const projectId = "demo-sabaq-classroom";

before(async () => {
  env = await initializeTestEnvironment({
    projectId,
    firestore: {
      rules: fs.readFileSync(path.join(__dirname, "..", "..", "firestore.rules"), "utf8"),
    },
    storage: {
      rules: fs.readFileSync(path.join(__dirname, "..", "..", "storage.rules"), "utf8"),
    },
  });
});

beforeEach(async () => {
  await env.clearFirestore();
  await env.clearStorage();
  await env.withSecurityRulesDisabled(async context => {
    const db = context.firestore();
    await setDoc(doc(db, "profiles/admin-a"), { displayName: "Admin A", role: "admin", active: true, classroomIds: [] });
    await setDoc(doc(db, "profiles/student-a"), { displayName: "Student A", role: "student", active: true, classroomIds: ["class-a"], guardianIds: ["guardian-a"] });
    await setDoc(doc(db, "profiles/student-b"), { displayName: "Student B", role: "student", active: true, classroomIds: ["class-b"], guardianIds: [] });
    await setDoc(doc(db, "profiles/student-peer"), { displayName: "Student Peer", role: "student", active: true, classroomIds: ["class-a"], guardianIds: [] });
    await setDoc(doc(db, "profiles/student-suspended"), { displayName: "Suspended", role: "student", active: false, classroomIds: ["class-a"], guardianIds: [] });
    await setDoc(doc(db, "profiles/teacher-a"), { displayName: "Teacher A", role: "teacher", active: true, classroomIds: ["class-a"] });
    await setDoc(doc(db, "profiles/guardian-a"), { displayName: "Guardian A", role: "guardian", active: true, classroomIds: ["class-a"], studentIds: ["student-a"] });
    await setDoc(doc(db, "classrooms/class-a"), { name: "A", teacherIds: ["teacher-a"], memberIds: ["teacher-a", "student-a", "student-peer"] });
    await setDoc(doc(db, "classrooms/class-b"), { name: "B", teacherIds: ["teacher-b"], memberIds: ["teacher-b", "student-b"] });
    await setDoc(doc(db, "submissions/work-a"), { classroomId: "class-a", assignmentId: "assignment-a", studentId: "student-a", state: "handed_in" });
    await setDoc(doc(db, "submissions/work-b"), { classroomId: "class-b", assignmentId: "assignment-b", studentId: "student-b", state: "handed_in" });
    await setDoc(doc(db, "submissionRevisions/submission-revision-a"), { classroomId: "class-a", assignmentId: "assignment-a", studentId: "student-a", revision: 1, snapshot: { note: "Prior answer" } });
    await setDoc(doc(db, "progress/progress-a"), { classroomId: "class-a", studentId: "student-a", level: 3 });
    await setDoc(doc(db, "assignments/draft-a"), { classroomId: "class-a", teacherId: "teacher-a", state: "draft", title: "Private draft" });
    await setDoc(doc(db, "assignments/published-a"), { classroomId: "class-a", teacherId: "teacher-a", state: "published", title: "Visible work" });
    await setDoc(doc(db, "assignmentRevisions/revision-a"), { assignmentId: "published-a", classroomId: "class-a", revision: 1, snapshot: { title: "Prior title" } });
    await setDoc(doc(db, "invitations/private-token-hash"), { email: "student@example.test", role: "student" });
    await setDoc(doc(db, "notificationPreferences/student-a"), { assignmentUpdates: true, timeZone: "UTC" });
    await setDoc(doc(db, "deviceTokens/token-hash"), { uid: "student-a", token: "secret-device-token" });
    await setDoc(doc(db, "notificationEvents/event-a"), { kind: "assignment_new", recipientIds: ["student-a"] });
    await setDoc(doc(db, "notificationDigests/digest-a"), { uid: "student-a", status: "pending" });
  });
});

after(async () => {
  await env.cleanup();
});

test("unauthenticated users cannot read classroom records", async () => {
  await assertFails(getDoc(doc(env.unauthenticatedContext().firestore(), "submissions/work-a")));
});

test("student can read own submission but not another classroom submission", async () => {
  const db = env.authenticatedContext("student-a", { role: "student" }).firestore();
  await assertSucceeds(getDoc(doc(db, "submissions/work-a")));
  await assertFails(getDoc(doc(db, "submissions/work-b")));
});

test("linked guardian can read ward submission and progress only", async () => {
  const db = env.authenticatedContext("guardian-a", { role: "guardian" }).firestore();
  await assertSucceeds(getDoc(doc(db, "submissions/work-a")));
  await assertSucceeds(getDoc(doc(db, "progress/progress-a")));
  await assertFails(getDoc(doc(db, "submissions/work-b")));
});

test("assigned teacher can read own classroom submission", async () => {
  const db = env.authenticatedContext("teacher-a", { role: "teacher" }).firestore();
  await assertSucceeds(getDoc(doc(db, "submissions/work-a")));
  await assertFails(getDoc(doc(db, "submissions/work-b")));
});

test("submission history follows the same private audience as current work", async () => {
  const owner = env.authenticatedContext("student-a", { role: "student" }).firestore();
  const peer = env.authenticatedContext("student-peer", { role: "student" }).firestore();
  const guardian = env.authenticatedContext("guardian-a", { role: "guardian" }).firestore();
  const teacher = env.authenticatedContext("teacher-a", { role: "teacher" }).firestore();
  await assertSucceeds(getDoc(doc(owner, "submissionRevisions/submission-revision-a")));
  await assertSucceeds(getDoc(doc(guardian, "submissionRevisions/submission-revision-a")));
  await assertSucceeds(getDoc(doc(teacher, "submissionRevisions/submission-revision-a")));
  await assertFails(getDoc(doc(peer, "submissionRevisions/submission-revision-a")));
  await assertFails(setDoc(doc(owner, "submissionRevisions/fake"), { classroomId: "class-a", studentId: "student-a" }));
});

test("clients cannot write audit or progress records", async () => {
  const db = env.authenticatedContext("teacher-a", { role: "teacher" }).firestore();
  await assertFails(setDoc(doc(db, "audit/fake"), { action: "fake" }));
  await assertFails(setDoc(doc(db, "progress/fake"), { classroomId: "class-a", studentId: "student-a", level: 5 }));
});

test("students cannot read teacher drafts but assigned teachers can", async () => {
  const student = env.authenticatedContext("student-a", { role: "student" }).firestore();
  const teacher = env.authenticatedContext("teacher-a", { role: "teacher" }).firestore();
  await assertFails(getDoc(doc(student, "assignments/draft-a")));
  await assertSucceeds(getDoc(doc(student, "assignments/published-a")));
  await assertSucceeds(getDoc(doc(teacher, "assignments/draft-a")));
});

test("assignment revision snapshots stay private to assigned staff", async () => {
  const student = env.authenticatedContext("student-a", { role: "student" }).firestore();
  const teacher = env.authenticatedContext("teacher-a", { role: "teacher" }).firestore();
  await assertFails(getDoc(doc(student, "assignmentRevisions/revision-a")));
  await assertSucceeds(getDoc(doc(teacher, "assignmentRevisions/revision-a")));
  await assertFails(setDoc(doc(teacher, "assignmentRevisions/fake"), { classroomId: "class-a" }));
});

test("clients cannot bypass callable lifecycle and roster writes", async () => {
  const teacher = env.authenticatedContext("teacher-a", { role: "teacher" }).firestore();
  const student = env.authenticatedContext("student-a", { role: "student" }).firestore();
  await assertFails(setDoc(doc(teacher, "assignments/fake"), { classroomId: "class-a", teacherId: "teacher-a", state: "published" }));
  await assertFails(setDoc(doc(teacher, "classrooms/class-a"), { memberIds: ["teacher-a"] }, { merge: true }));
  await assertFails(setDoc(doc(student, "submissions/fake"), { classroomId: "class-a", studentId: "student-a" }));
});

test("invitation records are opaque even to authenticated clients", async () => {
  const admin = env.authenticatedContext("admin-a", { role: "admin" }).firestore();
  await assertFails(getDoc(doc(admin, "invitations/private-token-hash")));
  await assertFails(setDoc(doc(admin, "invitations/fake"), { role: "admin" }));
});

test("users can read preferences but notification delivery records stay server-only", async () => {
  const owner = env.authenticatedContext("student-a", { role: "student" }).firestore();
  const peer = env.authenticatedContext("student-peer", { role: "student" }).firestore();
  const admin = env.authenticatedContext("admin-a", { role: "admin" }).firestore();
  await assertSucceeds(getDoc(doc(owner, "notificationPreferences/student-a")));
  await assertFails(getDoc(doc(peer, "notificationPreferences/student-a")));
  await assertFails(setDoc(doc(owner, "notificationPreferences/student-a"), { assignmentUpdates: false }));
  await assertFails(getDoc(doc(owner, "deviceTokens/token-hash")));
  await assertFails(getDoc(doc(admin, "deviceTokens/token-hash")));
  await assertFails(getDoc(doc(admin, "notificationEvents/event-a")));
  await assertFails(getDoc(doc(owner, "notificationDigests/digest-a")));
});

test("suspended accounts immediately lose classroom reads", async () => {
  const suspended = env.authenticatedContext("student-suspended", { role: "student" }).firestore();
  await assertFails(getDoc(doc(suspended, "assignments/published-a")));
  await assertFails(getDoc(doc(suspended, "classrooms/class-a")));
});

test("submission attachments stay private to learner, guardian, and assigned teacher", async () => {
  const ownerStorage = env.authenticatedContext("student-a", { role: "student" }).storage();
  const path = "classrooms/class-a/submissions/student-a/submission-a/answer.txt";
  await assertSucceeds(uploadBytes(ref(ownerStorage, path), new Uint8Array([1, 2, 3]), { contentType: "text/plain" }));
  await assertSucceeds(getBytes(ref(ownerStorage, path)));
  await assertSucceeds(getBytes(ref(env.authenticatedContext("guardian-a", { role: "guardian" }).storage(), path)));
  await assertSucceeds(getBytes(ref(env.authenticatedContext("teacher-a", { role: "teacher" }).storage(), path)));
  await assertFails(getBytes(ref(env.authenticatedContext("student-peer", { role: "student" }).storage(), path)));
  await assertFails(getBytes(ref(env.authenticatedContext("student-suspended", { role: "student" }).storage(), path)));
});

test("only assigned staff upload assignment resources and MIME allowlist is enforced", async () => {
  const path = "classrooms/class-a/assignments/assignment-a/page.pdf";
  const teacherStorage = env.authenticatedContext("teacher-a", { role: "teacher" }).storage();
  const studentStorage = env.authenticatedContext("student-a", { role: "student" }).storage();
  await assertSucceeds(uploadBytes(ref(teacherStorage, path), new Uint8Array([1]), { contentType: "application/pdf" }));
  await assertSucceeds(getBytes(ref(studentStorage, path)));
  await assertFails(uploadBytes(ref(studentStorage, "classrooms/class-a/assignments/fake/page.pdf"), new Uint8Array([1]), { contentType: "application/pdf" }));
  await assertFails(uploadBytes(ref(teacherStorage, "classrooms/class-a/assignments/fake/script.html"), new Uint8Array([1]), { contentType: "text/html" }));
});

test("announcement attachments are staff-written and classroom-readable", async () => {
  const path = "classrooms/class-a/announcements/announcement-a/page.png";
  const teacherStorage = env.authenticatedContext("teacher-a", { role: "teacher" }).storage();
  const studentStorage = env.authenticatedContext("student-a", { role: "student" }).storage();
  await assertSucceeds(uploadBytes(ref(teacherStorage, path), new Uint8Array([1]), { contentType: "image/png" }));
  await assertSucceeds(getBytes(ref(studentStorage, path)));
  await assertFails(uploadBytes(ref(studentStorage, "classrooms/class-a/announcements/fake/page.png"), new Uint8Array([1]), { contentType: "image/png" }));
});
