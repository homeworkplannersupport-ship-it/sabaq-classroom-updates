const test = require("node:test");
const assert = require("node:assert/strict");
const {
  expirationFromHours,
  hasRecentAuthentication,
  invitationId,
  invitationMatchesVerifiedEmail,
  invitationToken,
  isInvitationUsable,
  isLastAssignedTeacher,
  transferMembership,
} = require("../security");

test("invitation tokens are high entropy and stored only by hash", () => {
  const first = invitationToken();
  const second = invitationToken();
  assert.notEqual(first, second);
  assert.ok(first.length >= 43);
  assert.match(invitationId(first), /^[a-f0-9]{64}$/);
  assert.notEqual(invitationId(first), invitationId(second));
});

test("invitation expiration is bounded to seven days", () => {
  const now = 1_700_000_000_000;
  assert.equal(expirationFromHours(24, now).getTime(), now + 86_400_000);
  assert.throws(() => expirationFromHours(0, now));
  assert.throws(() => expirationFromHours(169, now));
});

test("invitation must be current, unredeemed, and unrevoked", () => {
  const now = 1_700_000_000_000;
  assert.equal(isInvitationUsable({ expiresAt: new Date(now + 60_000) }, now), true);
  assert.equal(isInvitationUsable({ expiresAt: new Date(now - 1) }, now), false);
  assert.equal(isInvitationUsable({ expiresAt: new Date(now + 60_000), redeemedAt: new Date(now) }, now), false);
  assert.equal(isInvitationUsable({ expiresAt: new Date(now + 60_000), revokedAt: new Date(now) }, now), false);
  assert.equal(isInvitationUsable({ expiresAt: new Date(now + 8 * 24 * 60 * 60 * 1000) }, now), false);
});

test("Google activation requires the exact verified invited email", () => {
  const invitation = { email: "Teacher@Example.com" };
  assert.equal(invitationMatchesVerifiedEmail(invitation, { email: "teacher@example.com", email_verified: true }), true);
  assert.equal(invitationMatchesVerifiedEmail(invitation, { email: "other@example.com", email_verified: true }), false);
  assert.equal(invitationMatchesVerifiedEmail(invitation, { email: "teacher@example.com", email_verified: false }), false);
});

test("sensitive actions require authentication within five minutes", () => {
  const now = 2_000_000_000;
  assert.equal(hasRecentAuthentication({ auth_time: now - 299 }, now), true);
  assert.equal(hasRecentAuthentication({ auth_time: now - 301 }, now), false);
  assert.equal(hasRecentAuthentication({}, now), false);
  assert.equal(hasRecentAuthentication({ auth_time: now + 60 }, now), false);
});

test("classroom transfer preserves unrelated and historical memberships", () => {
  assert.deepEqual(transferMembership(["class-a", "class-extra"], ["class-old"], "class-a", "class-b"), {
    classroomIds: ["class-extra", "class-b"],
    historicalClassroomIds: ["class-old", "class-a"],
  });
  assert.throws(() => transferMembership(["class-a"], [], "class-missing", "class-b"));
  assert.throws(() => transferMembership(["class-a"], [], "class-a", "class-a"));
});

test("last assigned teacher cannot be removed", () => {
  assert.equal(isLastAssignedTeacher(["teacher-a"], "teacher-a"), true);
  assert.equal(isLastAssignedTeacher(["teacher-a", "teacher-b"], "teacher-a"), false);
  assert.equal(isLastAssignedTeacher(["teacher-b"], "teacher-a"), false);
});
