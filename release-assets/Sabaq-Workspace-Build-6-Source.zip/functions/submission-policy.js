const crypto = require("node:crypto");

const submissionStates = new Set(["draft", "handed_in", "returned", "completed"]);

function submissionState(value) {
  const state = String(value || "").toLowerCase();
  if (!submissionStates.has(state)) throw new Error("Unsupported submission state.");
  return state;
}

function canStudentAction(currentState, action) {
  const current = currentState ? submissionState(currentState) : null;
  if (action === "save_draft") return current === null || current === "draft" || current === "returned";
  if (action === "hand_in") return current === null || current === "draft" || current === "returned";
  if (action === "unsubmit") return current === "handed_in";
  return false;
}

function canTeacherReview(currentState, destination) {
  const current = submissionState(currentState);
  const target = submissionState(destination);
  if (target === "returned") return current === "handed_in" || current === "completed";
  if (target === "completed") return current === "handed_in" || current === "returned";
  return false;
}

function submissionId(assignmentId, studentId) {
  return crypto.createHash("sha256").update(`submission:${assignmentId}:${studentId}`).digest("hex");
}

function submissionMutationKey(actorId, requestId) {
  if (typeof requestId !== "string" || !/^[A-Za-z0-9_-]{8,128}$/.test(requestId)) {
    throw new Error("requestId is invalid.");
  }
  return crypto.createHash("sha256").update(`submission-mutation:${actorId}:${requestId}`).digest("hex");
}

function validateMutation(currentRevision, expectedRevision, currentMutationKey, mutationKey) {
  if (currentMutationKey === mutationKey) return "retry";
  const expected = Number(expectedRevision);
  if (!Number.isInteger(expected) || expected < 0 || expected !== currentRevision) {
    throw new Error("Submission changed on another device.");
  }
  return "apply";
}

function submissionSnapshot(data) {
  return {
    note: data.note || "",
    attachmentPaths: data.attachmentPaths || [],
    state: data.state,
    feedback: data.feedback || "",
    handedInAt: data.handedInAt || null,
  };
}

module.exports = {
  canStudentAction,
  canTeacherReview,
  submissionId,
  submissionMutationKey,
  submissionSnapshot,
  submissionState,
  validateMutation,
};
