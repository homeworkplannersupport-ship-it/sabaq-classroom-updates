const notificationKinds = new Set([
  "assignment_new",
  "assignment_changed",
  "submission_handed_in",
  "submission_returned",
  "submission_completed",
  "announcement_new",
  "comment_new",
]);

const defaults = Object.freeze({
  assignmentUpdates: true,
  submissionUpdates: true,
  announcements: true,
  quietStartMinutes: 21 * 60,
  quietEndMinutes: 7 * 60,
  timeZone: "UTC",
  digestMode: "immediate",
  digestHourLocal: 18,
});

function notificationKind(value) {
  const kind = String(value || "");
  if (!notificationKinds.has(kind)) throw new Error("Unsupported notification kind.");
  return kind;
}

function validTimeZone(value) {
  const timeZone = String(value || "UTC");
  try {
    new Intl.DateTimeFormat("en", { timeZone }).format(new Date());
    return timeZone;
  } catch {
    throw new Error("timeZone is invalid.");
  }
}

function normalizePreferences(value = {}) {
  const integer = (candidate, fallback, min, max, name) => {
    const parsed = candidate === undefined ? fallback : Number(candidate);
    if (!Number.isInteger(parsed) || parsed < min || parsed > max) throw new Error(`${name} is invalid.`);
    return parsed;
  };
  const digestMode = value.digestMode || defaults.digestMode;
  if (!new Set(["immediate", "daily"]).has(digestMode)) throw new Error("digestMode is invalid.");
  return {
    assignmentUpdates: value.assignmentUpdates === undefined ? defaults.assignmentUpdates : value.assignmentUpdates === true,
    submissionUpdates: value.submissionUpdates === undefined ? defaults.submissionUpdates : value.submissionUpdates === true,
    announcements: value.announcements === undefined ? defaults.announcements : value.announcements === true,
    quietStartMinutes: integer(value.quietStartMinutes, defaults.quietStartMinutes, 0, 1439, "quietStartMinutes"),
    quietEndMinutes: integer(value.quietEndMinutes, defaults.quietEndMinutes, 0, 1439, "quietEndMinutes"),
    timeZone: validTimeZone(value.timeZone || defaults.timeZone),
    digestMode,
    digestHourLocal: integer(value.digestHourLocal, defaults.digestHourLocal, 0, 23, "digestHourLocal"),
  };
}

function localClock(date, timeZone) {
  const parts = Object.fromEntries(new Intl.DateTimeFormat("en-CA", {
    timeZone,
    hour12: false,
    hour: "2-digit",
    minute: "2-digit",
  }).formatToParts(date).filter(part => part.type !== "literal").map(part => [part.type, Number(part.value)]));
  return { hour: parts.hour % 24, minute: parts.minute };
}

function isQuietMinute(minute, start, end) {
  if (start === end) return false;
  return start < end ? minute >= start && minute < end : minute >= start || minute < end;
}

function categoryEnabled(preferences, kind) {
  if (kind.startsWith("assignment_")) return preferences.assignmentUpdates;
  if (kind.startsWith("submission_")) return preferences.submissionUpdates;
  return preferences.announcements;
}

function findNextMinute(start, predicate, maxMinutes = 48 * 60) {
  for (let offset = 1; offset <= maxMinutes; offset += 1) {
    const candidate = new Date(start.getTime() + offset * 60_000);
    if (predicate(candidate)) return candidate;
  }
  throw new Error("Unable to calculate notification delivery time.");
}

function notificationDecision(rawPreferences, rawKind, now = new Date()) {
  const preferences = normalizePreferences(rawPreferences);
  const kind = notificationKind(rawKind);
  if (!categoryEnabled(preferences, kind)) return { action: "drop", reason: "disabled" };
  const local = localClock(now, preferences.timeZone);
  const minute = local.hour * 60 + local.minute;
  if (preferences.digestMode === "daily") {
    const dueAt = findNextMinute(now, candidate => {
      const clock = localClock(candidate, preferences.timeZone);
      return clock.hour === preferences.digestHourLocal && clock.minute === 0;
    });
    return { action: "defer", reason: "daily_digest", dueAt };
  }
  if (isQuietMinute(minute, preferences.quietStartMinutes, preferences.quietEndMinutes)) {
    const dueAt = findNextMinute(now, candidate => {
      const clock = localClock(candidate, preferences.timeZone);
      return !isQuietMinute(clock.hour * 60 + clock.minute, preferences.quietStartMinutes, preferences.quietEndMinutes);
    });
    return { action: "defer", reason: "quiet_hours", dueAt };
  }
  return { action: "send", reason: "immediate" };
}

function genericNotification(kind) {
  const normalized = notificationKind(kind);
  const messages = {
    assignment_new: ["New classroom work", "Open Sabaq Workspace to view the update."],
    assignment_changed: ["Classroom work updated", "Open Sabaq Workspace to review the change."],
    submission_handed_in: ["New hand-in", "Open Sabaq Workspace to review it."],
    submission_returned: ["Work returned", "Open Sabaq Workspace to read private feedback."],
    submission_completed: ["Work reviewed", "Open Sabaq Workspace to view its status."],
    announcement_new: ["New classroom announcement", "Open Sabaq Workspace to read it."],
    comment_new: ["New classroom comment", "Open Sabaq Workspace to continue the discussion."],
  };
  return { title: messages[normalized][0], body: messages[normalized][1] };
}

module.exports = {
  genericNotification,
  notificationDecision,
  notificationKind,
  normalizePreferences,
};
