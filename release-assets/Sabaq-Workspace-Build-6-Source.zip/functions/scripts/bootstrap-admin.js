const { applicationDefault, initializeApp } = require("firebase-admin/app");
const { getAuth } = require("firebase-admin/auth");
const { FieldValue, getFirestore } = require("firebase-admin/firestore");

function argument(name) {
  const index = process.argv.indexOf(`--${name}`);
  return index >= 0 ? process.argv[index + 1] : undefined;
}

async function main() {
  const projectId = argument("project");
  const email = String(argument("email") || "").trim().toLowerCase();
  if (!projectId || !email) throw new Error("Usage: npm run bootstrap-admin -- --project PROJECT_ID --email VERIFIED_GOOGLE_EMAIL");
  initializeApp({ credential: applicationDefault(), projectId });
  const auth = getAuth();
  const db = getFirestore();
  const existing = await db.collection("profiles").where("role", "==", "admin").limit(1).get();
  if (!existing.empty) throw new Error("An administrator already exists. The one-time bootstrap is permanently closed.");
  const user = await auth.getUserByEmail(email);
  if (!user.emailVerified) throw new Error("The Google email must be verified before bootstrap.");
  const batch = db.batch();
  batch.create(db.doc(`profiles/${user.uid}`), {
    displayName: user.displayName || "Sabaq administrator",
    role: "admin",
    active: true,
    classroomIds: [],
    createdAt: FieldValue.serverTimestamp(),
  });
  batch.create(db.doc(`privateAccounts/${user.uid}`), {
    email,
    provider: "google.com",
    bootstrap: true,
    createdAt: FieldValue.serverTimestamp(),
  });
  batch.create(db.collection("audit").doc(), {
    actorId: user.uid,
    action: "account.bootstrap.admin",
    targetId: user.uid,
    details: {},
    at: FieldValue.serverTimestamp(),
  });
  await auth.setCustomUserClaims(user.uid, { ...(user.customClaims || {}), role: "admin" });
  try {
    await batch.commit();
  } catch (error) {
    await auth.setCustomUserClaims(user.uid, user.customClaims || {}).catch(() => undefined);
    throw error;
  }
  await auth.revokeRefreshTokens(user.uid);
  console.log(`Bootstrapped one administrator for ${email}. Do not run this script again.`);
}

main().catch(error => {
  console.error(error.message || error);
  process.exitCode = 1;
});
