const crypto = require("node:crypto");

const MAX_INVITATION_AGE_MS = 7 * 24 * 60 * 60 * 1000;
const RECENT_AUTH_SECONDS = 5 * 60;

function invitationToken() {
  return crypto.randomBytes(32).toString("base64url");
}

function invitationId(token) {
  return crypto.createHash("sha256").update(token, "utf8").digest("hex");
}

function expirationFromHours(hours, nowMillis = Date.now()) {
  const parsed = Number(hours);
  if (!Number.isFinite(parsed) || parsed < 1 || parsed > 168) {
    throw new Error("Expiration must be between 1 and 168 hours.");
  }
  return new Date(nowMillis + Math.round(parsed * 60 * 60 * 1000));
}

function isInvitationUsable(invitation, nowMillis = Date.now()) {
  if (!invitation || invitation.revokedAt || invitation.redeemedAt) return false;
  const expiresAt = invitation.expiresAt instanceof Date
    ? invitation.expiresAt.getTime()
    : invitation.expiresAt?.toMillis?.();
  return Number.isFinite(expiresAt)
    && expiresAt > nowMillis
    && expiresAt - nowMillis <= MAX_INVITATION_AGE_MS;
}

function invitationMatchesVerifiedEmail(invitation, token) {
  const invited = String(invitation?.email || "").trim().toLowerCase();
  const signedIn = String(token?.email || "").trim().toLowerCase();
  return invited.length > 0 && token?.email_verified === true && invited === signedIn;
}

function hasRecentAuthentication(token, nowSeconds = Math.floor(Date.now() / 1000)) {
  const authTime = Number(token?.auth_time);
  return Number.isFinite(authTime)
    && authTime <= nowSeconds + 30
    && nowSeconds - authTime <= RECENT_AUTH_SECONDS;
}

function transferMembership(classroomIds, historicalClassroomIds, fromClassroomId, toClassroomId) {
  if (fromClassroomId === toClassroomId || !classroomIds.includes(fromClassroomId)) {
    throw new Error("Invalid classroom transfer.");
  }
  return {
    classroomIds: [...new Set(classroomIds.filter(id => id !== fromClassroomId).concat(toClassroomId))],
    historicalClassroomIds: [...new Set((historicalClassroomIds || []).concat(fromClassroomId))],
  };
}

function isLastAssignedTeacher(teacherIds, uid) {
  return Array.isArray(teacherIds)
    && teacherIds.includes(uid)
    && teacherIds.filter(id => id !== uid).length === 0;
}

module.exports = {
  expirationFromHours,
  hasRecentAuthentication,
  invitationId,
  invitationToken,
  invitationMatchesVerifiedEmail,
  isInvitationUsable,
  isLastAssignedTeacher,
  transferMembership,
};
