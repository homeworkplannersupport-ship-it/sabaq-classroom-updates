# Sabaq Workspace — Build 6 Checklist

## Account and server foundation

- [x] Require a verified server account before the app can be used.
- [x] Remove the offline-administrator and local-login bypasses.
- [x] Add secure one-time activation for the approved workspace owner.
- [x] Keep account data and classroom membership synchronized across devices.
- [x] Route classroom and account-management writes through audited Firebase functions.

## Classroom workspace

- [x] Give every class dedicated Stream, Classwork, People, and Grades areas.
- [x] Add role-aware teacher, student, administrator, and guardian access.
- [x] Support server-backed assignments, announcements, submissions, feedback, rosters, progress, transfers, and classroom lifecycle controls.
- [x] Keep cached classroom content readable offline and prevent false success messages for unsynchronized writes.
- [x] Let authorized administrators choose administrator, teacher, student, or guardian when creating an invitation; never let a new user self-promote.
- [x] Protect administrator invitations with recent authentication, audit logging, and a clear high-privilege warning.
- [x] Let administrators create, edit, archive, restore, and fully manage classrooms.
- [x] Add multiple co-teachers per classroom with shared management rights for the stream, classwork, people, and grades.
- [x] Let classroom owners add or remove co-teachers without leaving a classroom without an owner.
- [x] Let teachers and administrators create, edit, schedule, reuse, close, and archive assignments.
- [x] Support multiple assignment images plus existing document attachments, with secure previews and uploads.
- [x] Add public class comments on assignments, private student–teacher comments, moderation controls, timestamps, and notifications.
- [x] Add an optional per-class grading system that can be toggled on or off by a classroom owner.
- [x] When grading is enabled, support points, ungraded work, private grades, returned work, class summaries, and student/guardian grade views.
- [x] Keep completion-only tracking when grading is disabled.
- [x] Put classroom announcements and newly published work on the main role-aware home stream, similar to a classroom activity feed.
- [x] Allow teachers to post, edit, schedule, pin, and remove announcements, with images or files when appropriate.
- [x] Add announcement and assignment comment controls so teachers can disable or lock discussion per post.

## Mishkaat visual overhaul

- [x] Revamp the complete app UI with a cohesive Mishkaat-inspired theme.
- [x] Apply the theme consistently to onboarding, dashboards, classroom workspaces, dialogs, navigation, settings, and empty/loading/error states.
- [x] Preserve Sabaq Workspace's own identity and accessibility instead of copying another app's branding.
- [x] Keep motion, haptics, sounds, spacing, and interaction response polished and fast.

## Update experience

- [x] Detect the first launch after an installed update.
- [x] Show a polished one-time “What’s new” popup after updating.
- [x] Display the installed version, build number, release title, and complete change log.
- [x] Do not show the popup again after that build has been acknowledged.
- [x] Keep the manual update-history viewer in Settings.

## Release gates

- [x] Backend policy tests pass.
- [x] Android unit tests and lint pass.
- [x] Permanently signed Build 6 APK created and certificate/version verified.
- [x] Firebase CLI authorization approved by the user.
- [x] Build 6 backend deployed.
- [ ] Final redesigned APK rebuilt, reverified, and published to GitHub.
- [ ] GitHub update feed changed only after the published APK is verified.
