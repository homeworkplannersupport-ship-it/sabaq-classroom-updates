# Sabaq Workspace — Build 3

Version: `0.3.0-alpha-build-3`

Package: `com.foxlabs.sabaqclassroom`

Planned tag: `build-3`

## What’s new

- Teachers can save assignments as drafts, schedule publication, publish immediately, close work, archive it, and restore archived work to draft.
- Scheduled work becomes visible when its publication time arrives; drafts, scheduled work, and archived work remain hidden from students and guardians.
- Teachers can edit eligible assignment details. Each edit or state change increments the revision and preserves a private prior snapshot.
- The teacher workspace shows assignment state, hand-in count, and revision number, with separate controls for editing, lifecycle changes, and submission review.
- Classroom archive/restore safeguards continue to preserve rosters, submissions, and work history.
- Build 3 uses the permanent signing identity established by Build 2 and can update directly over Build 2.

## Verification gates

- Unit tests, debug assembly, Compose test APK compilation, release lint, R8 shrinking, signed release assembly, certificate verification, and checksum verification must pass before publication.
- Real-device execution, Firebase deployment, safeguarding review, accessibility/RTL testing, independent security review, and a consenting closed pilot remain explicit gates.
