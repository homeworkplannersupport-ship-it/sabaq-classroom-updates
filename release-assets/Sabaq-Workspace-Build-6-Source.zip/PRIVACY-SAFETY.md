# Sabaq Workspace privacy and safeguarding draft

Status: engineering draft for review by the intended madrasah, guardians, and qualified privacy/security reviewers. It is not a substitute for local legal advice or safeguarding approval.

## Data boundaries

- Personal planner tasks, journal entries, focus history, and OCR text remain on the device unless the user explicitly exports a planner backup.
- Classroom accounts, rosters, assignments, submissions, private feedback, announcements, progress records, and attachments are intended to synchronize only after the dedicated secured backend is deployed.
- The app contains no advertising, behavioral analytics, location tracking, contact scraping, or sale of personal data.
- Passwords must never be logged, exported, displayed after creation, or stored as plaintext. The offline prototype uses salted PBKDF2; production accounts must use Firebase Authentication and server-enforced authorization.

## Roles and safeguarding

- Administrators manage accounts and guardian links. Teachers may access only assigned classrooms. Students may access their own submissions and feedback. Guardians receive read-only access only to explicitly linked students.
- Student public posting is disabled. Teacher feedback and student submissions are private.
- A madrasah must document its lawful basis or consent process, minimum ages, retention periods, staff access, offboarding, account deletion, incident escalation, and approved terminology before real student data is entered.
- Religious text, scanned pages, notifications, screenshots, deletion, and file handling require a respectful-use review by the intended community.

## Security and incident response

- Deny-by-default Firestore and Storage rules, server-issued role claims, size and MIME limits, audit events, TLS, and authorized attachment paths are required before multi-device use.
- Suspected exposure should trigger credential revocation, access-log preservation, affected-account identification, containment, notification under applicable policy and law, recovery, and a written post-incident review.
- Release artifacts must pass the repository release gate and retain the permanent signing certificate.

## User rights and lifecycle

Production administration must support access and export, correction, suspension, deletion, retention expiry, classroom transfer without silent history loss, and verified offboarding. Planner backup excludes accounts and classroom-controlled records by design.

## Pilot gate

Do not use real student data until the backend is deployed and adversarially tested, the policy is approved, guardian and learner consent requirements are satisfied, terminology is reviewed, an independent security review is complete, and a small consenting pilot has passed device and accessibility testing.
