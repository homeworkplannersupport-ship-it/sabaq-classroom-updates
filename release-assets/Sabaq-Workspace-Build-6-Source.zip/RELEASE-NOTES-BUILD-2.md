# Sabaq Workspace — Build 2

Version: `0.2.0-alpha-build-2`

Package: `com.foxlabs.sabaqclassroom`

Planned tag: `build-2`

## What’s new

- First-run administrator setup, role-specific accounts, secure local password hashing, sign-in, 12-hour session expiry, password change, suspension re-authentication, search, guardian links, and student transfers.
- Teacher-created classrooms and rosters with authorized editing, archive/restore, active-class safeguards, and history-preserving transfers; assignments with real due date/time, subject/type, estimate, priority, steps, and persistent photo/document/PDF attachments.
- Student Assigned, Started, Due soon, Missing, Handed in, Returned, and Completed sections; offline drafts, attachment preview, timestamped receipts, controlled unsubmit/resubmit, and private feedback.
- Classroom announcements and configurable progress records, plus a read-only linked-guardian family dashboard.
- Today, calendar handoff, personal tasks, planning coach, assignment-linked resilient focus timer/history, editable dated journal, on-device OCR/history, and planner-only backup/restore.
- Original navy/gold/ivory/sage identity, centralized haptics, original synthesized cues, silent/media safeguards, local reminder channels, notification deep links, test notification, and automatic update indication.
- Permanent release signing, R8 shrinking, checksum/certificate release gate, secret-free source packaging, privacy/safeguarding draft, threat model, Firebase rules/functions scaffold, and passing adversarial Firestore emulator tests.

## Known release gates

- Production Firebase project creation and deployment require explicit confirmation; the Android client remains offline/local until then.
- The published Build 1 alpha used a debug certificate. Permanent-key Build 2 requires a one-time uninstall/reinstall unless a separately approved legacy bridge is chosen.
- Real-device Android 8–current, Samsung, accessibility, RTL/large-text, and in-place-update tests require devices or configured emulators.
- Terminology, Hijri calendar choice, safeguarding/consent policy, respectful religious-text handling, independent security review, and a consenting closed pilot require the intended madrasah and qualified human reviewers.
