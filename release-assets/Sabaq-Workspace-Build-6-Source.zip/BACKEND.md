# Sabaq Workspace backend

The production design uses Firebase Authentication, Cloud Firestore, Cloud Storage, Cloud Functions (2nd gen), and Firebase Cloud Messaging. The Android client must not be connected to real student data until the emulator rule tests pass and a project-specific privacy/consent review is complete.

Administrative account creation is performed by callable Cloud Functions using the Admin SDK. The Android client never receives server credentials and cannot assign its own role. Roles are stored as custom authentication claims and duplicated in read-only profile documents for queries. Sensitive administrator calls require an authentication time no more than five minutes old.

Firestore and Storage default to deny. Private account data is separated from display profiles because Firestore reads operate at the document level rather than field level. All roster, assignment, submission, announcement, invitation, progress, and audit writes go through callable functions; clients cannot bypass validation with direct Firestore writes. Students and guardians can read only published or closed assignments.

Invitations use a random 256-bit bearer code. Firestore stores only its SHA-256 identifier, never the original code. An administrator with a recent sign-in can issue or revoke an invitation, invitations expire within seven days, App Check is required at the callable boundary, and redemption is transactionally one-time. If activation loses a race or fails, the newly created Authentication user is removed.

Account lifecycle calls also require a recent administrator sign-in. Suspension updates Authentication and the active profile flag, revokes refresh tokens, and writes an audit entry; rules consult the active flag so an already-issued token loses classroom access immediately. Role changes are limited to unlinked non-administrator accounts and revoke old claims. Student transfers update both classroom rosters and the profile transactionally while preserving historical classroom identifiers. Offboarding removes live roster and guardian links, preserves controlled work records, disables Authentication, and refuses to orphan a classroom by removing its last teacher.

Assignment services mirror the Android lifecycle: draft, scheduled, published, closed, and archived states use an explicit transition policy. Client request IDs produce deterministic assignment IDs for retry-safe creation. Edits and state changes run in transactions, increment a revision, preserve a staff-only prior snapshot, and write an audit record. Attachment references must stay beneath the assignment’s authorized Storage prefix. A scheduled function promotes up to 100 due scheduled assignments every five minutes and records the automatic transition.

Submission services use one deterministic document per assignment and learner. Draft, hand-in, unsubmit, return, complete, and reopen actions follow explicit role-specific transitions. Every mutation requires both an actor-scoped request ID and the revision the client last observed; exact retries are harmless, while stale clients receive a conflict instead of silently replacing work. Prior versions are retained in private submission-revision records. Attachment references are accepted only beneath that learner’s exact submission path, and empty hand-ins are rejected.

Push delivery uses a server-only notification outbox. Assignment publication/change, announcements, hand-ins, and returned/completed work enqueue generic events in the same atomic write as the underlying action. Device tokens, outbox records, and digest records are unreadable to clients. Per-account preferences support category opt-outs, IANA time zones, overnight quiet hours, and daily digests. Deferred events are delivered by a scheduled function, invalid FCM tokens are removed, and Android payloads use private visibility with no classroom, assignment, learner, feedback, or religious-text content. Delivery is at-least-once, so the future Android client must deduplicate by event ID after authentication.

Storage uses separate paths for classroom resources and private submissions. Classroom resources are writable only by assigned staff. Submission files are readable only by the student owner, linked guardian, assigned teacher, or administrator. Uploads must be non-empty, no larger than 15 MB, and one of JPEG, PNG, WebP, PDF, or plain text. Malware scanning remains a deployment gate.

## Local verification

From `functions/`:

```text
npm test
npm run lint
npm run test:rules
```

The rules command runs Firestore and Storage emulators under the explicit `demo-sabaq-classroom` project. The current suite covers unauthenticated access, cross-class submissions, guardian links, assigned teachers, draft visibility, private assignment/submission revision history, direct-write bypass attempts, opaque invitation and notification-delivery documents, immediate suspension, private submission files, staff-only assignment/announcement resources, and MIME validation. Emulator success does not replace deployment, App Check configuration, client integration, or independent review.

Before classroom-data deployment:

1. [x] Create the dedicated `sabaq-classroom` Firebase project and register `com.foxlabs.sabaqclassroom` with the permanent SHA-1/SHA-256 fingerprints.
2. [x] Enable Google Authentication on the Spark plan, set the public app name, refresh `google-services.json`, and connect the Android Credential Manager client without granting roles from client identity. The new support account has Editor project access; selecting it as Firebase's public support email remains open.
3. [ ] Firebase Email/Password authentication and required enforcement of a minimum 10-character password are enabled. Email-enumeration protection, authorized reset domains, and reviewed Sabaq-branded password-reset templates remain open. Password credentials must link only to the same Google-verified Firebase identity during invitation activation; they never grant a role.
4. [ ] Change the Firebase Authentication public app name and all user-facing authentication/reset email templates to `Sabaq Workspace`, then verify the sender, subject, body, action URL, and mobile reset journey on a physical device.
5. [x] Firestore and the default Storage bucket are enabled in production. The project is on Blaze under the Google Cloud free trial, with a CA$2.50 monthly alert budget. A budget is an alert, not a hard spending cap; the operator must not activate the full paid account without a separate decision.
6. [x] Authorize the current Firebase CLI and function packages, then pass all 22 backend unit/policy tests, lint, and all 15 Firestore/Storage emulator tests immediately before deployment.
7. [ ] Bootstrap exactly one administrator through a documented one-time procedure and remove the bootstrap path.
8. [ ] Production Firestore rules/indexes and Storage rules are deployed. All 29 Cloud Functions are deployed in `us-central1` with `maxInstances: 2`, and Artifact Registry removes old function images after one day. Play Integrity App Check is registered for the permanent signing certificate with sideload-compatible verdict requirements; callable Functions enforce App Check in code. Monitoring review, API-level enforcement, and physical-device validation remain open.
9. [x] Keep the real Android project configuration local and git-ignored; never commit signing material.
10. [x] Build 5 passes 22 backend tests, lint, 15 emulator rule tests, Android unit tests, release lint, release assembly, and signing validation. The staged APK matches the tested APK byte-for-byte.

## One-time administrator bootstrap

After the chosen administrator signs in with their verified Google account once, an authorized project operator can run `npm run bootstrap-admin -- --project sabaq-classroom --email VERIFIED_GOOGLE_EMAIL` from `functions/` with Application Default Credentials. The script refuses to run if any administrator profile already exists, assigns the server claim and profile together with compensating rollback, revokes prior refresh tokens, and is never deployed as a callable endpoint. Mark deployment gate 7 complete only after the resulting profile, audit entry, and refreshed Android sign-in are verified.
